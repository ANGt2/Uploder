#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MVLite - Part 02 Admin Expanded
Standalone Telegram bot without external packages.

Part 02 adds:
- richer admin dashboard
- user search by ID/username
- block/unblock user
- promote/demote admin
- adjust user balance
- category sorting
- product sorting
- product move between categories
- order status management
- admin logs viewer
- database backup command
- safer HTTP error display
"""

import os
import json
import time
import sqlite3
import urllib.request
import urllib.error
import traceback
from datetime import datetime

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8979540158:AAGho_VCJlaYaggrhhcXQlAUm4KOv8sXfhU")
DB_PATH = os.environ.get("DB_PATH", "mixvoucher_lite.db")
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))

API = f"https://api.telegram.org/bot{BOT_TOKEN}"
STATE = {}

WELCOME_TEXT = """سلام 👋

به ربات فروش ووچر خوش آمدید.

از منوی زیر یکی از گزینه‌ها را انتخاب کنید.
"""

HELP_TEXT = """📚 راهنما

• از بخش خرید می‌توانید دسته‌بندی‌ها و محصولات را ببینید.
• محصولات، دسته‌بندی‌ها و دکمه‌های بخش خرید از پنل ادمین ساخته می‌شوند.
• بخش‌های هات ووچر، پریمیوم ووچر، یو ووچر، AI، VPN و VPS فعلاً خام هستند و از پنل ادمین محصول می‌گیرند.
"""

# -------------------- Basic Utilities --------------------

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def money(n):
    try:
        return f"{int(n):,}"
    except Exception:
        return "0"

def safe_int(value, default=0):
    try:
        return int(str(value).strip())
    except Exception:
        return default

def only_digits(text):
    return "".join(ch for ch in str(text) if ch.isdigit())

def html_escape(s):
    s = "" if s is None else str(s)
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

# -------------------- Telegram API --------------------

def tg(method, payload=None, timeout=60):
    payload = payload or {}
    url = f"{API}/{method}"
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            result = json.loads(raw)
            if not result.get("ok"):
                raise RuntimeError(result)
            return result["result"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Telegram HTTP {e.code}: {body}")

def answer_callback(callback_query_id, text="", show_alert=False):
    try:
        return tg("answerCallbackQuery", {
            "callback_query_id": callback_query_id,
            "text": text,
            "show_alert": show_alert,
        }, timeout=20)
    except Exception:
        return None

def send_message(chat_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "text": html_escape(text)[:4096] if "<b>" not in text and "<code>" not in text else text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return tg("sendMessage", payload)

def edit_message(chat_id, message_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        return tg("editMessageText", payload)
    except Exception as e:
        if "message is not modified" in str(e):
            return None
        raise

def send_document(chat_id, path, caption=""):
    boundary = "----MVLiteBoundary"
    with open(path, "rb") as f:
        file_data = f.read()
    filename = os.path.basename(path)

    body = b""
    def add_field(name, value):
        nonlocal body
        body += f"--{boundary}\r\n".encode()
        body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
        body += str(value).encode("utf-8") + b"\r\n"

    add_field("chat_id", chat_id)
    if caption:
        add_field("caption", caption)

    body += f"--{boundary}\r\n".encode()
    body += f'Content-Disposition: form-data; name="document"; filename="{filename}"\r\n'.encode()
    body += b"Content-Type: application/octet-stream\r\n\r\n"
    body += file_data + b"\r\n"
    body += f"--{boundary}--\r\n".encode()

    req = urllib.request.Request(
        f"{API}/sendDocument",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))

def kb(rows):
    return {"inline_keyboard": rows}

def btn(text, data):
    return {"text": text, "callback_data": data}

# -------------------- Database --------------------

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        balance INTEGER DEFAULT 0,
        is_blocked INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        price INTEGER DEFAULT 0,
        stock_text TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL,
        FOREIGN KEY(category_id) REFERENCES categories(id)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        product_id INTEGER,
        amount INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS admin_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_tg_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        detail TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )
    """)

    defaults = {
        "welcome_text": WELCOME_TEXT,
        "support_username": "@Support",
        "channel_username": "@Channel",
        "bot_status": "on",
        "shop_status": "on",
    }
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

    seed_categories = [
        ("🔥 Hot Voucher", "hot_voucher", "بخش هات ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 10),
        ("💎 Premium Voucher", "premium_voucher", "بخش پریمیوم ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 20),
        ("🟣 U Voucher", "u_voucher", "بخش یو ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 30),
        ("🤖 AI Services", "ai_services", "بخش سرویس‌های هوش مصنوعی - محصولات را از پنل ادمین اضافه کنید.", 1, 40),
        ("🌐 VPN Services", "vpn_services", "بخش سرویس‌های VPN - محصولات را از پنل ادمین اضافه کنید.", 1, 50),
        ("🖥 VPS / Server", "vps_server", "بخش سرور مجازی - محصولات را از پنل ادمین اضافه کنید.", 1, 60),
    ]
    for title, slug, desc, active, order in seed_categories:
        c.execute("""
        INSERT OR IGNORE INTO categories(title, slug, description, is_active, sort_order, created_at)
        VALUES(?,?,?,?,?,?)
        """, (title, slug, desc, active, order, now()))

    conn.commit()
    conn.close()

def get_setting(key, default=""):
    conn = db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default

def set_setting(key, value):
    conn = db()
    conn.execute("""
    INSERT INTO settings(key,value) VALUES(?,?)
    ON CONFLICT(key) DO UPDATE SET value=excluded.value
    """, (key, value))
    conn.commit()
    conn.close()

def log_admin(admin_tg_id, action, detail=""):
    conn = db()
    conn.execute("INSERT INTO admin_logs(admin_tg_id, action, detail, created_at) VALUES(?,?,?,?)",
                 (admin_tg_id, action, detail, now()))
    conn.commit()
    conn.close()

def upsert_user(message):
    user = message.get("from", {})
    tg_id = user.get("id")
    username = user.get("username") or ""
    first_name = user.get("first_name") or ""
    conn = db()
    conn.execute("""
    INSERT INTO users(tg_id, username, first_name, created_at)
    VALUES(?,?,?,?)
    ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name
    """, (tg_id, username, first_name, now()))
    if OWNER_ID and tg_id == OWNER_ID:
        conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?", (tg_id,))
    conn.commit()
    row = conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    conn.close()
    return row

def get_user(tg_id):
    conn = db()
    row = conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    conn.close()
    return row

def get_user_by_any(query):
    q = str(query).strip()
    conn = db()
    row = None
    if q.startswith("@"):
        row = conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q[1:],)).fetchone()
    elif q.isdigit():
        row = conn.execute("SELECT * FROM users WHERE tg_id=? OR id=?", (int(q), int(q))).fetchone()
    else:
        row = conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q,)).fetchone()
    conn.close()
    return row

def is_admin(tg_id):
    u = get_user(tg_id)
    return bool(u and u["is_admin"])

def require_admin(tg_id):
    if not is_admin(tg_id):
        raise PermissionError("admin required")

def stats():
    conn = db()
    data = {}
    for name, query in {
        "users": "SELECT COUNT(*) n FROM users",
        "admins": "SELECT COUNT(*) n FROM users WHERE is_admin=1",
        "blocked": "SELECT COUNT(*) n FROM users WHERE is_blocked=1",
        "balance": "SELECT COALESCE(SUM(balance),0) n FROM users",
        "categories": "SELECT COUNT(*) n FROM categories",
        "active_categories": "SELECT COUNT(*) n FROM categories WHERE is_active=1",
        "products": "SELECT COUNT(*) n FROM products",
        "active_products": "SELECT COUNT(*) n FROM products WHERE is_active=1",
        "orders": "SELECT COUNT(*) n FROM orders",
        "pending_orders": "SELECT COUNT(*) n FROM orders WHERE status='pending'",
        "done_orders": "SELECT COUNT(*) n FROM orders WHERE status='done'",
        "rejected_orders": "SELECT COUNT(*) n FROM orders WHERE status='rejected'",
    }.items():
        data[name] = conn.execute(query).fetchone()["n"]
    conn.close()
    return data

# -------------------- State Helpers --------------------

def set_state(tg_id, name, data=None):
    STATE[tg_id] = {"name": name, "data": data or {}, "time": time.time()}

def clear_state(tg_id):
    STATE.pop(tg_id, None)

def get_state(tg_id):
    return STATE.get(tg_id)

# -------------------- User Keyboards --------------------

def main_menu():
    return kb([
        [btn("🛒 خرید", "buy_menu"), btn("👤 حساب کاربری", "profile")],
        [btn("💰 کیف پول", "wallet"), btn("📦 سفارش‌های من", "my_orders")],
        [btn("📞 پشتیبانی", "support"), btn("📚 راهنما", "help")],
    ])

def back_main():
    return kb([[btn("🔙 بازگشت به منوی اصلی", "main")]])

def categories_menu():
    conn = db()
    rows = conn.execute("""
    SELECT * FROM categories
    WHERE is_active=1
    ORDER BY sort_order ASC, id ASC
    """).fetchall()
    conn.close()
    keyboard = []
    line = []
    for cat in rows:
        line.append(btn(cat["title"], f"cat:{cat['id']}"))
        if len(line) == 2:
            keyboard.append(line)
            line = []
    if line:
        keyboard.append(line)
    keyboard.append([btn("🔙 بازگشت", "main")])
    return kb(keyboard)

def products_menu(category_id):
    conn = db()
    cat = conn.execute("SELECT * FROM categories WHERE id=?", (category_id,)).fetchone()
    products = conn.execute("""
    SELECT * FROM products
    WHERE category_id=? AND is_active=1
    ORDER BY sort_order ASC, id ASC
    """, (category_id,)).fetchall()
    conn.close()
    keyboard = []
    for p in products:
        price = f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
        keyboard.append([btn(f"{p['title']} | {price}", f"product:{p['id']}")])
    if not products:
        keyboard.append([btn("فعلاً محصولی ثبت نشده", "noop")])
    keyboard.append([btn("🔙 دسته‌بندی‌ها", "buy_menu"), btn("🏠 خانه", "main")])
    return cat, kb(keyboard)

# -------------------- Admin Keyboards --------------------

def admin_menu():
    return kb([
        [btn("📊 آمار", "admin:stats"), btn("🧩 دسته‌بندی‌ها", "admin:cats")],
        [btn("📦 محصولات", "admin:products"), btn("👥 کاربران", "admin:users")],
        [btn("🧾 سفارش‌ها", "admin:orders"), btn("📜 لاگ‌ها", "admin:logs")],
        [btn("⚙️ تنظیمات", "admin:settings"), btn("📣 پیام همگانی", "admin:broadcast")],
        [btn("💾 بکاپ دیتابیس", "admin:backup"), btn("🧹 پاکسازی وضعیت", "admin:clear_state")],
        [btn("🏠 منوی کاربر", "main")],
    ])

def admin_back():
    return kb([[btn("🔙 پنل ادمین", "admin:home")]])

def admin_cats_menu():
    conn = db()
    cats = conn.execute("SELECT * FROM categories ORDER BY sort_order ASC, id ASC").fetchall()
    conn.close()
    rows = [[btn("➕ افزودن دسته‌بندی", "admin:cat_add")]]
    for c in cats:
        status = "✅" if c["is_active"] else "❌"
        rows.append([btn(f"{status} {c['sort_order']} | {c['title']}", f"admin:cat:{c['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_cat_detail_menu(cat_id):
    return kb([
        [btn("✏️ تغییر نام", f"admin:cat_rename:{cat_id}"), btn("🔢 ترتیب", f"admin:cat_sort:{cat_id}")],
        [btn("📝 تغییر توضیح", f"admin:cat_desc:{cat_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:cat_toggle:{cat_id}")],
        [btn("➕ افزودن محصول به این دسته", f"admin:prod_add_to:{cat_id}")],
        [btn("🗑 حذف دسته", f"admin:cat_delete_confirm:{cat_id}")],
        [btn("🔙 دسته‌بندی‌ها", "admin:cats")],
    ])

def admin_products_menu():
    conn = db()
    products = conn.execute("""
    SELECT p.*, c.title cat_title FROM products p
    LEFT JOIN categories c ON c.id=p.category_id
    ORDER BY p.id DESC LIMIT 70
    """).fetchall()
    conn.close()
    rows = [[btn("➕ افزودن محصول", "admin:prod_choose_cat")]]
    for p in products:
        status = "✅" if p["is_active"] else "❌"
        rows.append([btn(f"{status} #{p['id']} {p['title']} | {money(p['price'])}", f"admin:prod:{p['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_product_detail_menu(prod_id):
    return kb([
        [btn("✏️ نام", f"admin:prod_rename:{prod_id}"), btn("💰 قیمت", f"admin:prod_price:{prod_id}")],
        [btn("📝 توضیح", f"admin:prod_desc:{prod_id}"), btn("📦 متن موجودی", f"admin:prod_stock:{prod_id}")],
        [btn("🔢 ترتیب", f"admin:prod_sort:{prod_id}"), btn("📂 تغییر دسته", f"admin:prod_move:{prod_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:prod_toggle:{prod_id}")],
        [btn("🗑 حذف محصول", f"admin:prod_delete_confirm:{prod_id}")],
        [btn("🔙 محصولات", "admin:products")],
    ])

def admin_choose_cat_for_product(prefix="admin:prod_add_to"):
    conn = db()
    cats = conn.execute("SELECT * FROM categories ORDER BY sort_order ASC,id ASC").fetchall()
    conn.close()
    rows = []
    for c in cats:
        rows.append([btn(c["title"], f"{prefix}:{c['id']}")])
    rows.append([btn("🔙 محصولات", "admin:products")])
    return kb(rows)

def admin_settings_menu():
    bot_status = get_setting("bot_status", "on")
    shop_status = get_setting("shop_status", "on")
    return kb([
        [btn(f"🤖 وضعیت ربات: {bot_status}", "admin:toggle_bot")],
        [btn(f"🛒 وضعیت فروشگاه: {shop_status}", "admin:toggle_shop")],
        [btn("📝 متن شروع", "admin:set_welcome")],
        [btn("📞 پشتیبانی", "admin:set_support")],
        [btn("📢 کانال", "admin:set_channel")],
        [btn("🔙 پنل ادمین", "admin:home")],
    ])

def admin_user_detail_menu(tg_id):
    return kb([
        [btn("🚫 مسدود/آزاد", f"admin:user_toggle_block:{tg_id}")],
        [btn("👑 ادمین/عادی", f"admin:user_toggle_admin:{tg_id}")],
        [btn("💰 تغییر موجودی", f"admin:user_balance:{tg_id}")],
        [btn("🧾 سفارش‌های کاربر", f"admin:user_orders:{tg_id}")],
        [btn("🔙 کاربران", "admin:users")],
    ])

def admin_order_detail_menu(order_id):
    return kb([
        [btn("✅ انجام شد", f"admin:order_status:{order_id}:done")],
        [btn("⏳ pending", f"admin:order_status:{order_id}:pending")],
        [btn("❌ رد شد", f"admin:order_status:{order_id}:rejected")],
        [btn("📝 یادداشت", f"admin:order_note:{order_id}")],
        [btn("🔙 سفارش‌ها", "admin:orders")],
    ])

# -------------------- Render Texts --------------------

def render_profile(user):
    username = f"@{user['username']}" if user["username"] else "ندارد"
    return f"""👤 <b>حساب کاربری</b>

آیدی عددی: <code>{user['tg_id']}</code>
نام: {html_escape(user['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(user['balance'])}</b> تومان
تاریخ عضویت: {user['created_at']}
"""

def render_wallet(user):
    return f"""💰 <b>کیف پول</b>

موجودی فعلی شما:
<b>{money(user['balance'])}</b> تومان

در این نسخه، مدیریت موجودی از پنل ادمین انجام می‌شود.
"""

def render_category(cat):
    return f"""🛒 <b>{html_escape(cat['title'])}</b>

{html_escape(cat['description'] or 'محصولی برای این بخش ثبت نشده است.')}

از لیست زیر محصول موردنظر را انتخاب کنید.
"""

def render_product(p):
    price = f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
    stock = p["stock_text"] or "موجودی/تحویل توسط ادمین تنظیم نشده است."
    return f"""📦 <b>{html_escape(p['title'])}</b>

💰 قیمت: <b>{price}</b>

📝 توضیحات:
{html_escape(p['description'] or '-')}

📌 وضعیت/موجودی:
{html_escape(stock)}

برای تکمیل خرید، در نسخه‌های بعدی مسیر پرداخت و تحویل تکمیل می‌شود.
"""

def render_admin_home():
    s = stats()
    return f"""👑 <b>پنل مدیریت MVLite</b>

📊 کاربران: <b>{s['users']}</b>
👑 ادمین‌ها: <b>{s['admins']}</b>
🚫 مسدودها: <b>{s['blocked']}</b>
💰 مجموع موجودی کاربران: <b>{money(s['balance'])}</b> تومان

🧩 دسته‌بندی‌ها: <b>{s['categories']}</b> | فعال: <b>{s['active_categories']}</b>
📦 محصولات: <b>{s['products']}</b> | فعال: <b>{s['active_products']}</b>

🧾 سفارش‌ها: <b>{s['orders']}</b>
⏳ pending: <b>{s['pending_orders']}</b>
✅ done: <b>{s['done_orders']}</b>
❌ rejected: <b>{s['rejected_orders']}</b>

از دکمه‌های زیر مدیریت کن.
"""

def render_user_admin(u):
    admin = "بله 👑" if u["is_admin"] else "خیر"
    blocked = "بله 🚫" if u["is_blocked"] else "خیر"
    username = f"@{u['username']}" if u["username"] else "-"
    return f"""👤 <b>مدیریت کاربر</b>

ID داخلی: <code>{u['id']}</code>
Telegram ID: <code>{u['tg_id']}</code>
نام: {html_escape(u['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(u['balance'])}</b> تومان
ادمین: {admin}
مسدود: {blocked}
عضویت: {u['created_at']}
"""

def render_order_admin(o):
    return f"""🧾 <b>جزئیات سفارش</b>

ID: <code>{o['id']}</code>
کد: <code>{o['order_code']}</code>
کاربر: <code>{o['user_id']}</code>
محصول: {html_escape(o['product_title'] or '-')}
مبلغ: <b>{money(o['amount'])}</b> تومان
وضعیت: <b>{o['status']}</b>
تاریخ: {o['created_at']}

یادداشت:
{html_escape(o['note'] or '-')}
"""

# -------------------- User Actions --------------------

def open_main(chat_id, message_id=None):
    text = get_setting("welcome_text", WELCOME_TEXT)
    if message_id:
        edit_message(chat_id, message_id, text, main_menu())
    else:
        send_message(chat_id, text, main_menu())

def handle_user_callback(chat_id, message_id, tg_id, data):
    user = get_user(tg_id)

    if data == "noop":
        return

    if data == "main":
        clear_state(tg_id)
        return open_main(chat_id, message_id)

    if data == "buy_menu":
        if get_setting("shop_status", "on") != "on":
            return edit_message(chat_id, message_id, "🛒 فروشگاه فعلاً غیرفعال است.", back_main())
        return edit_message(chat_id, message_id, "🛒 <b>بخش خرید</b>\n\nیک دسته‌بندی را انتخاب کنید:", categories_menu())

    if data.startswith("cat:"):
        cat_id = int(data.split(":")[1])
        cat, keyboard = products_menu(cat_id)
        if not cat:
            return edit_message(chat_id, message_id, "دسته‌بندی پیدا نشد.", back_main())
        return edit_message(chat_id, message_id, render_category(cat), keyboard)

    if data.startswith("product:"):
        prod_id = int(data.split(":")[1])
        conn = db()
        p = conn.execute("SELECT * FROM products WHERE id=? AND is_active=1", (prod_id,)).fetchone()
        conn.close()
        if not p:
            return edit_message(chat_id, message_id, "محصول پیدا نشد یا غیرفعال است.", back_main())
        return edit_message(chat_id, message_id, render_product(p), kb([
            [btn("🛒 ثبت سفارش آزمایشی", f"order_test:{prod_id}")],
            [btn("🔙 برگشت", f"cat:{p['category_id']}"), btn("🏠 خانه", "main")]
        ]))

    if data.startswith("order_test:"):
        prod_id = int(data.split(":")[1])
        code = f"MV-{int(time.time())}-{tg_id % 10000}"
        conn = db()
        p = conn.execute("SELECT * FROM products WHERE id=?", (prod_id,)).fetchone()
        if not p:
            conn.close()
            return edit_message(chat_id, message_id, "محصول پیدا نشد.", back_main())
        conn.execute("""
        INSERT INTO orders(order_code,user_id,product_id,amount,status,note,created_at)
        VALUES(?,?,?,?,?,?,?)
        """, (code, tg_id, prod_id, p["price"], "pending", "سفارش آزمایشی نسخه دوم", now()))
        conn.commit()
        conn.close()
        return edit_message(chat_id, message_id,
            f"✅ سفارش آزمایشی ثبت شد.\n\nکد سفارش: <code>{code}</code>\nوضعیت: pending",
            back_main()
        )

    if data == "profile":
        return edit_message(chat_id, message_id, render_profile(user), back_main())

    if data == "wallet":
        return edit_message(chat_id, message_id, render_wallet(user), back_main())

    if data == "my_orders":
        conn = db()
        rows = conn.execute("""
        SELECT o.*, p.title product_title FROM orders o
        LEFT JOIN products p ON p.id=o.product_id
        WHERE o.user_id=?
        ORDER BY o.id DESC LIMIT 10
        """, (tg_id,)).fetchall()
        conn.close()
        if not rows:
            text = "📦 شما هنوز سفارشی ندارید."
        else:
            lines = ["📦 <b>آخرین سفارش‌های شما</b>\n"]
            for o in rows:
                lines.append(f"• <code>{o['order_code']}</code> | {html_escape(o['product_title'] or '-')} | {o['status']}")
            text = "\n".join(lines)
        return edit_message(chat_id, message_id, text, back_main())

    if data == "support":
        support = get_setting("support_username", "@Support")
        channel = get_setting("channel_username", "@Channel")
        return edit_message(chat_id, message_id,
            f"📞 <b>پشتیبانی</b>\n\nSupport: {html_escape(support)}\nChannel: {html_escape(channel)}",
            back_main()
        )

    if data == "help":
        return edit_message(chat_id, message_id, HELP_TEXT, back_main())

# -------------------- Admin Callback --------------------

def handle_admin_callback(chat_id, message_id, tg_id, data):
    require_admin(tg_id)

    if data == "admin:home":
        clear_state(tg_id)
        return edit_message(chat_id, message_id, render_admin_home(), admin_menu())

    if data == "admin:stats":
        return edit_message(chat_id, message_id, render_admin_home(), admin_menu())

    if data == "admin:cats":
        return edit_message(chat_id, message_id, "🧩 <b>مدیریت دسته‌بندی‌ها</b>", admin_cats_menu())

    if data == "admin:cat_add":
        set_state(tg_id, "cat_add_title")
        return edit_message(chat_id, message_id, "نام دسته‌بندی جدید را ارسال کن:", admin_back())

    if data.startswith("admin:cat:"):
        cat_id = int(data.split(":")[2])
        conn = db()
        cat = conn.execute("SELECT * FROM categories WHERE id=?", (cat_id,)).fetchone()
        conn.close()
        if not cat:
            return edit_message(chat_id, message_id, "دسته‌بندی پیدا نشد.", admin_cats_menu())
        status = "فعال ✅" if cat["is_active"] else "غیرفعال ❌"
        text = f"""🧩 <b>{html_escape(cat['title'])}</b>

ID: <code>{cat['id']}</code>
Slug: <code>{cat['slug']}</code>
وضعیت: {status}
ترتیب: {cat['sort_order']}

توضیح:
{html_escape(cat['description'] or '-')}
"""
        return edit_message(chat_id, message_id, text, admin_cat_detail_menu(cat_id))

    if data.startswith("admin:cat_rename:"):
        cat_id = int(data.split(":")[2])
        set_state(tg_id, "cat_rename", {"cat_id": cat_id})
        return edit_message(chat_id, message_id, "نام جدید دسته‌بندی را ارسال کن:", admin_back())

    if data.startswith("admin:cat_desc:"):
        cat_id = int(data.split(":")[2])
        set_state(tg_id, "cat_desc", {"cat_id": cat_id})
        return edit_message(chat_id, message_id, "توضیح جدید دسته‌بندی را ارسال کن:", admin_back())

    if data.startswith("admin:cat_sort:"):
        cat_id = int(data.split(":")[2])
        set_state(tg_id, "cat_sort", {"cat_id": cat_id})
        return edit_message(chat_id, message_id, "عدد ترتیب دسته را ارسال کن. عدد کمتر یعنی بالاتر.", admin_back())

    if data.startswith("admin:cat_toggle:"):
        cat_id = int(data.split(":")[2])
        conn = db()
        conn.execute("UPDATE categories SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (cat_id,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "cat_toggle", str(cat_id))
        return edit_message(chat_id, message_id, "وضعیت دسته‌بندی تغییر کرد.", admin_cats_menu())

    if data.startswith("admin:cat_delete_confirm:"):
        cat_id = int(data.split(":")[2])
        return edit_message(chat_id, message_id, "آیا از حذف این دسته مطمئنی؟ محصولاتش هم حذف می‌شوند.", kb([
            [btn("✅ بله حذف کن", f"admin:cat_delete:{cat_id}")],
            [btn("❌ انصراف", f"admin:cat:{cat_id}")],
        ]))

    if data.startswith("admin:cat_delete:"):
        cat_id = int(data.split(":")[2])
        conn = db()
        conn.execute("DELETE FROM products WHERE category_id=?", (cat_id,))
        conn.execute("DELETE FROM categories WHERE id=?", (cat_id,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "cat_delete", str(cat_id))
        return edit_message(chat_id, message_id, "دسته‌بندی حذف شد.", admin_cats_menu())

    if data == "admin:products":
        return edit_message(chat_id, message_id, "📦 <b>مدیریت محصولات</b>", admin_products_menu())

    if data == "admin:prod_choose_cat":
        return edit_message(chat_id, message_id, "اول دسته‌بندی محصول را انتخاب کن:", admin_choose_cat_for_product())

    if data.startswith("admin:prod_add_to:"):
        cat_id = int(data.split(":")[2])
        set_state(tg_id, "prod_add_title", {"cat_id": cat_id})
        return edit_message(chat_id, message_id, "نام محصول جدید را ارسال کن:", admin_back())

    if data.startswith("admin:prod:"):
        prod_id = int(data.split(":")[2])
        conn = db()
        p = conn.execute("""
        SELECT p.*, c.title cat_title FROM products p
        LEFT JOIN categories c ON c.id=p.category_id
        WHERE p.id=?
        """, (prod_id,)).fetchone()
        conn.close()
        if not p:
            return edit_message(chat_id, message_id, "محصول پیدا نشد.", admin_products_menu())
        status = "فعال ✅" if p["is_active"] else "غیرفعال ❌"
        text = f"""📦 <b>{html_escape(p['title'])}</b>

ID: <code>{p['id']}</code>
دسته: {html_escape(p['cat_title'] or '-')}
قیمت: <b>{money(p['price'])}</b> تومان
ترتیب: {p['sort_order']}
وضعیت: {status}

توضیح:
{html_escape(p['description'] or '-')}

موجودی/متن تحویل:
{html_escape(p['stock_text'] or '-')}
"""
        return edit_message(chat_id, message_id, text, admin_product_detail_menu(prod_id))

    if data.startswith("admin:prod_rename:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_rename", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "نام جدید محصول را ارسال کن:", admin_back())

    if data.startswith("admin:prod_price:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_price", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "قیمت جدید را به تومان و فقط عددی ارسال کن:", admin_back())

    if data.startswith("admin:prod_desc:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_desc", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "توضیح جدید محصول را ارسال کن:", admin_back())

    if data.startswith("admin:prod_stock:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_stock", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "متن موجودی/تحویل محصول را ارسال کن:", admin_back())

    if data.startswith("admin:prod_sort:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_sort", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "عدد ترتیب محصول را ارسال کن. عدد کمتر یعنی بالاتر.", admin_back())

    if data.startswith("admin:prod_move:"):
        prod_id = int(data.split(":")[2])
        set_state(tg_id, "prod_move_wait_cat", {"prod_id": prod_id})
        return edit_message(chat_id, message_id, "دسته‌بندی جدید محصول را انتخاب کن:", admin_choose_cat_for_product("admin:prod_move_to"))

    if data.startswith("admin:prod_move_to:"):
        cat_id = int(data.split(":")[2])
        st = get_state(tg_id)
        if not st or st["name"] != "prod_move_wait_cat":
            return edit_message(chat_id, message_id, "وضعیت انتقال پیدا نشد.", admin_products_menu())
        prod_id = st["data"]["prod_id"]
        conn = db()
        conn.execute("UPDATE products SET category_id=? WHERE id=?", (cat_id, prod_id))
        conn.commit()
        conn.close()
        clear_state(tg_id)
        log_admin(tg_id, "prod_move", f"{prod_id}->{cat_id}")
        return edit_message(chat_id, message_id, "✅ دسته محصول تغییر کرد.", admin_products_menu())

    if data.startswith("admin:prod_toggle:"):
        prod_id = int(data.split(":")[2])
        conn = db()
        conn.execute("UPDATE products SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (prod_id,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "prod_toggle", str(prod_id))
        return edit_message(chat_id, message_id, "وضعیت محصول تغییر کرد.", admin_products_menu())

    if data.startswith("admin:prod_delete_confirm:"):
        prod_id = int(data.split(":")[2])
        return edit_message(chat_id, message_id, "آیا از حذف محصول مطمئنی؟", kb([
            [btn("✅ بله حذف کن", f"admin:prod_delete:{prod_id}")],
            [btn("❌ انصراف", f"admin:prod:{prod_id}")],
        ]))

    if data.startswith("admin:prod_delete:"):
        prod_id = int(data.split(":")[2])
        conn = db()
        conn.execute("DELETE FROM products WHERE id=?", (prod_id,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "prod_delete", str(prod_id))
        return edit_message(chat_id, message_id, "محصول حذف شد.", admin_products_menu())

    if data == "admin:users":
        conn = db()
        rows = conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 25").fetchall()
        conn.close()
        lines = ["👥 <b>آخرین کاربران</b>\n"]
        for u in rows:
            admin_mark = "👑" if u["is_admin"] else ""
            block_mark = "🚫" if u["is_blocked"] else ""
            lines.append(f"{admin_mark}{block_mark} <code>{u['tg_id']}</code> | {html_escape(u['first_name'] or '-')} | @{html_escape(u['username'] or '-')}")
        return edit_message(chat_id, message_id, "\n".join(lines), kb([
            [btn("🔍 جستجوی کاربر", "admin:user_search")],
            [btn("🔙 پنل ادمین", "admin:home")]
        ]))

    if data == "admin:user_search":
        set_state(tg_id, "user_search")
        return edit_message(chat_id, message_id, "آیدی عددی یا یوزرنیم کاربر را ارسال کن:", admin_back())

    if data.startswith("admin:user:"):
        target = int(data.split(":")[2])
        u = get_user(target)
        if not u:
            return edit_message(chat_id, message_id, "کاربر پیدا نشد.", admin_back())
        return edit_message(chat_id, message_id, render_user_admin(u), admin_user_detail_menu(target))

    if data.startswith("admin:user_toggle_block:"):
        target = int(data.split(":")[2])
        conn = db()
        conn.execute("UPDATE users SET is_blocked=CASE WHEN is_blocked=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "user_toggle_block", str(target))
        u = get_user(target)
        return edit_message(chat_id, message_id, render_user_admin(u), admin_user_detail_menu(target))

    if data.startswith("admin:user_toggle_admin:"):
        target = int(data.split(":")[2])
        if OWNER_ID and target == OWNER_ID:
            return edit_message(chat_id, message_id, "مالک اصلی را نمی‌شود عادی کرد.", admin_back())
        conn = db()
        conn.execute("UPDATE users SET is_admin=CASE WHEN is_admin=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit()
        conn.close()
        log_admin(tg_id, "user_toggle_admin", str(target))
        u = get_user(target)
        return edit_message(chat_id, message_id, render_user_admin(u), admin_user_detail_menu(target))

    if data.startswith("admin:user_balance:"):
        target = int(data.split(":")[2])
        set_state(tg_id, "user_balance", {"target": target})
        return edit_message(chat_id, message_id, "موجودی جدید کاربر را به تومان و فقط عددی ارسال کن:", admin_back())

    if data.startswith("admin:user_orders:"):
        target = int(data.split(":")[2])
        return show_orders(chat_id, message_id, user_filter=target)

    if data == "admin:orders":
        return show_orders(chat_id, message_id)

    if data.startswith("admin:order:"):
        order_id = int(data.split(":")[2])
        conn = db()
        o = conn.execute("""
        SELECT o.*, p.title product_title FROM orders o
        LEFT JOIN products p ON p.id=o.product_id
        WHERE o.id=?
        """, (order_id,)).fetchone()
        conn.close()
        if not o:
            return edit_message(chat_id, message_id, "سفارش پیدا نشد.", admin_back())
        return edit_message(chat_id, message_id, render_order_admin(o), admin_order_detail_menu(order_id))

    if data.startswith("admin:order_status:"):
        parts = data.split(":")
        order_id = int(parts[2])
        status = parts[3]
        conn = db()
        conn.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        conn.commit()
        conn.close()
        log_admin(tg_id, "order_status", f"{order_id}={status}")
        return show_orders(chat_id, message_id)

    if data.startswith("admin:order_note:"):
        order_id = int(data.split(":")[2])
        set_state(tg_id, "order_note", {"order_id": order_id})
        return edit_message(chat_id, message_id, "یادداشت جدید سفارش را ارسال کن:", admin_back())

    if data == "admin:logs":
        conn = db()
        rows = conn.execute("SELECT * FROM admin_logs ORDER BY id DESC LIMIT 30").fetchall()
        conn.close()
        if not rows:
            text = "📜 لاگی ثبت نشده است."
        else:
            lines = ["📜 <b>آخرین لاگ‌های ادمین</b>\n"]
            for r in rows:
                lines.append(f"#{r['id']} | <code>{r['admin_tg_id']}</code> | {html_escape(r['action'])} | {html_escape(r['detail'] or '-')} | {r['created_at']}")
            text = "\n".join(lines)
        return edit_message(chat_id, message_id, text, admin_back())

    if data == "admin:backup":
        backup_name = f"mvlite_backup_{int(time.time())}.db"
        if os.path.exists(DB_PATH):
            with open(DB_PATH, "rb") as src, open(backup_name, "wb") as dst:
                dst.write(src.read())
            send_document(chat_id, backup_name, "💾 بکاپ دیتابیس MVLite")
            try:
                os.remove(backup_name)
            except Exception:
                pass
            return edit_message(chat_id, message_id, "✅ بکاپ ارسال شد.", admin_menu())
        return edit_message(chat_id, message_id, "دیتابیس پیدا نشد.", admin_back())

    if data == "admin:settings":
        return edit_message(chat_id, message_id, "⚙️ <b>تنظیمات</b>", admin_settings_menu())

    if data == "admin:toggle_bot":
        cur = get_setting("bot_status", "on")
        set_setting("bot_status", "off" if cur == "on" else "on")
        return edit_message(chat_id, message_id, "⚙️ <b>تنظیمات</b>", admin_settings_menu())

    if data == "admin:toggle_shop":
        cur = get_setting("shop_status", "on")
        set_setting("shop_status", "off" if cur == "on" else "on")
        return edit_message(chat_id, message_id, "⚙️ <b>تنظیمات</b>", admin_settings_menu())

    if data == "admin:set_welcome":
        set_state(tg_id, "set_welcome")
        return edit_message(chat_id, message_id, "متن جدید /start را ارسال کن:", admin_back())

    if data == "admin:set_support":
        set_state(tg_id, "set_support")
        return edit_message(chat_id, message_id, "یوزرنیم پشتیبانی را ارسال کن. مثال: @Rafturn", admin_back())

    if data == "admin:set_channel":
        set_state(tg_id, "set_channel")
        return edit_message(chat_id, message_id, "یوزرنیم کانال را ارسال کن. مثال: @channel", admin_back())

    if data == "admin:broadcast":
        set_state(tg_id, "broadcast")
        return edit_message(chat_id, message_id, "متن پیام همگانی را ارسال کن:", admin_back())

    if data == "admin:clear_state":
        clear_state(tg_id)
        return edit_message(chat_id, message_id, "وضعیت موقت پاک شد.", admin_menu())

def show_orders(chat_id, message_id, user_filter=None):
    conn = db()
    if user_filter:
        rows = conn.execute("""
        SELECT o.*, p.title product_title FROM orders o
        LEFT JOIN products p ON p.id=o.product_id
        WHERE o.user_id=?
        ORDER BY o.id DESC LIMIT 30
        """, (user_filter,)).fetchall()
    else:
        rows = conn.execute("""
        SELECT o.*, p.title product_title FROM orders o
        LEFT JOIN products p ON p.id=o.product_id
        ORDER BY o.id DESC LIMIT 30
        """).fetchall()
    conn.close()

    if not rows:
        text = "🧾 سفارشی ثبت نشده است."
        return edit_message(chat_id, message_id, text, admin_back())

    lines = ["🧾 <b>آخرین سفارش‌ها</b>\n"]
    buttons = []
    for o in rows:
        lines.append(f"#{o['id']} | <code>{o['order_code']}</code> | user:{o['user_id']} | {html_escape(o['product_title'] or '-')} | {o['status']}")
        buttons.append([btn(f"#{o['id']} {o['status']}", f"admin:order:{o['id']}")])
    buttons.append([btn("🔙 پنل ادمین", "admin:home")])
    return edit_message(chat_id, message_id, "\n".join(lines), kb(buttons))

# -------------------- State Text Handlers --------------------

def handle_state_message(chat_id, tg_id, text):
    st = get_state(tg_id)
    if not st:
        return False
    if not is_admin(tg_id):
        clear_state(tg_id)
        return False

    name = st["name"]
    data = st.get("data") or {}
    conn = db()

    try:
        if name == "cat_add_title":
            slug = "cat_" + str(int(time.time()))
            conn.execute("""
            INSERT INTO categories(title,slug,description,is_active,sort_order,created_at)
            VALUES(?,?,?,?,?,?)
            """, (text.strip(), slug, "", 1, 100, now()))
            conn.commit()
            log_admin(tg_id, "cat_add", text)
            send_message(chat_id, "✅ دسته‌بندی اضافه شد.", admin_cats_menu())
            return True

        if name == "cat_rename":
            conn.execute("UPDATE categories SET title=? WHERE id=?", (text.strip(), data["cat_id"]))
            conn.commit()
            log_admin(tg_id, "cat_rename", str(data["cat_id"]))
            send_message(chat_id, "✅ نام دسته‌بندی تغییر کرد.", admin_cats_menu())
            return True

        if name == "cat_desc":
            conn.execute("UPDATE categories SET description=? WHERE id=?", (text.strip(), data["cat_id"]))
            conn.commit()
            log_admin(tg_id, "cat_desc", str(data["cat_id"]))
            send_message(chat_id, "✅ توضیح دسته‌بندی تغییر کرد.", admin_cats_menu())
            return True

        if name == "cat_sort":
            sort_order = safe_int(text, 100)
            conn.execute("UPDATE categories SET sort_order=? WHERE id=?", (sort_order, data["cat_id"]))
            conn.commit()
            log_admin(tg_id, "cat_sort", f"{data['cat_id']}={sort_order}")
            send_message(chat_id, "✅ ترتیب دسته‌بندی تغییر کرد.", admin_cats_menu())
            return True

        if name == "prod_add_title":
            conn.execute("""
            INSERT INTO products(category_id,title,description,price,stock_text,is_active,sort_order,created_at)
            VALUES(?,?,?,?,?,?,?,?)
            """, (data["cat_id"], text.strip(), "", 0, "", 1, 100, now()))
            conn.commit()
            log_admin(tg_id, "prod_add", text)
            send_message(chat_id, "✅ محصول اضافه شد. از بخش محصولات می‌توانی قیمت، ترتیب و توضیح بدهی.", admin_products_menu())
            return True

        if name == "prod_rename":
            conn.execute("UPDATE products SET title=? WHERE id=?", (text.strip(), data["prod_id"]))
            conn.commit()
            log_admin(tg_id, "prod_rename", str(data["prod_id"]))
            send_message(chat_id, "✅ نام محصول تغییر کرد.", admin_products_menu())
            return True

        if name == "prod_price":
            price = safe_int(only_digits(text), 0)
            conn.execute("UPDATE products SET price=? WHERE id=?", (price, data["prod_id"]))
            conn.commit()
            log_admin(tg_id, "prod_price", f"{data['prod_id']}={price}")
            send_message(chat_id, "✅ قیمت محصول تغییر کرد.", admin_products_menu())
            return True

        if name == "prod_desc":
            conn.execute("UPDATE products SET description=? WHERE id=?", (text.strip(), data["prod_id"]))
            conn.commit()
            log_admin(tg_id, "prod_desc", str(data["prod_id"]))
            send_message(chat_id, "✅ توضیح محصول تغییر کرد.", admin_products_menu())
            return True

        if name == "prod_stock":
            conn.execute("UPDATE products SET stock_text=? WHERE id=?", (text.strip(), data["prod_id"]))
            conn.commit()
            log_admin(tg_id, "prod_stock", str(data["prod_id"]))
            send_message(chat_id, "✅ متن موجودی/تحویل تغییر کرد.", admin_products_menu())
            return True

        if name == "prod_sort":
            sort_order = safe_int(text, 100)
            conn.execute("UPDATE products SET sort_order=? WHERE id=?", (sort_order, data["prod_id"]))
            conn.commit()
            log_admin(tg_id, "prod_sort", f"{data['prod_id']}={sort_order}")
            send_message(chat_id, "✅ ترتیب محصول تغییر کرد.", admin_products_menu())
            return True

        if name == "user_search":
            u = get_user_by_any(text)
            if not u:
                send_message(chat_id, "❌ کاربر پیدا نشد.", admin_back())
                return True
            send_message(chat_id, render_user_admin(u), admin_user_detail_menu(u["tg_id"]))
            return True

        if name == "user_balance":
            target = data["target"]
            balance = safe_int(only_digits(text), 0)
            conn.execute("UPDATE users SET balance=? WHERE tg_id=?", (balance, target))
            conn.commit()
            log_admin(tg_id, "user_balance", f"{target}={balance}")
            u = get_user(target)
            send_message(chat_id, "✅ موجودی کاربر تغییر کرد.")
            send_message(chat_id, render_user_admin(u), admin_user_detail_menu(target))
            return True

        if name == "order_note":
            order_id = data["order_id"]
            conn.execute("UPDATE orders SET note=? WHERE id=?", (text.strip(), order_id))
            conn.commit()
            log_admin(tg_id, "order_note", str(order_id))
            send_message(chat_id, "✅ یادداشت سفارش تغییر کرد.", admin_menu())
            return True

        if name == "set_welcome":
            set_setting("welcome_text", text.strip())
            log_admin(tg_id, "set_welcome")
            send_message(chat_id, "✅ متن شروع تغییر کرد.", admin_settings_menu())
            return True

        if name == "set_support":
            set_setting("support_username", text.strip())
            log_admin(tg_id, "set_support", text)
            send_message(chat_id, "✅ پشتیبانی تغییر کرد.", admin_settings_menu())
            return True

        if name == "set_channel":
            set_setting("channel_username", text.strip())
            log_admin(tg_id, "set_channel", text)
            send_message(chat_id, "✅ کانال تغییر کرد.", admin_settings_menu())
            return True

        if name == "broadcast":
            users = conn.execute("SELECT tg_id FROM users WHERE is_blocked=0").fetchall()
            clear_state(tg_id)
            conn.close()
            ok = 0
            fail = 0
            send_message(chat_id, f"📣 شروع ارسال به {len(users)} کاربر...")
            for u in users:
                try:
                    send_message(u["tg_id"], text)
                    ok += 1
                    time.sleep(0.05)
                except Exception:
                    fail += 1
            log_admin(tg_id, "broadcast", f"ok={ok}, fail={fail}")
            send_message(chat_id, f"✅ ارسال تمام شد.\nموفق: {ok}\nناموفق: {fail}", admin_menu())
            return True

    finally:
        try:
            conn.close()
        except Exception:
            pass
        clear_state(tg_id)

    return False

# -------------------- Message Dispatcher --------------------

def handle_message(message):
    user = upsert_user(message)
    chat_id = message["chat"]["id"]
    tg_id = message["from"]["id"]
    text = message.get("text", "")

    if user["is_blocked"]:
        return send_message(chat_id, "🚫 دسترسی شما به ربات مسدود شده است.")

    if get_setting("bot_status", "on") != "on" and not is_admin(tg_id):
        return send_message(chat_id, "ربات فعلاً غیرفعال است.")

    if text == "/start":
        clear_state(tg_id)
        return open_main(chat_id)

    if text == "/help":
        return send_message(chat_id, HELP_TEXT, back_main())

    if text == "/claim_admin":
        conn = db()
        count = conn.execute("SELECT COUNT(*) n FROM users WHERE is_admin=1").fetchone()["n"]
        if count == 0 or (OWNER_ID and tg_id == OWNER_ID):
            conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?", (tg_id,))
            conn.commit()
            conn.close()
            return send_message(chat_id, "✅ شما ادمین شدید.\nحالا /admin را بزنید.")
        conn.close()
        return send_message(chat_id, "❌ ادمین قبلاً ثبت شده است.")

    if text == "/admin":
        if not is_admin(tg_id):
            return send_message(chat_id, "❌ شما ادمین نیستید.\nاگر اولین اجراست، /claim_admin را بزنید.")
        clear_state(tg_id)
        return send_message(chat_id, render_admin_home(), admin_menu())

    if text == "/backup":
        if not is_admin(tg_id):
            return send_message(chat_id, "❌ دسترسی ندارید.")
        backup_name = f"mvlite_backup_{int(time.time())}.db"
        if os.path.exists(DB_PATH):
            with open(DB_PATH, "rb") as src, open(backup_name, "wb") as dst:
                dst.write(src.read())
            send_document(chat_id, backup_name, "💾 بکاپ دیتابیس")
            try:
                os.remove(backup_name)
            except Exception:
                pass
            return
        return send_message(chat_id, "دیتابیس پیدا نشد.")

    if handle_state_message(chat_id, tg_id, text):
        return

    return send_message(chat_id, "از منوی زیر استفاده کنید:", main_menu())

def handle_callback(callback):
    cq_id = callback["id"]
    message = callback.get("message", {})
    chat_id = message.get("chat", {}).get("id")
    message_id = message.get("message_id")
    tg_id = callback["from"]["id"]
    data = callback.get("data", "")

    answer_callback(cq_id)
    fake_msg = {"from": callback["from"], "chat": message.get("chat", {})}
    upsert_user(fake_msg)

    try:
        if data.startswith("admin:"):
            return handle_admin_callback(chat_id, message_id, tg_id, data)
        return handle_user_callback(chat_id, message_id, tg_id, data)
    except PermissionError:
        return edit_message(chat_id, message_id, "❌ دسترسی ادمین ندارید.", back_main())
    except Exception as e:
        traceback.print_exc()
        return edit_message(chat_id, message_id, f"خطا:\n<code>{html_escape(repr(e))}</code>", back_main())

def polling_loop():
    print("MVLite Part 02 is running...")
    print("Use /claim_admin for first admin, then /admin")
    offset = 0

    while True:
        try:
            updates = tg("getUpdates", {
                "timeout": 30,
                "offset": offset,
                "allowed_updates": ["message", "callback_query"],
            }, timeout=45)

            for upd in updates:
                offset = upd["update_id"] + 1
                try:
                    if "message" in upd:
                        handle_message(upd["message"])
                    elif "callback_query" in upd:
                        handle_callback(upd["callback_query"])
                except Exception as inner:
                    print("UPDATE ERROR:", repr(inner))
                    traceback.print_exc()

        except KeyboardInterrupt:
            print("Stopped.")
            break
        except Exception as e:
            print("POLLING ERROR:", repr(e))
            time.sleep(5)

def main():
    init_db()
    polling_loop()

if __name__ == "__main__":
    main()

