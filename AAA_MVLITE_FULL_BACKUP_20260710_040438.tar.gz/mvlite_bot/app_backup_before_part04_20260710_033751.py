#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MVLite - Part 03 Wallet / Payments / Receipts
Standalone Telegram bot without external packages.

Part 03 adds:
- wallet top-up request flow
- receipt submission as text or photo
- admin review for top-up requests
- wallet transaction ledger
- full purchase flow using wallet balance
- product stock mode: manual/unlimited/text stock
- better order creation and balance deduction
- user order detail page
- admin payment panel
"""

import os, json, time, sqlite3, urllib.request, urllib.error, traceback
from datetime import datetime

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8979540158:AAGho_VCJlaYaggrhhcXQlAUm4KOv8sXfhU")
DB_PATH = os.environ.get("DB_PATH", "mixvoucher_lite.db")
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))
API = f"https://api.telegram.org/bot{BOT_TOKEN}"
STATE = {}

WELCOME_TEXT = """سلام 👋

به ربات فروش ووچر خوش آمدید.

از منوی زیر یکی از گزینه‌ها را انتخاب کنید.
"""

HELP_TEXT = """📚 راهنما

• از بخش خرید دسته‌بندی و محصول را انتخاب کنید.
• خرید از موجودی کیف پول انجام می‌شود.
• برای افزایش موجودی از بخش کیف پول درخواست شارژ ثبت کنید.
• رسید شما توسط ادمین بررسی می‌شود.
"""

BANK_INFO_DEFAULT = """شماره کارت/حساب فروشگاه هنوز تنظیم نشده است.

ادمین می‌تواند از مسیر:
پنل ادمین ← تنظیمات ← اطلاعات پرداخت
آن را تنظیم کند.
"""

# -------------------- Utilities --------------------

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def money(n):
    try: return f"{int(n):,}"
    except Exception: return "0"

def safe_int(value, default=0):
    try: return int(str(value).strip())
    except Exception: return default

def only_digits(text):
    return "".join(ch for ch in str(text) if ch.isdigit())

def html_escape(s):
    s = "" if s is None else str(s)
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

def short_code(prefix):
    return f"{prefix}-{int(time.time())}-{os.getpid()%1000}"

# -------------------- Telegram --------------------

def tg(method, payload=None, timeout=60):
    payload = payload or {}
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        f"{API}/{method}",
        data=data,
        headers={"Content-Type":"application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            out = json.loads(raw)
            if not out.get("ok"):
                raise RuntimeError(out)
            return out["result"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Telegram HTTP {e.code}: {body}")

def answer_callback(cid, text="", show_alert=False):
    try: tg("answerCallbackQuery", {"callback_query_id":cid,"text":text,"show_alert":show_alert}, 20)
    except Exception: pass

def send_message(chat_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup: payload["reply_markup"] = reply_markup
    return tg("sendMessage", payload)

def edit_message(chat_id, message_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup: payload["reply_markup"] = reply_markup
    try:
        return tg("editMessageText", payload)
    except Exception as e:
        if "message is not modified" in str(e): return None
        raise

def send_document(chat_id, path, caption=""):
    boundary = "----MVLiteBoundary"
    with open(path, "rb") as f: file_data = f.read()
    filename = os.path.basename(path)
    body = b""
    def field(name, value):
        nonlocal body
        body += f"--{boundary}\r\n".encode()
        body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
        body += str(value).encode("utf-8") + b"\r\n"
    field("chat_id", chat_id)
    if caption: field("caption", caption)
    body += f"--{boundary}\r\n".encode()
    body += f'Content-Disposition: form-data; name="document"; filename="{filename}"\r\n'.encode()
    body += b"Content-Type: application/octet-stream\r\n\r\n" + file_data + b"\r\n"
    body += f"--{boundary}--\r\n".encode()
    req = urllib.request.Request(
        f"{API}/sendDocument", data=body,
        headers={"Content-Type":f"multipart/form-data; boundary={boundary}"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))

def kb(rows): return {"inline_keyboard": rows}
def btn(text, data): return {"text": text, "callback_data": data}

# -------------------- Database --------------------

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db(); c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        balance INTEGER DEFAULT 0,
        is_blocked INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        price INTEGER DEFAULT 0,
        stock_text TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL,
        FOREIGN KEY(category_id) REFERENCES categories(id)
    )""")

    # migrations for old DBs
    for col, ddl in [
        ("stock_mode", "ALTER TABLE products ADD COLUMN stock_mode TEXT DEFAULT 'manual'"),
        ("delivery_text", "ALTER TABLE products ADD COLUMN delivery_text TEXT DEFAULT ''"),
        ("min_qty", "ALTER TABLE products ADD COLUMN min_qty INTEGER DEFAULT 1"),
        ("max_qty", "ALTER TABLE products ADD COLUMN max_qty INTEGER DEFAULT 1"),
    ]:
        try: c.execute(ddl)
        except sqlite3.OperationalError: pass

    c.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        product_id INTEGER,
        amount INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    for col, ddl in [
        ("qty", "ALTER TABLE orders ADD COLUMN qty INTEGER DEFAULT 1"),
        ("delivery_text", "ALTER TABLE orders ADD COLUMN delivery_text TEXT DEFAULT ''"),
        ("updated_at", "ALTER TABLE orders ADD COLUMN updated_at TEXT DEFAULT ''"),
    ]:
        try: c.execute(ddl)
        except sqlite3.OperationalError: pass

    c.execute("""CREATE TABLE IF NOT EXISTS admin_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_tg_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        detail TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        type TEXT NOT NULL,
        ref_type TEXT DEFAULT '',
        ref_id INTEGER DEFAULT 0,
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS payment_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        status TEXT DEFAULT 'pending',
        receipt_type TEXT DEFAULT 'text',
        receipt_text TEXT DEFAULT '',
        receipt_file_id TEXT DEFAULT '',
        admin_note TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        reviewed_at TEXT DEFAULT ''
    )""")

    defaults = {
        "welcome_text": WELCOME_TEXT,
        "support_username": "@Support",
        "channel_username": "@Channel",
        "bot_status": "on",
        "shop_status": "on",
        "bank_info": BANK_INFO_DEFAULT,
        "min_topup": "10000",
        "max_topup": "50000000",
    }
    for k,v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k,v))

    seed = [
        ("🔥 Hot Voucher", "hot_voucher", "بخش هات ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 10),
        ("💎 Premium Voucher", "premium_voucher", "بخش پریمیوم ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 20),
        ("🟣 U Voucher", "u_voucher", "بخش یو ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 30),
        ("🤖 AI Services", "ai_services", "بخش سرویس‌های هوش مصنوعی - محصولات را از پنل ادمین اضافه کنید.", 1, 40),
        ("🌐 VPN Services", "vpn_services", "بخش سرویس‌های VPN - محصولات را از پنل ادمین اضافه کنید.", 1, 50),
        ("🖥 VPS / Server", "vps_server", "بخش سرور مجازی - محصولات را از پنل ادمین اضافه کنید.", 1, 60),
    ]
    for title, slug, desc, active, order in seed:
        c.execute("""INSERT OR IGNORE INTO categories(title,slug,description,is_active,sort_order,created_at)
                     VALUES(?,?,?,?,?,?)""", (title,slug,desc,active,order,now()))
    conn.commit(); conn.close()

def get_setting(key, default=""):
    conn=db(); row=conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone(); conn.close()
    return row["value"] if row else default

def set_setting(key,value):
    conn=db()
    conn.execute("""INSERT INTO settings(key,value) VALUES(?,?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value""", (key,value))
    conn.commit(); conn.close()

def log_admin(admin_tg_id, action, detail=""):
    conn=db()
    conn.execute("INSERT INTO admin_logs(admin_tg_id,action,detail,created_at) VALUES(?,?,?,?)",
                 (admin_tg_id, action, detail, now()))
    conn.commit(); conn.close()

def add_wallet_tx(conn, user_id, amount, typ, ref_type="", ref_id=0, note=""):
    conn.execute("""INSERT INTO wallet_transactions(user_id,amount,type,ref_type,ref_id,note,created_at)
                    VALUES(?,?,?,?,?,?,?)""", (user_id, amount, typ, ref_type, ref_id, note, now()))

def change_balance(user_id, delta, typ, ref_type="", ref_id=0, note=""):
    conn=db()
    conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (delta, user_id))
    add_wallet_tx(conn, user_id, delta, typ, ref_type, ref_id, note)
    conn.commit(); conn.close()

def upsert_user(message):
    user = message.get("from", {})
    tg_id = user.get("id")
    username = user.get("username") or ""
    first_name = user.get("first_name") or ""
    conn=db()
    conn.execute("""INSERT INTO users(tg_id,username,first_name,created_at)
                    VALUES(?,?,?,?)
                    ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name""",
                 (tg_id, username, first_name, now()))
    if OWNER_ID and tg_id == OWNER_ID:
        conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?", (tg_id,))
    conn.commit()
    row=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    conn.close(); return row

def get_user(tg_id):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone(); conn.close(); return row

def get_user_by_any(query):
    q=str(query).strip()
    conn=db(); row=None
    if q.startswith("@"):
        row=conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q[1:],)).fetchone()
    elif q.isdigit():
        row=conn.execute("SELECT * FROM users WHERE tg_id=? OR id=?", (int(q), int(q))).fetchone()
    else:
        row=conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q,)).fetchone()
    conn.close(); return row

def is_admin(tg_id):
    u=get_user(tg_id); return bool(u and u["is_admin"])

def require_admin(tg_id):
    if not is_admin(tg_id): raise PermissionError("admin required")

def stats():
    conn=db(); data={}
    queries = {
        "users":"SELECT COUNT(*) n FROM users",
        "admins":"SELECT COUNT(*) n FROM users WHERE is_admin=1",
        "blocked":"SELECT COUNT(*) n FROM users WHERE is_blocked=1",
        "balance":"SELECT COALESCE(SUM(balance),0) n FROM users",
        "categories":"SELECT COUNT(*) n FROM categories",
        "active_categories":"SELECT COUNT(*) n FROM categories WHERE is_active=1",
        "products":"SELECT COUNT(*) n FROM products",
        "active_products":"SELECT COUNT(*) n FROM products WHERE is_active=1",
        "orders":"SELECT COUNT(*) n FROM orders",
        "pending_orders":"SELECT COUNT(*) n FROM orders WHERE status='pending'",
        "done_orders":"SELECT COUNT(*) n FROM orders WHERE status='done'",
        "rejected_orders":"SELECT COUNT(*) n FROM orders WHERE status='rejected'",
        "payments":"SELECT COUNT(*) n FROM payment_requests",
        "pending_payments":"SELECT COUNT(*) n FROM payment_requests WHERE status='pending'",
    }
    for name,q in queries.items():
        data[name]=conn.execute(q).fetchone()["n"]
    conn.close(); return data

# -------------------- State --------------------

def set_state(tg_id,name,data=None): STATE[tg_id]={"name":name,"data":data or {}, "time":time.time()}
def clear_state(tg_id): STATE.pop(tg_id, None)
def get_state(tg_id): return STATE.get(tg_id)

# -------------------- Keyboards --------------------

def main_menu():
    return kb([
        [btn("🛒 خرید", "buy_menu"), btn("👤 حساب کاربری", "profile")],
        [btn("💰 کیف پول", "wallet"), btn("📦 سفارش‌های من", "my_orders")],
        [btn("📞 پشتیبانی", "support"), btn("📚 راهنما", "help")],
    ])

def back_main(): return kb([[btn("🔙 بازگشت به منوی اصلی", "main")]])

def wallet_menu():
    return kb([
        [btn("➕ شارژ کیف پول", "wallet_topup")],
        [btn("📜 تراکنش‌های کیف پول", "wallet_txs")],
        [btn("🧾 درخواست‌های شارژ", "my_payments")],
        [btn("🔙 منوی اصلی", "main")]
    ])

def categories_menu():
    conn=db()
    rows=conn.execute("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order ASC,id ASC").fetchall()
    conn.close()
    keyboard=[]; line=[]
    for cat in rows:
        line.append(btn(cat["title"], f"cat:{cat['id']}"))
        if len(line)==2:
            keyboard.append(line); line=[]
    if line: keyboard.append(line)
    keyboard.append([btn("🔙 بازگشت", "main")])
    return kb(keyboard)

def products_menu(category_id):
    conn=db()
    cat=conn.execute("SELECT * FROM categories WHERE id=?", (category_id,)).fetchone()
    products=conn.execute("""SELECT * FROM products WHERE category_id=? AND is_active=1
                             ORDER BY sort_order ASC,id ASC""", (category_id,)).fetchall()
    conn.close()
    keyboard=[]
    for p in products:
        price = f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
        keyboard.append([btn(f"{p['title']} | {price}", f"product:{p['id']}")])
    if not products: keyboard.append([btn("فعلاً محصولی ثبت نشده", "noop")])
    keyboard.append([btn("🔙 دسته‌بندی‌ها", "buy_menu"), btn("🏠 خانه", "main")])
    return cat, kb(keyboard)

def product_buy_menu(prod_id):
    return kb([
        [btn("✅ خرید با کیف پول", f"buy_confirm:{prod_id}")],
        [btn("🔙 برگشت", f"product:{prod_id}"), btn("🏠 خانه", "main")]
    ])

def admin_menu():
    s=stats()
    pending_pay = s["pending_payments"]
    return kb([
        [btn("📊 آمار", "admin:stats"), btn("🧩 دسته‌بندی‌ها", "admin:cats")],
        [btn("📦 محصولات", "admin:products"), btn("👥 کاربران", "admin:users")],
        [btn(f"💳 پرداخت‌ها ({pending_pay})", "admin:payments"), btn("🧾 سفارش‌ها", "admin:orders")],
        [btn("📜 لاگ‌ها", "admin:logs"), btn("⚙️ تنظیمات", "admin:settings")],
        [btn("📣 پیام همگانی", "admin:broadcast"), btn("💾 بکاپ دیتابیس", "admin:backup")],
        [btn("🏠 منوی کاربر", "main")],
    ])

def admin_back(): return kb([[btn("🔙 پنل ادمین", "admin:home")]])

def admin_cats_menu():
    conn=db(); cats=conn.execute("SELECT * FROM categories ORDER BY sort_order ASC,id ASC").fetchall(); conn.close()
    rows=[[btn("➕ افزودن دسته‌بندی", "admin:cat_add")]]
    for c in cats:
        rows.append([btn(f"{'✅' if c['is_active'] else '❌'} {c['sort_order']} | {c['title']}", f"admin:cat:{c['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_cat_detail_menu(cat_id):
    return kb([
        [btn("✏️ نام", f"admin:cat_rename:{cat_id}"), btn("🔢 ترتیب", f"admin:cat_sort:{cat_id}")],
        [btn("📝 توضیح", f"admin:cat_desc:{cat_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:cat_toggle:{cat_id}")],
        [btn("➕ افزودن محصول", f"admin:prod_add_to:{cat_id}")],
        [btn("🗑 حذف دسته", f"admin:cat_delete_confirm:{cat_id}")],
        [btn("🔙 دسته‌بندی‌ها", "admin:cats")]
    ])

def admin_products_menu():
    conn=db()
    products=conn.execute("""SELECT p.*,c.title cat_title FROM products p
                             LEFT JOIN categories c ON c.id=p.category_id
                             ORDER BY p.id DESC LIMIT 80""").fetchall()
    conn.close()
    rows=[[btn("➕ افزودن محصول", "admin:prod_choose_cat")]]
    for p in products:
        rows.append([btn(f"{'✅' if p['is_active'] else '❌'} #{p['id']} {p['title']} | {money(p['price'])}", f"admin:prod:{p['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_product_detail_menu(prod_id):
    return kb([
        [btn("✏️ نام", f"admin:prod_rename:{prod_id}"), btn("💰 قیمت", f"admin:prod_price:{prod_id}")],
        [btn("📝 توضیح", f"admin:prod_desc:{prod_id}"), btn("📦 متن موجودی", f"admin:prod_stock:{prod_id}")],
        [btn("🚚 متن تحویل", f"admin:prod_delivery:{prod_id}"), btn("🏷 حالت موجودی", f"admin:prod_stockmode:{prod_id}")],
        [btn("🔢 ترتیب", f"admin:prod_sort:{prod_id}"), btn("📂 تغییر دسته", f"admin:prod_move:{prod_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:prod_toggle:{prod_id}")],
        [btn("🗑 حذف محصول", f"admin:prod_delete_confirm:{prod_id}")],
        [btn("🔙 محصولات", "admin:products")]
    ])

def admin_choose_cat_for_product(prefix="admin:prod_add_to"):
    conn=db(); cats=conn.execute("SELECT * FROM categories ORDER BY sort_order ASC,id ASC").fetchall(); conn.close()
    rows=[[btn(c["title"], f"{prefix}:{c['id']}")] for c in cats]
    rows.append([btn("🔙 محصولات", "admin:products")])
    return kb(rows)

def admin_stockmode_menu(prod_id):
    return kb([
        [btn("manual - بررسی دستی ادمین", f"admin:prod_stockmode_set:{prod_id}:manual")],
        [btn("unlimited - تحویل خودکار متن", f"admin:prod_stockmode_set:{prod_id}:unlimited")],
        [btn("text - متن موجودی/راهنما", f"admin:prod_stockmode_set:{prod_id}:text")],
        [btn("🔙 محصول", f"admin:prod:{prod_id}")]
    ])

def admin_settings_menu():
    return kb([
        [btn(f"🤖 وضعیت ربات: {get_setting('bot_status','on')}", "admin:toggle_bot")],
        [btn(f"🛒 وضعیت فروشگاه: {get_setting('shop_status','on')}", "admin:toggle_shop")],
        [btn("📝 متن شروع", "admin:set_welcome"), btn("💳 اطلاعات پرداخت", "admin:set_bank")],
        [btn("حداقل شارژ", "admin:set_min_topup"), btn("حداکثر شارژ", "admin:set_max_topup")],
        [btn("📞 پشتیبانی", "admin:set_support"), btn("📢 کانال", "admin:set_channel")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def admin_user_detail_menu(tg_id):
    return kb([
        [btn("🚫 مسدود/آزاد", f"admin:user_toggle_block:{tg_id}"), btn("👑 ادمین/عادی", f"admin:user_toggle_admin:{tg_id}")],
        [btn("💰 تغییر موجودی", f"admin:user_balance:{tg_id}"), btn("➕ افزایش موجودی", f"admin:user_add_balance:{tg_id}")],
        [btn("➖ کاهش موجودی", f"admin:user_sub_balance:{tg_id}"), btn("📜 تراکنش‌ها", f"admin:user_txs:{tg_id}")],
        [btn("🧾 سفارش‌های کاربر", f"admin:user_orders:{tg_id}")],
        [btn("🔙 کاربران", "admin:users")]
    ])

def admin_order_detail_menu(order_id):
    return kb([
        [btn("✅ انجام شد", f"admin:order_status:{order_id}:done"), btn("⏳ pending", f"admin:order_status:{order_id}:pending")],
        [btn("❌ رد شد", f"admin:order_status:{order_id}:rejected"), btn("🔄 بازگشت وجه", f"admin:order_refund:{order_id}")],
        [btn("🚚 متن تحویل", f"admin:order_delivery:{order_id}"), btn("📝 یادداشت", f"admin:order_note:{order_id}")],
        [btn("🔙 سفارش‌ها", "admin:orders")]
    ])

def admin_payment_detail_menu(pay_id):
    return kb([
        [btn("✅ تأیید و شارژ", f"admin:pay_approve:{pay_id}")],
        [btn("❌ رد درخواست", f"admin:pay_reject:{pay_id}")],
        [btn("📝 یادداشت ادمین", f"admin:pay_note:{pay_id}")],
        [btn("🔙 پرداخت‌ها", "admin:payments")]
    ])

# -------------------- Render --------------------

def render_profile(u):
    username=f"@{u['username']}" if u["username"] else "ندارد"
    return f"""👤 <b>حساب کاربری</b>

آیدی عددی: <code>{u['tg_id']}</code>
نام: {html_escape(u['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(u['balance'])}</b> تومان
تاریخ عضویت: {u['created_at']}
"""

def render_wallet(u):
    return f"""💰 <b>کیف پول</b>

موجودی فعلی شما:
<b>{money(u['balance'])}</b> تومان

برای خرید محصولات، ابتدا کیف پول را شارژ کنید.
"""

def render_category(cat):
    return f"""🛒 <b>{html_escape(cat['title'])}</b>

{html_escape(cat['description'] or '-')}

از لیست زیر محصول موردنظر را انتخاب کنید.
"""

def render_product(p):
    price=f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
    stock=p["stock_text"] or "موجودی/تحویل توسط ادمین تنظیم نشده است."
    mode=p["stock_mode"] if "stock_mode" in p.keys() else "manual"
    return f"""📦 <b>{html_escape(p['title'])}</b>

💰 قیمت: <b>{price}</b>
🏷 حالت تحویل: <code>{mode}</code>

📝 توضیحات:
{html_escape(p['description'] or '-')}

📌 وضعیت/موجودی:
{html_escape(stock)}
"""

def render_admin_home():
    s=stats()
    return f"""👑 <b>پنل مدیریت MVLite</b>

📊 کاربران: <b>{s['users']}</b>
👑 ادمین‌ها: <b>{s['admins']}</b>
🚫 مسدودها: <b>{s['blocked']}</b>
💰 مجموع موجودی کاربران: <b>{money(s['balance'])}</b> تومان

🧩 دسته‌بندی‌ها: <b>{s['categories']}</b> | فعال: <b>{s['active_categories']}</b>
📦 محصولات: <b>{s['products']}</b> | فعال: <b>{s['active_products']}</b>

🧾 سفارش‌ها: <b>{s['orders']}</b>
⏳ pending: <b>{s['pending_orders']}</b>
✅ done: <b>{s['done_orders']}</b>
❌ rejected: <b>{s['rejected_orders']}</b>

💳 درخواست شارژ: <b>{s['payments']}</b>
⏳ شارژ pending: <b>{s['pending_payments']}</b>
"""

def render_user_admin(u):
    username=f"@{u['username']}" if u["username"] else "-"
    return f"""👤 <b>مدیریت کاربر</b>

ID داخلی: <code>{u['id']}</code>
Telegram ID: <code>{u['tg_id']}</code>
نام: {html_escape(u['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(u['balance'])}</b> تومان
ادمین: {"بله 👑" if u["is_admin"] else "خیر"}
مسدود: {"بله 🚫" if u["is_blocked"] else "خیر"}
عضویت: {u['created_at']}
"""

def render_order_admin(o):
    return f"""🧾 <b>جزئیات سفارش</b>

ID: <code>{o['id']}</code>
کد: <code>{o['order_code']}</code>
کاربر: <code>{o['user_id']}</code>
محصول: {html_escape(o['product_title'] or '-')}
تعداد: {o['qty']}
مبلغ: <b>{money(o['amount'])}</b> تومان
وضعیت: <b>{o['status']}</b>
تاریخ: {o['created_at']}

تحویل:
{html_escape(o['delivery_text'] or '-')}

یادداشت:
{html_escape(o['note'] or '-')}
"""

def render_payment_admin(p):
    return f"""💳 <b>درخواست شارژ</b>

ID: <code>{p['id']}</code>
کد: <code>{p['request_code']}</code>
کاربر: <code>{p['user_id']}</code>
مبلغ: <b>{money(p['amount'])}</b> تومان
وضعیت: <b>{p['status']}</b>
نوع رسید: {p['receipt_type']}
تاریخ: {p['created_at']}

رسید/توضیح:
{html_escape(p['receipt_text'] or '-')}

File ID:
<code>{html_escape(p['receipt_file_id'] or '-')}</code>

یادداشت ادمین:
{html_escape(p['admin_note'] or '-')}
"""

# -------------------- User Flows --------------------

def open_main(chat_id, message_id=None):
    text=get_setting("welcome_text", WELCOME_TEXT)
    if message_id: edit_message(chat_id, message_id, text, main_menu())
    else: send_message(chat_id, text, main_menu())

def handle_user_callback(chat_id, message_id, tg_id, data):
    u=get_user(tg_id)
    if data=="noop": return
    if data=="main": clear_state(tg_id); return open_main(chat_id, message_id)
    if data=="help": return edit_message(chat_id,message_id,HELP_TEXT,back_main())
    if data=="support":
        return edit_message(chat_id,message_id,
            f"📞 <b>پشتیبانی</b>\n\nSupport: {html_escape(get_setting('support_username','@Support'))}\nChannel: {html_escape(get_setting('channel_username','@Channel'))}",
            back_main())

    if data=="profile": return edit_message(chat_id,message_id,render_profile(u),back_main())

    if data=="wallet": return edit_message(chat_id,message_id,render_wallet(u),wallet_menu())

    if data=="wallet_topup":
        bank=get_setting("bank_info", BANK_INFO_DEFAULT)
        set_state(tg_id, "topup_amount")
        return edit_message(chat_id,message_id,
            f"➕ <b>شارژ کیف پول</b>\n\nابتدا مبلغ شارژ را فقط عددی ارسال کنید.\n\n💳 اطلاعات پرداخت:\n{html_escape(bank)}",
            kb([[btn("🔙 کیف پول","wallet")]]))

    if data=="wallet_txs":
        conn=db()
        rows=conn.execute("""SELECT * FROM wallet_transactions WHERE user_id=?
                             ORDER BY id DESC LIMIT 15""", (tg_id,)).fetchall()
        conn.close()
        if not rows: text="📜 تراکنشی ثبت نشده است."
        else:
            lines=["📜 <b>آخرین تراکنش‌های کیف پول</b>\n"]
            for r in rows:
                sign="+" if r["amount"]>=0 else ""
                lines.append(f"#{r['id']} | {sign}{money(r['amount'])} | {r['type']} | {r['created_at']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,wallet_menu())

    if data=="my_payments":
        conn=db()
        rows=conn.execute("""SELECT * FROM payment_requests WHERE user_id=?
                             ORDER BY id DESC LIMIT 10""", (tg_id,)).fetchall()
        conn.close()
        if not rows: text="🧾 درخواست شارژی ثبت نکرده‌اید."
        else:
            lines=["🧾 <b>درخواست‌های شارژ شما</b>\n"]
            for p in rows:
                lines.append(f"• <code>{p['request_code']}</code> | {money(p['amount'])} | {p['status']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,wallet_menu())

    if data=="buy_menu":
        if get_setting("shop_status","on")!="on":
            return edit_message(chat_id,message_id,"🛒 فروشگاه فعلاً غیرفعال است.",back_main())
        return edit_message(chat_id,message_id,"🛒 <b>بخش خرید</b>\n\nیک دسته‌بندی را انتخاب کنید:",categories_menu())

    if data.startswith("cat:"):
        cat_id=int(data.split(":")[1])
        cat, keyboard=products_menu(cat_id)
        if not cat: return edit_message(chat_id,message_id,"دسته‌بندی پیدا نشد.",back_main())
        return edit_message(chat_id,message_id,render_category(cat),keyboard)

    if data.startswith("product:"):
        prod_id=int(data.split(":")[1])
        conn=db(); p=conn.execute("SELECT * FROM products WHERE id=? AND is_active=1",(prod_id,)).fetchone(); conn.close()
        if not p: return edit_message(chat_id,message_id,"محصول پیدا نشد یا غیرفعال است.",back_main())
        return edit_message(chat_id,message_id,render_product(p),product_buy_menu(prod_id))

    if data.startswith("buy_confirm:"):
        prod_id=int(data.split(":")[1])
        conn=db()
        p=conn.execute("SELECT * FROM products WHERE id=? AND is_active=1",(prod_id,)).fetchone()
        user=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if not p:
            conn.close(); return edit_message(chat_id,message_id,"محصول پیدا نشد.",back_main())
        if p["price"] <= 0:
            conn.close(); return edit_message(chat_id,message_id,"برای این محصول قیمت تنظیم نشده است.",back_main())
        if user["balance"] < p["price"]:
            conn.close()
            return edit_message(chat_id,message_id,
                f"❌ موجودی کافی نیست.\n\nقیمت: {money(p['price'])} تومان\nموجودی شما: {money(user['balance'])} تومان",
                kb([[btn("➕ شارژ کیف پول","wallet_topup")],[btn("🔙 برگشت",f"product:{prod_id}")]]))
        code=short_code("MV")
        mode=p["stock_mode"] or "manual"
        status="done" if mode=="unlimited" else "pending"
        delivery = p["delivery_text"] if mode=="unlimited" else ""
        conn.execute("UPDATE users SET balance=balance-? WHERE tg_id=?", (p["price"], tg_id))
        conn.execute("""INSERT INTO orders(order_code,user_id,product_id,amount,status,note,qty,delivery_text,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?)""",
                     (code,tg_id,prod_id,p["price"],status,"خرید با کیف پول",1,delivery,now(),now()))
        order_id=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        add_wallet_tx(conn,tg_id,-p["price"],"purchase","order",order_id,f"خرید {p['title']}")
        conn.commit(); conn.close()
        text=f"✅ سفارش ثبت شد.\n\nکد سفارش: <code>{code}</code>\nوضعیت: <b>{status}</b>"
        if delivery:
            text += f"\n\n🚚 تحویل:\n{html_escape(delivery)}"
        return edit_message(chat_id,message_id,text,kb([[btn("📦 سفارش‌های من","my_orders")],[btn("🏠 خانه","main")]]))

    if data=="my_orders":
        return show_my_orders(chat_id,message_id,tg_id)

    if data.startswith("my_order:"):
        order_id=int(data.split(":")[1])
        conn=db()
        o=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                          LEFT JOIN products p ON p.id=o.product_id
                          WHERE o.id=? AND o.user_id=?""", (order_id,tg_id)).fetchone()
        conn.close()
        if not o: return edit_message(chat_id,message_id,"سفارش پیدا نشد.",back_main())
        text=f"""📦 <b>جزئیات سفارش</b>

کد: <code>{o['order_code']}</code>
محصول: {html_escape(o['product_title'] or '-')}
مبلغ: <b>{money(o['amount'])}</b> تومان
وضعیت: <b>{o['status']}</b>
تاریخ: {o['created_at']}

تحویل:
{html_escape(o['delivery_text'] or 'در انتظار بررسی/تحویل')}
"""
        return edit_message(chat_id,message_id,text,kb([[btn("🔙 سفارش‌ها","my_orders")],[btn("🏠 خانه","main")]]))

def show_my_orders(chat_id,message_id,tg_id):
    conn=db()
    rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                         LEFT JOIN products p ON p.id=o.product_id
                         WHERE o.user_id=? ORDER BY o.id DESC LIMIT 10""", (tg_id,)).fetchall()
    conn.close()
    if not rows:
        return edit_message(chat_id,message_id,"📦 شما هنوز سفارشی ندارید.",back_main())
    lines=["📦 <b>سفارش‌های من</b>\n"]
    buttons=[]
    for o in rows:
        lines.append(f"• <code>{o['order_code']}</code> | {html_escape(o['product_title'] or '-')} | {o['status']}")
        buttons.append([btn(f"{o['order_code']} | {o['status']}", f"my_order:{o['id']}")])
    buttons.append([btn("🏠 خانه","main")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))

# -------------------- Admin Helpers --------------------

def show_orders(chat_id,message_id,user_filter=None):
    conn=db()
    if user_filter:
        rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                             LEFT JOIN products p ON p.id=o.product_id
                             WHERE o.user_id=? ORDER BY o.id DESC LIMIT 30""", (user_filter,)).fetchall()
    else:
        rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                             LEFT JOIN products p ON p.id=o.product_id
                             ORDER BY o.id DESC LIMIT 30""").fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"🧾 سفارشی ثبت نشده است.",admin_back())
    lines=["🧾 <b>آخرین سفارش‌ها</b>\n"]; buttons=[]
    for o in rows:
        lines.append(f"#{o['id']} | <code>{o['order_code']}</code> | user:{o['user_id']} | {html_escape(o['product_title'] or '-')} | {o['status']}")
        buttons.append([btn(f"#{o['id']} {o['status']}", f"admin:order:{o['id']}")])
    buttons.append([btn("🔙 پنل ادمین","admin:home")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))

def show_payments(chat_id,message_id,status=None):
    conn=db()
    if status:
        rows=conn.execute("SELECT * FROM payment_requests WHERE status=? ORDER BY id DESC LIMIT 30", (status,)).fetchall()
    else:
        rows=conn.execute("SELECT * FROM payment_requests ORDER BY id DESC LIMIT 30").fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"💳 درخواست شارژی ثبت نشده است.",admin_back())
    lines=["💳 <b>درخواست‌های شارژ</b>\n"]; buttons=[]
    for p in rows:
        lines.append(f"#{p['id']} | <code>{p['request_code']}</code> | user:{p['user_id']} | {money(p['amount'])} | {p['status']}")
        buttons.append([btn(f"#{p['id']} {p['status']} | {money(p['amount'])}", f"admin:pay:{p['id']}")])
    buttons.append([btn("⏳ فقط pending","admin:payments_pending")])
    buttons.append([btn("🔙 پنل ادمین","admin:home")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))

# -------------------- Admin Callback --------------------

def handle_admin_callback(chat_id,message_id,tg_id,data):
    require_admin(tg_id)

    if data=="admin:home": clear_state(tg_id); return edit_message(chat_id,message_id,render_admin_home(),admin_menu())
    if data=="admin:stats": return edit_message(chat_id,message_id,render_admin_home(),admin_menu())
    if data=="admin:payments": return show_payments(chat_id,message_id)
    if data=="admin:payments_pending": return show_payments(chat_id,message_id,"pending")

    if data.startswith("admin:pay:"):
        pay_id=int(data.split(":")[2])
        conn=db(); p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone(); conn.close()
        if not p: return edit_message(chat_id,message_id,"درخواست پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_payment_admin(p),admin_payment_detail_menu(pay_id))

    if data.startswith("admin:pay_approve:"):
        pay_id=int(data.split(":")[2])
        conn=db()
        p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone()
        if not p:
            conn.close(); return edit_message(chat_id,message_id,"درخواست پیدا نشد.",admin_back())
        if p["status"]!="pending":
            conn.close(); return edit_message(chat_id,message_id,"این درخواست قبلاً بررسی شده است.",admin_back())
        conn.execute("UPDATE payment_requests SET status='approved', reviewed_at=? WHERE id=?", (now(),pay_id))
        conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (p["amount"],p["user_id"]))
        add_wallet_tx(conn,p["user_id"],p["amount"],"topup","payment",pay_id,"تأیید شارژ توسط ادمین")
        conn.commit(); conn.close()
        log_admin(tg_id,"pay_approve",str(pay_id))
        try: send_message(p["user_id"], f"✅ درخواست شارژ شما تأیید شد.\nمبلغ: {money(p['amount'])} تومان")
        except Exception: pass
        return show_payments(chat_id,message_id,"pending")

    if data.startswith("admin:pay_reject:"):
        pay_id=int(data.split(":")[2])
        conn=db(); p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone()
        if p and p["status"]=="pending":
            conn.execute("UPDATE payment_requests SET status='rejected', reviewed_at=? WHERE id=?", (now(),pay_id))
            conn.commit()
            try: send_message(p["user_id"], f"❌ درخواست شارژ شما رد شد.\nکد: {p['request_code']}")
            except Exception: pass
        conn.close(); log_admin(tg_id,"pay_reject",str(pay_id))
        return show_payments(chat_id,message_id,"pending")

    if data.startswith("admin:pay_note:"):
        pay_id=int(data.split(":")[2]); set_state(tg_id,"pay_note",{"pay_id":pay_id})
        return edit_message(chat_id,message_id,"یادداشت ادمین برای این پرداخت را ارسال کن:",admin_back())

    # categories
    if data=="admin:cats": return edit_message(chat_id,message_id,"🧩 <b>مدیریت دسته‌بندی‌ها</b>",admin_cats_menu())
    if data=="admin:cat_add": set_state(tg_id,"cat_add_title"); return edit_message(chat_id,message_id,"نام دسته‌بندی جدید را ارسال کن:",admin_back())
    if data.startswith("admin:cat:"):
        cat_id=int(data.split(":")[2])
        conn=db(); cat=conn.execute("SELECT * FROM categories WHERE id=?", (cat_id,)).fetchone(); conn.close()
        if not cat: return edit_message(chat_id,message_id,"دسته‌بندی پیدا نشد.",admin_cats_menu())
        text=f"""🧩 <b>{html_escape(cat['title'])}</b>

ID: <code>{cat['id']}</code>
Slug: <code>{cat['slug']}</code>
وضعیت: {"فعال ✅" if cat["is_active"] else "غیرفعال ❌"}
ترتیب: {cat['sort_order']}

توضیح:
{html_escape(cat['description'] or '-')}
"""
        return edit_message(chat_id,message_id,text,admin_cat_detail_menu(cat_id))
    for prefix,state_name,prompt in [
        ("admin:cat_rename:","cat_rename","نام جدید دسته‌بندی را ارسال کن:"),
        ("admin:cat_desc:","cat_desc","توضیح جدید دسته‌بندی را ارسال کن:"),
        ("admin:cat_sort:","cat_sort","عدد ترتیب دسته را ارسال کن:")
    ]:
        if data.startswith(prefix):
            cat_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"cat_id":cat_id})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:cat_toggle:"):
        cat_id=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE categories SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (cat_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"cat_toggle",str(cat_id))
        return edit_message(chat_id,message_id,"وضعیت دسته‌بندی تغییر کرد.",admin_cats_menu())
    if data.startswith("admin:cat_delete_confirm:"):
        cat_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف این دسته مطمئنی؟ محصولاتش هم حذف می‌شوند.",kb([
            [btn("✅ بله حذف کن",f"admin:cat_delete:{cat_id}")],[btn("❌ انصراف",f"admin:cat:{cat_id}")]]))
    if data.startswith("admin:cat_delete:"):
        cat_id=int(data.split(":")[2]); conn=db()
        conn.execute("DELETE FROM products WHERE category_id=?", (cat_id,))
        conn.execute("DELETE FROM categories WHERE id=?", (cat_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"cat_delete",str(cat_id))
        return edit_message(chat_id,message_id,"دسته‌بندی حذف شد.",admin_cats_menu())

    # products
    if data=="admin:products": return edit_message(chat_id,message_id,"📦 <b>مدیریت محصولات</b>",admin_products_menu())
    if data=="admin:prod_choose_cat": return edit_message(chat_id,message_id,"اول دسته‌بندی محصول را انتخاب کن:",admin_choose_cat_for_product())
    if data.startswith("admin:prod_add_to:"):
        cat_id=int(data.split(":")[2]); set_state(tg_id,"prod_add_title",{"cat_id":cat_id})
        return edit_message(chat_id,message_id,"نام محصول جدید را ارسال کن:",admin_back())
    if data.startswith("admin:prod:"):
        prod_id=int(data.split(":")[2])
        conn=db()
        p=conn.execute("""SELECT p.*,c.title cat_title FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?""",(prod_id,)).fetchone()
        conn.close()
        if not p: return edit_message(chat_id,message_id,"محصول پیدا نشد.",admin_products_menu())
        text=f"""📦 <b>{html_escape(p['title'])}</b>

ID: <code>{p['id']}</code>
دسته: {html_escape(p['cat_title'] or '-')}
قیمت: <b>{money(p['price'])}</b> تومان
ترتیب: {p['sort_order']}
وضعیت: {"فعال ✅" if p["is_active"] else "غیرفعال ❌"}
حالت موجودی: <code>{p['stock_mode']}</code>

توضیح:
{html_escape(p['description'] or '-')}

متن موجودی:
{html_escape(p['stock_text'] or '-')}

متن تحویل:
{html_escape(p['delivery_text'] or '-')}
"""
        return edit_message(chat_id,message_id,text,admin_product_detail_menu(prod_id))
    for prefix,state_name,prompt in [
        ("admin:prod_rename:","prod_rename","نام جدید محصول را ارسال کن:"),
        ("admin:prod_price:","prod_price","قیمت جدید را فقط عددی ارسال کن:"),
        ("admin:prod_desc:","prod_desc","توضیح جدید محصول را ارسال کن:"),
        ("admin:prod_stock:","prod_stock","متن موجودی/راهنما را ارسال کن:"),
        ("admin:prod_delivery:","prod_delivery","متن تحویل خودکار را ارسال کن:"),
        ("admin:prod_sort:","prod_sort","عدد ترتیب محصول را ارسال کن:")
    ]:
        if data.startswith(prefix):
            prod_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"prod_id":prod_id})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:prod_stockmode:"):
        prod_id=int(data.split(":")[2]); return edit_message(chat_id,message_id,"حالت موجودی را انتخاب کن:",admin_stockmode_menu(prod_id))
    if data.startswith("admin:prod_stockmode_set:"):
        parts=data.split(":"); prod_id=int(parts[2]); mode=parts[3]
        conn=db(); conn.execute("UPDATE products SET stock_mode=? WHERE id=?", (mode,prod_id)); conn.commit(); conn.close()
        log_admin(tg_id,"prod_stockmode",f"{prod_id}={mode}")
        return edit_message(chat_id,message_id,"✅ حالت موجودی تغییر کرد.",admin_product_detail_menu(prod_id))
    if data.startswith("admin:prod_move:"):
        prod_id=int(data.split(":")[2]); set_state(tg_id,"prod_move_wait_cat",{"prod_id":prod_id})
        return edit_message(chat_id,message_id,"دسته‌بندی جدید محصول را انتخاب کن:",admin_choose_cat_for_product("admin:prod_move_to"))
    if data.startswith("admin:prod_move_to:"):
        cat_id=int(data.split(":")[2]); st=get_state(tg_id)
        if not st or st["name"]!="prod_move_wait_cat": return edit_message(chat_id,message_id,"وضعیت انتقال پیدا نشد.",admin_products_menu())
        prod_id=st["data"]["prod_id"]; conn=db()
        conn.execute("UPDATE products SET category_id=? WHERE id=?", (cat_id,prod_id)); conn.commit(); conn.close()
        clear_state(tg_id); log_admin(tg_id,"prod_move",f"{prod_id}->{cat_id}")
        return edit_message(chat_id,message_id,"✅ دسته محصول تغییر کرد.",admin_products_menu())
    if data.startswith("admin:prod_toggle:"):
        prod_id=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE products SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (prod_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"prod_toggle",str(prod_id))
        return edit_message(chat_id,message_id,"وضعیت محصول تغییر کرد.",admin_products_menu())
    if data.startswith("admin:prod_delete_confirm:"):
        prod_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف محصول مطمئنی؟",kb([[btn("✅ بله حذف کن",f"admin:prod_delete:{prod_id}")],[btn("❌ انصراف",f"admin:prod:{prod_id}")]]))
    if data.startswith("admin:prod_delete:"):
        prod_id=int(data.split(":")[2]); conn=db(); conn.execute("DELETE FROM products WHERE id=?", (prod_id,)); conn.commit(); conn.close()
        log_admin(tg_id,"prod_delete",str(prod_id))
        return edit_message(chat_id,message_id,"محصول حذف شد.",admin_products_menu())

    # users
    if data=="admin:users":
        conn=db(); rows=conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 25").fetchall(); conn.close()
        lines=["👥 <b>آخرین کاربران</b>\n"]
        for u in rows:
            lines.append(f"{'👑' if u['is_admin'] else ''}{'🚫' if u['is_blocked'] else ''} <code>{u['tg_id']}</code> | {html_escape(u['first_name'] or '-')} | @{html_escape(u['username'] or '-')}")
        return edit_message(chat_id,message_id,"\n".join(lines),kb([[btn("🔍 جستجوی کاربر","admin:user_search")],[btn("🔙 پنل ادمین","admin:home")]]))
    if data=="admin:user_search": set_state(tg_id,"user_search"); return edit_message(chat_id,message_id,"آیدی عددی یا یوزرنیم کاربر را ارسال کن:",admin_back())
    if data.startswith("admin:user:"):
        target=int(data.split(":")[2]); u=get_user(target)
        if not u: return edit_message(chat_id,message_id,"کاربر پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_user_admin(u),admin_user_detail_menu(target))
    if data.startswith("admin:user_toggle_block:"):
        target=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE users SET is_blocked=CASE WHEN is_blocked=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit(); conn.close(); log_admin(tg_id,"user_toggle_block",str(target))
        return edit_message(chat_id,message_id,render_user_admin(get_user(target)),admin_user_detail_menu(target))
    if data.startswith("admin:user_toggle_admin:"):
        target=int(data.split(":")[2])
        if OWNER_ID and target==OWNER_ID: return edit_message(chat_id,message_id,"مالک اصلی را نمی‌شود عادی کرد.",admin_back())
        conn=db(); conn.execute("UPDATE users SET is_admin=CASE WHEN is_admin=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit(); conn.close(); log_admin(tg_id,"user_toggle_admin",str(target))
        return edit_message(chat_id,message_id,render_user_admin(get_user(target)),admin_user_detail_menu(target))
    for prefix,state_name,prompt in [
        ("admin:user_balance:","user_balance","موجودی جدید کاربر را فقط عددی ارسال کن:"),
        ("admin:user_add_balance:","user_add_balance","مبلغ افزایش موجودی را فقط عددی ارسال کن:"),
        ("admin:user_sub_balance:","user_sub_balance","مبلغ کاهش موجودی را فقط عددی ارسال کن:")
    ]:
        if data.startswith(prefix):
            target=int(data.split(":")[2]); set_state(tg_id,state_name,{"target":target})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:user_txs:"):
        target=int(data.split(":")[2]); return show_user_txs(chat_id,message_id,target)
    if data.startswith("admin:user_orders:"):
        target=int(data.split(":")[2]); return show_orders(chat_id,message_id,target)

    # orders
    if data=="admin:orders": return show_orders(chat_id,message_id)
    if data.startswith("admin:order:"):
        order_id=int(data.split(":")[2])
        conn=db()
        o=conn.execute("""SELECT o.*,p.title product_title FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.id=?""",(order_id,)).fetchone()
        conn.close()
        if not o: return edit_message(chat_id,message_id,"سفارش پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_order_admin(o),admin_order_detail_menu(order_id))
    if data.startswith("admin:order_status:"):
        parts=data.split(":"); order_id=int(parts[2]); status=parts[3]
        conn=db(); conn.execute("UPDATE orders SET status=?, updated_at=? WHERE id=?", (status,now(),order_id)); conn.commit(); conn.close()
        log_admin(tg_id,"order_status",f"{order_id}={status}")
        return show_orders(chat_id,message_id)
    if data.startswith("admin:order_refund:"):
        order_id=int(data.split(":")[2])
        conn=db()
        o=conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not o:
            conn.close(); return edit_message(chat_id,message_id,"سفارش پیدا نشد.",admin_back())
        if "REFUNDED" in (o["note"] or ""):
            conn.close(); return edit_message(chat_id,message_id,"این سفارش قبلاً بازگشت وجه شده است.",admin_back())
        conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (o["amount"],o["user_id"]))
        conn.execute("UPDATE orders SET status='refunded', note=note||? , updated_at=? WHERE id=?", ("\nREFUNDED",now(),order_id))
        add_wallet_tx(conn,o["user_id"],o["amount"],"refund","order",order_id,"بازگشت وجه سفارش")
        conn.commit(); conn.close(); log_admin(tg_id,"order_refund",str(order_id))
        try: send_message(o["user_id"], f"🔄 مبلغ سفارش <code>{o['order_code']}</code> به کیف پول شما برگشت داده شد.")
        except Exception: pass
        return show_orders(chat_id,message_id)
    for prefix,state_name,prompt in [
        ("admin:order_note:","order_note","یادداشت جدید سفارش را ارسال کن:"),
        ("admin:order_delivery:","order_delivery","متن تحویل سفارش را ارسال کن:")
    ]:
        if data.startswith(prefix):
            order_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"order_id":order_id})
            return edit_message(chat_id,message_id,prompt,admin_back())

    # settings/logs/backup
    if data=="admin:settings": return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    if data=="admin:toggle_bot":
        set_setting("bot_status","off" if get_setting("bot_status","on")=="on" else "on")
        return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    if data=="admin:toggle_shop":
        set_setting("shop_status","off" if get_setting("shop_status","on")=="on" else "on")
        return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    for cb,state,prompt in [
        ("admin:set_welcome","set_welcome","متن جدید /start را ارسال کن:"),
        ("admin:set_bank","set_bank","اطلاعات پرداخت/شماره کارت را ارسال کن:"),
        ("admin:set_min_topup","set_min_topup","حداقل مبلغ شارژ را عددی ارسال کن:"),
        ("admin:set_max_topup","set_max_topup","حداکثر مبلغ شارژ را عددی ارسال کن:"),
        ("admin:set_support","set_support","یوزرنیم پشتیبانی را ارسال کن:"),
        ("admin:set_channel","set_channel","یوزرنیم کانال را ارسال کن:"),
        ("admin:broadcast","broadcast","متن پیام همگانی را ارسال کن:")
    ]:
        if data==cb:
            set_state(tg_id,state); return edit_message(chat_id,message_id,prompt,admin_back())
    if data=="admin:logs":
        conn=db(); rows=conn.execute("SELECT * FROM admin_logs ORDER BY id DESC LIMIT 30").fetchall(); conn.close()
        if not rows: text="📜 لاگی ثبت نشده است."
        else:
            lines=["📜 <b>آخرین لاگ‌ها</b>\n"]
            for r in rows:
                lines.append(f"#{r['id']} | <code>{r['admin_tg_id']}</code> | {html_escape(r['action'])} | {html_escape(r['detail'] or '-')} | {r['created_at']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,admin_back())
    if data=="admin:backup":
        backup=f"mvlite_backup_{int(time.time())}.db"
        with open(DB_PATH,"rb") as src, open(backup,"wb") as dst: dst.write(src.read())
        send_document(chat_id, backup, "💾 بکاپ دیتابیس MVLite")
        try: os.remove(backup)
        except Exception: pass
        return edit_message(chat_id,message_id,"✅ بکاپ ارسال شد.",admin_menu())
    if data=="admin:clear_state": clear_state(tg_id); return edit_message(chat_id,message_id,"وضعیت موقت پاک شد.",admin_menu())

def show_user_txs(chat_id,message_id,target):
    conn=db()
    rows=conn.execute("SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 25",(target,)).fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"تراکنشی برای این کاربر نیست.",admin_back())
    lines=[f"📜 <b>تراکنش‌های کاربر</b>\n<code>{target}</code>\n"]
    for r in rows:
        sign="+" if r["amount"]>=0 else ""
        lines.append(f"#{r['id']} | {sign}{money(r['amount'])} | {r['type']} | {html_escape(r['note'] or '-')} | {r['created_at']}")
    return edit_message(chat_id,message_id,"\n".join(lines),admin_back())

# -------------------- State Text / Photo --------------------

def handle_state_message(chat_id,tg_id,text,message=None):
    st=get_state(tg_id)
    if not st: return False
    name=st["name"]; data=st.get("data") or {}

    if name=="topup_amount":
        amount=safe_int(only_digits(text),0)
        minv=safe_int(get_setting("min_topup","10000"),10000)
        maxv=safe_int(get_setting("max_topup","50000000"),50000000)
        if amount < minv or amount > maxv:
            send_message(chat_id,f"❌ مبلغ باید بین {money(minv)} تا {money(maxv)} تومان باشد.",wallet_menu())
            clear_state(tg_id); return True
        set_state(tg_id,"topup_receipt",{"amount":amount})
        send_message(chat_id,
            f"✅ مبلغ ثبت شد: {money(amount)} تومان\n\nحالا رسید پرداخت را به صورت متن یا عکس ارسال کن.",
            kb([[btn("🔙 کیف پول","wallet")]]))
        return True

    if name=="topup_receipt":
        amount=data["amount"]
        receipt_type="text"; receipt_text=text or ""; file_id=""
        if message and message.get("photo"):
            receipt_type="photo"
            file_id=message["photo"][-1]["file_id"]
            receipt_text=message.get("caption","")
        code=short_code("PAY")
        conn=db()
        conn.execute("""INSERT INTO payment_requests(request_code,user_id,amount,status,receipt_type,receipt_text,receipt_file_id,created_at)
                        VALUES(?,?,?,?,?,?,?,?)""", (code,tg_id,amount,"pending",receipt_type,receipt_text,file_id,now()))
        conn.commit(); conn.close()
        clear_state(tg_id)
        send_message(chat_id,f"✅ درخواست شارژ ثبت شد.\n\nکد: <code>{code}</code>\nمبلغ: {money(amount)} تومان\nوضعیت: pending",wallet_menu())
        notify_admins(f"💳 درخواست شارژ جدید\n\nکاربر: <code>{tg_id}</code>\nمبلغ: <b>{money(amount)}</b>\nکد: <code>{code}</code>")
        return True

    # admin-only states
    if not is_admin(tg_id):
        clear_state(tg_id); return False

    conn=db()
    try:
        if name=="cat_add_title":
            slug="cat_"+str(int(time.time()))
            conn.execute("INSERT INTO categories(title,slug,description,is_active,sort_order,created_at) VALUES(?,?,?,?,?,?)",(text.strip(),slug,"",1,100,now()))
            conn.commit(); log_admin(tg_id,"cat_add",text); send_message(chat_id,"✅ دسته‌بندی اضافه شد.",admin_cats_menu()); return True
        if name=="cat_rename":
            conn.execute("UPDATE categories SET title=? WHERE id=?",(text.strip(),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ نام تغییر کرد.",admin_cats_menu()); return True
        if name=="cat_desc":
            conn.execute("UPDATE categories SET description=? WHERE id=?",(text.strip(),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ توضیح تغییر کرد.",admin_cats_menu()); return True
        if name=="cat_sort":
            conn.execute("UPDATE categories SET sort_order=? WHERE id=?",(safe_int(text,100),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ ترتیب تغییر کرد.",admin_cats_menu()); return True
        if name=="prod_add_title":
            conn.execute("""INSERT INTO products(category_id,title,description,price,stock_text,is_active,sort_order,created_at,stock_mode,delivery_text,min_qty,max_qty)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (data["cat_id"],text.strip(),"",0,"",1,100,now(),"manual","",1,1))
            conn.commit(); log_admin(tg_id,"prod_add",text); send_message(chat_id,"✅ محصول اضافه شد.",admin_products_menu()); return True
        if name=="prod_rename":
            conn.execute("UPDATE products SET title=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ نام محصول تغییر کرد.",admin_products_menu()); return True
        if name=="prod_price":
            conn.execute("UPDATE products SET price=? WHERE id=?",(safe_int(only_digits(text),0),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ قیمت تغییر کرد.",admin_products_menu()); return True
        if name=="prod_desc":
            conn.execute("UPDATE products SET description=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ توضیح تغییر کرد.",admin_products_menu()); return True
        if name=="prod_stock":
            conn.execute("UPDATE products SET stock_text=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ متن موجودی تغییر کرد.",admin_products_menu()); return True
        if name=="prod_delivery":
            conn.execute("UPDATE products SET delivery_text=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ متن تحویل تغییر کرد.",admin_products_menu()); return True
        if name=="prod_sort":
            conn.execute("UPDATE products SET sort_order=? WHERE id=?",(safe_int(text,100),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ ترتیب محصول تغییر کرد.",admin_products_menu()); return True
        if name=="user_search":
            u=get_user_by_any(text)
            if not u: send_message(chat_id,"❌ کاربر پیدا نشد.",admin_back())
            else: send_message(chat_id,render_user_admin(u),admin_user_detail_menu(u["tg_id"]))
            return True
        if name=="user_balance":
            target=data["target"]; newbal=safe_int(only_digits(text),0)
            old=conn.execute("SELECT balance FROM users WHERE tg_id=?",(target,)).fetchone()["balance"]
            delta=newbal-old
            conn.execute("UPDATE users SET balance=? WHERE tg_id=?",(newbal,target))
            add_wallet_tx(conn,target,delta,"admin_set","user",target,"تنظیم موجودی توسط ادمین")
            conn.commit(); send_message(chat_id,"✅ موجودی تنظیم شد.",admin_user_detail_menu(target)); return True
        if name in ("user_add_balance","user_sub_balance"):
            target=data["target"]; amount=safe_int(only_digits(text),0)
            delta=amount if name=="user_add_balance" else -amount
            conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?",(delta,target))
            add_wallet_tx(conn,target,delta,"admin_adjust","user",target,"افزایش/کاهش دستی ادمین")
            conn.commit(); send_message(chat_id,"✅ موجودی تغییر کرد.",admin_user_detail_menu(target)); return True
        if name=="order_note":
            conn.execute("UPDATE orders SET note=?, updated_at=? WHERE id=?",(text.strip(),now(),data["order_id"])); conn.commit(); send_message(chat_id,"✅ یادداشت ثبت شد.",admin_menu()); return True
        if name=="order_delivery":
            conn.execute("UPDATE orders SET delivery_text=?, status='done', updated_at=? WHERE id=?",(text.strip(),now(),data["order_id"])); conn.commit()
            o=conn.execute("SELECT * FROM orders WHERE id=?",(data["order_id"],)).fetchone()
            send_message(chat_id,"✅ متن تحویل ثبت و سفارش done شد.",admin_menu())
            try: send_message(o["user_id"], f"✅ سفارش شما تکمیل شد.\nکد: <code>{o['order_code']}</code>\n\nتحویل:\n{html_escape(text)}")
            except Exception: pass
            return True
        if name=="pay_note":
            conn.execute("UPDATE payment_requests SET admin_note=? WHERE id=?",(text.strip(),data["pay_id"])); conn.commit(); send_message(chat_id,"✅ یادداشت پرداخت ثبت شد.",admin_menu()); return True
        if name=="set_welcome": set_setting("welcome_text",text.strip()); send_message(chat_id,"✅ متن شروع تغییر کرد.",admin_settings_menu()); return True
        if name=="set_bank": set_setting("bank_info",text.strip()); send_message(chat_id,"✅ اطلاعات پرداخت تغییر کرد.",admin_settings_menu()); return True
        if name=="set_min_topup": set_setting("min_topup",str(safe_int(only_digits(text),10000))); send_message(chat_id,"✅ حداقل شارژ تغییر کرد.",admin_settings_menu()); return True
        if name=="set_max_topup": set_setting("max_topup",str(safe_int(only_digits(text),50000000))); send_message(chat_id,"✅ حداکثر شارژ تغییر کرد.",admin_settings_menu()); return True
        if name=="set_support": set_setting("support_username",text.strip()); send_message(chat_id,"✅ پشتیبانی تغییر کرد.",admin_settings_menu()); return True
        if name=="set_channel": set_setting("channel_username",text.strip()); send_message(chat_id,"✅ کانال تغییر کرد.",admin_settings_menu()); return True
        if name=="broadcast":
            users=conn.execute("SELECT tg_id FROM users WHERE is_blocked=0").fetchall()
            clear_state(tg_id); conn.close()
            ok=fail=0; send_message(chat_id,f"📣 شروع ارسال به {len(users)} کاربر...")
            for u in users:
                try: send_message(u["tg_id"],text); ok+=1; time.sleep(0.05)
                except Exception: fail+=1
            log_admin(tg_id,"broadcast",f"ok={ok},fail={fail}")
            send_message(chat_id,f"✅ ارسال تمام شد.\nموفق: {ok}\nناموفق: {fail}",admin_menu())
            return True
    finally:
        try: conn.close()
        except Exception: pass
        clear_state(tg_id)
    return False

def notify_admins(text):
    conn=db(); admins=conn.execute("SELECT tg_id FROM users WHERE is_admin=1").fetchall(); conn.close()
    for a in admins:
        try: send_message(a["tg_id"], text)
        except Exception: pass

# -------------------- Dispatcher --------------------

def handle_message(message):
    u=upsert_user(message)
    chat_id=message["chat"]["id"]; tg_id=message["from"]["id"]
    text=message.get("text","")

    if u["is_blocked"]: return send_message(chat_id,"🚫 دسترسی شما به ربات مسدود شده است.")
    if get_setting("bot_status","on")!="on" and not is_admin(tg_id):
        return send_message(chat_id,"ربات فعلاً غیرفعال است.")

    if text=="/start": clear_state(tg_id); return open_main(chat_id)
    if text=="/help": return send_message(chat_id,HELP_TEXT,back_main())
    if text=="/claim_admin":
        conn=db(); count=conn.execute("SELECT COUNT(*) n FROM users WHERE is_admin=1").fetchone()["n"]
        if count==0 or (OWNER_ID and tg_id==OWNER_ID):
            conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?",(tg_id,)); conn.commit(); conn.close()
            return send_message(chat_id,"✅ شما ادمین شدید.\nحالا /admin را بزنید.")
        conn.close(); return send_message(chat_id,"❌ ادمین قبلاً ثبت شده است.")
    if text=="/admin":
        if not is_admin(tg_id): return send_message(chat_id,"❌ شما ادمین نیستید.\nاگر اولین اجراست، /claim_admin را بزنید.")
        clear_state(tg_id); return send_message(chat_id,render_admin_home(),admin_menu())
    if text=="/backup":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        backup=f"mvlite_backup_{int(time.time())}.db"
        with open(DB_PATH,"rb") as src, open(backup,"wb") as dst: dst.write(src.read())
        send_document(chat_id,backup,"💾 بکاپ دیتابیس")
        try: os.remove(backup)
        except Exception: pass
        return

    if handle_state_message(chat_id,tg_id,text,message): return
    return send_message(chat_id,"از منوی زیر استفاده کنید:",main_menu())

def handle_callback(callback):
    cid=callback["id"]; answer_callback(cid)
    msg=callback.get("message",{})
    chat_id=msg.get("chat",{}).get("id"); message_id=msg.get("message_id")
    tg_id=callback["from"]["id"]; data=callback.get("data","")
    upsert_user({"from":callback["from"],"chat":msg.get("chat",{})})
    try:
        if data.startswith("admin:"): return handle_admin_callback(chat_id,message_id,tg_id,data)
        return handle_user_callback(chat_id,message_id,tg_id,data)
    except PermissionError:
        return edit_message(chat_id,message_id,"❌ دسترسی ادمین ندارید.",back_main())
    except Exception as e:
        traceback.print_exc()
        return edit_message(chat_id,message_id,f"خطا:\n<code>{html_escape(repr(e))}</code>",back_main())

def polling_loop():
    print("MVLite Part 03 is running...")
    print("Use /claim_admin for first admin, then /admin")
    offset=0
    while True:
        try:
            updates=tg("getUpdates",{"timeout":30,"offset":offset,"allowed_updates":["message","callback_query"]},45)
            for upd in updates:
                offset=upd["update_id"]+1
                try:
                    if "message" in upd: handle_message(upd["message"])
                    elif "callback_query" in upd: handle_callback(upd["callback_query"])
                except Exception as inner:
                    print("UPDATE ERROR:",repr(inner)); traceback.print_exc()
        except KeyboardInterrupt:
            print("Stopped."); break
        except Exception as e:
            print("POLLING ERROR:",repr(e)); time.sleep(5)

def main():
    init_db()
    polling_loop()

if __name__=="__main__":
    main()

