#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MVLite - Part 03 Wallet / Payments / Receipts
Standalone Telegram bot without external packages.

Part 03 adds:
- wallet top-up request flow
- receipt submission as text or photo
- admin review for top-up requests
- wallet transaction ledger
- full purchase flow using wallet balance
- product stock mode: manual/unlimited/text stock
- better order creation and balance deduction
- user order detail page
- admin payment panel
- support ticket system
- admin ticket reply/close
- user ticket history
- discount coupon system
- admin coupon management
- product search for users
- coupon-based purchase discount
- stock code manager
- auto delivery using imported codes
- admin stock reports
- sales reports
- advanced bot texts manager
- admin announcements with pin-style menu
- maintenance message
- channel/social links manager
- FAQ manager
- anti-spam rate limiter
- admin database tools
- export reports as txt/csv
- user/order/payment search shortcuts
- advanced analytics dashboard
- daily/monthly/yearly reports
- admin risk center
- temporary mute system
- suspicious activity logs
- release diagnostics
- startup self-check
- database indexes
- health/admin diagnostics
- release metadata
"""

import os, json, time, sqlite3, urllib.request, urllib.error, traceback, csv, io
from datetime import datetime

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8979540158:AAGho_VCJlaYaggrhhcXQlAUm4KOv8sXfhU")
DB_PATH = os.environ.get("DB_PATH", "mixvoucher_lite.db")
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))
API = f"https://api.telegram.org/bot{BOT_TOKEN}"
STATE = {}
RATE_LIMIT = {}

APP_NAME = "MVLite"
APP_VERSION = "1.0.0"
APP_RELEASE = "MVLITE_RELEASE_1_0"
STARTED_AT = int(time.time())

WELCOME_TEXT = """سلام 👋

به ربات فروش ووچر خوش آمدید.

از منوی زیر یکی از گزینه‌ها را انتخاب کنید.
"""

HELP_TEXT = """📚 راهنما

• از بخش خرید دسته‌بندی و محصول را انتخاب کنید.
• خرید از موجودی کیف پول انجام می‌شود.
• برای افزایش موجودی از بخش کیف پول درخواست شارژ ثبت کنید.
• رسید شما توسط ادمین بررسی می‌شود.
"""

BANK_INFO_DEFAULT = """شماره کارت/حساب فروشگاه هنوز تنظیم نشده است.

ادمین می‌تواند از مسیر:
پنل ادمین ← تنظیمات ← اطلاعات پرداخت
آن را تنظیم کند.
"""

# -------------------- Utilities --------------------

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def money(n):
    try: return f"{int(n):,}"
    except Exception: return "0"

def safe_int(value, default=0):
    try: return int(str(value).strip())
    except Exception: return default

def only_digits(text):
    return "".join(ch for ch in str(text) if ch.isdigit())

def html_escape(s):
    s = "" if s is None else str(s)
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

def short_code(prefix):
    return f"{prefix}-{int(time.time())}-{os.getpid()%1000}"

# -------------------- Telegram --------------------

def tg(method, payload=None, timeout=60):
    payload = payload or {}
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        f"{API}/{method}",
        data=data,
        headers={"Content-Type":"application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            out = json.loads(raw)
            if not out.get("ok"):
                raise RuntimeError(out)
            return out["result"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Telegram HTTP {e.code}: {body}")

def answer_callback(cid, text="", show_alert=False):
    try: tg("answerCallbackQuery", {"callback_query_id":cid,"text":text,"show_alert":show_alert}, 20)
    except Exception: pass

def send_message(chat_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup: payload["reply_markup"] = reply_markup
    return tg("sendMessage", payload)

def edit_message(chat_id, message_id, text, reply_markup=None):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup: payload["reply_markup"] = reply_markup
    try:
        return tg("editMessageText", payload)
    except Exception as e:
        if "message is not modified" in str(e): return None
        raise

def send_document(chat_id, path, caption=""):
    boundary = "----MVLiteBoundary"
    with open(path, "rb") as f: file_data = f.read()
    filename = os.path.basename(path)
    body = b""
    def field(name, value):
        nonlocal body
        body += f"--{boundary}\r\n".encode()
        body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
        body += str(value).encode("utf-8") + b"\r\n"
    field("chat_id", chat_id)
    if caption: field("caption", caption)
    body += f"--{boundary}\r\n".encode()
    body += f'Content-Disposition: form-data; name="document"; filename="{filename}"\r\n'.encode()
    body += b"Content-Type: application/octet-stream\r\n\r\n" + file_data + b"\r\n"
    body += f"--{boundary}--\r\n".encode()
    req = urllib.request.Request(
        f"{API}/sendDocument", data=body,
        headers={"Content-Type":f"multipart/form-data; boundary={boundary}"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))

def kb(rows): return {"inline_keyboard": rows}
def btn(text, data): return {"text": text, "callback_data": data}

# -------------------- Database --------------------

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db(); c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tg_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        balance INTEGER DEFAULT 0,
        is_blocked INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        price INTEGER DEFAULT 0,
        stock_text TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL,
        FOREIGN KEY(category_id) REFERENCES categories(id)
    )""")

    # migrations for old DBs
    for col, ddl in [
        ("stock_mode", "ALTER TABLE products ADD COLUMN stock_mode TEXT DEFAULT 'manual'"),
        ("delivery_text", "ALTER TABLE products ADD COLUMN delivery_text TEXT DEFAULT ''"),
        ("min_qty", "ALTER TABLE products ADD COLUMN min_qty INTEGER DEFAULT 1"),
        ("max_qty", "ALTER TABLE products ADD COLUMN max_qty INTEGER DEFAULT 1"),
    ]:
        try: c.execute(ddl)
        except sqlite3.OperationalError: pass

    c.execute("""CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        product_id INTEGER,
        amount INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    for col, ddl in [
        ("qty", "ALTER TABLE orders ADD COLUMN qty INTEGER DEFAULT 1"),
        ("delivery_text", "ALTER TABLE orders ADD COLUMN delivery_text TEXT DEFAULT ''"),
        ("updated_at", "ALTER TABLE orders ADD COLUMN updated_at TEXT DEFAULT ''"),
    ]:
        try: c.execute(ddl)
        except sqlite3.OperationalError: pass

    c.execute("""CREATE TABLE IF NOT EXISTS admin_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admin_tg_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        detail TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        type TEXT NOT NULL,
        ref_type TEXT DEFAULT '',
        ref_id INTEGER DEFAULT 0,
        note TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS payment_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        status TEXT DEFAULT 'pending',
        receipt_type TEXT DEFAULT 'text',
        receipt_text TEXT DEFAULT '',
        receipt_file_id TEXT DEFAULT '',
        admin_note TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        reviewed_at TEXT DEFAULT ''
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_code TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        subject TEXT DEFAULT '',
        status TEXT DEFAULT 'open',
        created_at TEXT NOT NULL,
        updated_at TEXT DEFAULT ''
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS ticket_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        sender_type TEXT NOT NULL,
        sender_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(ticket_id) REFERENCES tickets(id)
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        title TEXT DEFAULT '',
        discount_type TEXT DEFAULT 'fixed',
        amount INTEGER DEFAULT 0,
        min_order INTEGER DEFAULT 0,
        max_uses INTEGER DEFAULT 0,
        used_count INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS coupon_usages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        coupon_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        order_id INTEGER NOT NULL,
        discount_amount INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(coupon_id) REFERENCES coupons(id)
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS product_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        code_text TEXT NOT NULL,
        status TEXT DEFAULT 'available',
        order_id INTEGER DEFAULT 0,
        used_by INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        used_at TEXT DEFAULT '',
        FOREIGN KEY(product_id) REFERENCES products(id)
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS faqs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 100,
        created_at TEXT NOT NULL
    )""")

    c.execute("""CREATE TABLE IF NOT EXISTS security_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        detail TEXT DEFAULT '',
        created_at TEXT NOT NULL
    )""")

    try:
        c.execute("ALTER TABLE users ADD COLUMN muted_until INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    try:
        c.execute("ALTER TABLE orders ADD COLUMN coupon_code TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    try:
        c.execute("ALTER TABLE orders ADD COLUMN discount_amount INTEGER DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    defaults = {
        "welcome_text": WELCOME_TEXT,
        "support_username": "@Support",
        "channel_username": "@Channel",
        "bot_status": "on",
        "shop_status": "on",
        "bank_info": BANK_INFO_DEFAULT,
        "min_topup": "10000",
        "max_topup": "50000000",
        "maintenance_text": "ربات در حال بروزرسانی است. لطفاً بعداً مراجعه کنید.",
        "announcement_text": "اطلاعیه‌ای ثبت نشده است.",
        "rules_text": "قوانین هنوز تنظیم نشده است.",
        "about_text": "ربات فروشگاهی MVLite",
        "banner_text": "🔥 فروشگاه ووچر و سرویس‌های دیجیتال",
        "instagram_url": "",
        "website_url": "",
    }
    for k,v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k,v))

    seed = [
        ("🔥 Hot Voucher", "hot_voucher", "بخش هات ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 10),
        ("💎 Premium Voucher", "premium_voucher", "بخش پریمیوم ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 20),
        ("🟣 U Voucher", "u_voucher", "بخش یو ووچر - محصولات را از پنل ادمین اضافه کنید.", 1, 30),
        ("🤖 AI Services", "ai_services", "بخش سرویس‌های هوش مصنوعی - محصولات را از پنل ادمین اضافه کنید.", 1, 40),
        ("🌐 VPN Services", "vpn_services", "بخش سرویس‌های VPN - محصولات را از پنل ادمین اضافه کنید.", 1, 50),
        ("🖥 VPS / Server", "vps_server", "بخش سرور مجازی - محصولات را از پنل ادمین اضافه کنید.", 1, 60),
    ]
    for title, slug, desc, active, order in seed:
        c.execute("""INSERT OR IGNORE INTO categories(title,slug,description,is_active,sort_order,created_at)
                     VALUES(?,?,?,?,?,?)""", (title,slug,desc,active,order,now()))

    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_users_tg_id ON users(tg_id)",
        "CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id)",
        "CREATE INDEX IF NOT EXISTS idx_products_active ON products(is_active)",
        "CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)",
        "CREATE INDEX IF NOT EXISTS idx_payments_user ON payment_requests(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_payments_status ON payment_requests(status)",
        "CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status)",
        "CREATE INDEX IF NOT EXISTS idx_codes_product_status ON product_codes(product_id,status)",
        "CREATE INDEX IF NOT EXISTS idx_wallet_user ON wallet_transactions(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_security_user ON security_events(user_id)",
    ]
    for q in indexes:
        c.execute(q)

    conn.commit(); conn.close()

def get_setting(key, default=""):
    conn=db(); row=conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone(); conn.close()
    return row["value"] if row else default

def set_setting(key,value):
    conn=db()
    conn.execute("""INSERT INTO settings(key,value) VALUES(?,?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value""", (key,value))
    conn.commit(); conn.close()

def log_admin(admin_tg_id, action, detail=""):
    conn=db()
    conn.execute("INSERT INTO admin_logs(admin_tg_id,action,detail,created_at) VALUES(?,?,?,?)",
                 (admin_tg_id, action, detail, now()))
    conn.commit(); conn.close()

def add_wallet_tx(conn, user_id, amount, typ, ref_type="", ref_id=0, note=""):
    conn.execute("""INSERT INTO wallet_transactions(user_id,amount,type,ref_type,ref_id,note,created_at)
                    VALUES(?,?,?,?,?,?,?)""", (user_id, amount, typ, ref_type, ref_id, note, now()))

def change_balance(user_id, delta, typ, ref_type="", ref_id=0, note=""):
    conn=db()
    conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (delta, user_id))
    add_wallet_tx(conn, user_id, delta, typ, ref_type, ref_id, note)
    conn.commit(); conn.close()

def upsert_user(message):
    user = message.get("from", {})
    tg_id = user.get("id")
    username = user.get("username") or ""
    first_name = user.get("first_name") or ""
    conn=db()
    conn.execute("""INSERT INTO users(tg_id,username,first_name,created_at)
                    VALUES(?,?,?,?)
                    ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name""",
                 (tg_id, username, first_name, now()))
    if OWNER_ID and tg_id == OWNER_ID:
        conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?", (tg_id,))
    conn.commit()
    row=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    conn.close(); return row

def get_user(tg_id):
    conn=db(); row=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone(); conn.close(); return row

def get_user_by_any(query):
    q=str(query).strip()
    conn=db(); row=None
    if q.startswith("@"):
        row=conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q[1:],)).fetchone()
    elif q.isdigit():
        row=conn.execute("SELECT * FROM users WHERE tg_id=? OR id=?", (int(q), int(q))).fetchone()
    else:
        row=conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)", (q,)).fetchone()
    conn.close(); return row

def is_admin(tg_id):
    u=get_user(tg_id); return bool(u and u["is_admin"])

def require_admin(tg_id):
    if not is_admin(tg_id): raise PermissionError("admin required")

def stats():
    conn=db(); data={}
    queries = {
        "users":"SELECT COUNT(*) n FROM users",
        "admins":"SELECT COUNT(*) n FROM users WHERE is_admin=1",
        "blocked":"SELECT COUNT(*) n FROM users WHERE is_blocked=1",
        "balance":"SELECT COALESCE(SUM(balance),0) n FROM users",
        "categories":"SELECT COUNT(*) n FROM categories",
        "active_categories":"SELECT COUNT(*) n FROM categories WHERE is_active=1",
        "products":"SELECT COUNT(*) n FROM products",
        "active_products":"SELECT COUNT(*) n FROM products WHERE is_active=1",
        "orders":"SELECT COUNT(*) n FROM orders",
        "pending_orders":"SELECT COUNT(*) n FROM orders WHERE status='pending'",
        "done_orders":"SELECT COUNT(*) n FROM orders WHERE status='done'",
        "rejected_orders":"SELECT COUNT(*) n FROM orders WHERE status='rejected'",
        "payments":"SELECT COUNT(*) n FROM payment_requests",
        "pending_payments":"SELECT COUNT(*) n FROM payment_requests WHERE status='pending'",
        "tickets":"SELECT COUNT(*) n FROM tickets",
        "open_tickets":"SELECT COUNT(*) n FROM tickets WHERE status='open'",
        "coupons":"SELECT COUNT(*) n FROM coupons",
        "active_coupons":"SELECT COUNT(*) n FROM coupons WHERE is_active=1",
        "available_codes":"SELECT COUNT(*) n FROM product_codes WHERE status='available'",
        "used_codes":"SELECT COUNT(*) n FROM product_codes WHERE status='used'",
        "sales_total":"SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('done','pending')",
        "faqs":"SELECT COUNT(*) n FROM faqs",
        "security_events":"SELECT COUNT(*) n FROM security_events",
        "today_sales":"SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('done','pending') AND substr(created_at,1,10)=substr(datetime('now','localtime'),1,10)",
        "month_sales":"SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('done','pending') AND substr(created_at,1,7)=substr(datetime('now','localtime'),1,7)",
    }
    for name,q in queries.items():
        data[name]=conn.execute(q).fetchone()["n"]
    conn.close(); return data

# -------------------- State --------------------

def set_state(tg_id,name,data=None): STATE[tg_id]={"name":name,"data":data or {}, "time":time.time()}
def clear_state(tg_id): STATE.pop(tg_id, None)
def get_state(tg_id): return STATE.get(tg_id)

# -------------------- Keyboards --------------------

def main_menu():
    return kb([
        [btn("🛒 خرید", "buy_menu"), btn("🔍 جستجوی محصول", "product_search")],
        [btn("👤 حساب کاربری", "profile"), btn("💰 کیف پول", "wallet")],
        [btn("📦 سفارش‌های من", "my_orders"), btn("🎟 کد تخفیف‌های من", "coupon_help")],
        [btn("📢 اطلاعیه", "announcement"), btn("📜 قوانین", "rules")],
        [btn("📞 پشتیبانی", "support"), btn("❓ سوالات متداول", "faq_menu")],
    ])

def back_main(): return kb([[btn("🔙 بازگشت به منوی اصلی", "main")]])

def wallet_menu():
    return kb([
        [btn("➕ شارژ کیف پول", "wallet_topup")],
        [btn("📜 تراکنش‌های کیف پول", "wallet_txs")],
        [btn("🧾 درخواست‌های شارژ", "my_payments")],
        [btn("🔙 منوی اصلی", "main")]
    ])

def support_menu():
    return kb([
        [btn("🎫 ثبت تیکت جدید", "ticket_new")],
        [btn("📨 تیکت‌های من", "my_tickets")],
        [btn("🔙 منوی اصلی", "main")]
    ])

def categories_menu():
    conn=db()
    rows=conn.execute("SELECT * FROM categories WHERE is_active=1 ORDER BY sort_order ASC,id ASC").fetchall()
    conn.close()
    keyboard=[]; line=[]
    for cat in rows:
        line.append(btn(cat["title"], f"cat:{cat['id']}"))
        if len(line)==2:
            keyboard.append(line); line=[]
    if line: keyboard.append(line)
    keyboard.append([btn("🔙 بازگشت", "main")])
    return kb(keyboard)

def products_menu(category_id):
    conn=db()
    cat=conn.execute("SELECT * FROM categories WHERE id=?", (category_id,)).fetchone()
    products=conn.execute("""SELECT * FROM products WHERE category_id=? AND is_active=1
                             ORDER BY sort_order ASC,id ASC""", (category_id,)).fetchall()
    conn.close()
    keyboard=[]
    for p in products:
        price = f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
        keyboard.append([btn(f"{p['title']} | {price}", f"product:{p['id']}")])
    if not products: keyboard.append([btn("فعلاً محصولی ثبت نشده", "noop")])
    keyboard.append([btn("🔙 دسته‌بندی‌ها", "buy_menu"), btn("🏠 خانه", "main")])
    return cat, kb(keyboard)

def product_buy_menu(prod_id):
    return kb([
        [btn("✅ خرید با کیف پول", f"buy_confirm:{prod_id}")],
        [btn("🔙 برگشت", f"product:{prod_id}"), btn("🏠 خانه", "main")]
    ])

def admin_menu():
    s=stats()
    pending_pay = s["pending_payments"]
    return kb([
        [btn("📊 آمار", "admin:stats"), btn("🧩 دسته‌بندی‌ها", "admin:cats")],
        [btn("📦 محصولات", "admin:products"), btn("👥 کاربران", "admin:users")],
        [btn(f"💳 پرداخت‌ها ({pending_pay})", "admin:payments"), btn("🧾 سفارش‌ها", "admin:orders")],
        [btn("📜 لاگ‌ها", "admin:logs"), btn("⚙️ تنظیمات", "admin:settings")],
        [btn("📣 پیام همگانی", "admin:broadcast"), btn("💾 بکاپ دیتابیس", "admin:backup")],
        [btn("🏠 منوی کاربر", "main")],
    ])

def admin_back(): return kb([[btn("🔙 پنل ادمین", "admin:home")]])

def admin_cats_menu():
    conn=db(); cats=conn.execute("SELECT * FROM categories ORDER BY sort_order ASC,id ASC").fetchall(); conn.close()
    rows=[[btn("➕ افزودن دسته‌بندی", "admin:cat_add")]]
    for c in cats:
        rows.append([btn(f"{'✅' if c['is_active'] else '❌'} {c['sort_order']} | {c['title']}", f"admin:cat:{c['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_cat_detail_menu(cat_id):
    return kb([
        [btn("✏️ نام", f"admin:cat_rename:{cat_id}"), btn("🔢 ترتیب", f"admin:cat_sort:{cat_id}")],
        [btn("📝 توضیح", f"admin:cat_desc:{cat_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:cat_toggle:{cat_id}")],
        [btn("➕ افزودن محصول", f"admin:prod_add_to:{cat_id}")],
        [btn("🗑 حذف دسته", f"admin:cat_delete_confirm:{cat_id}")],
        [btn("🔙 دسته‌بندی‌ها", "admin:cats")]
    ])

def admin_products_menu():
    conn=db()
    products=conn.execute("""SELECT p.*,c.title cat_title FROM products p
                             LEFT JOIN categories c ON c.id=p.category_id
                             ORDER BY p.id DESC LIMIT 80""").fetchall()
    conn.close()
    rows=[[btn("➕ افزودن محصول", "admin:prod_choose_cat")]]
    for p in products:
        rows.append([btn(f"{'✅' if p['is_active'] else '❌'} #{p['id']} {p['title']} | {money(p['price'])}", f"admin:prod:{p['id']}")])
    rows.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(rows)

def admin_product_detail_menu(prod_id):
    return kb([
        [btn("✏️ نام", f"admin:prod_rename:{prod_id}"), btn("💰 قیمت", f"admin:prod_price:{prod_id}")],
        [btn("📝 توضیح", f"admin:prod_desc:{prod_id}"), btn("📦 متن موجودی", f"admin:prod_stock:{prod_id}")],
        [btn("🚚 متن تحویل", f"admin:prod_delivery:{prod_id}"), btn("🏷 حالت موجودی", f"admin:prod_stockmode:{prod_id}")],
        [btn("🔢 ترتیب", f"admin:prod_sort:{prod_id}"), btn("📂 تغییر دسته", f"admin:prod_move:{prod_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:prod_toggle:{prod_id}")],
        [btn("🗑 حذف محصول", f"admin:prod_delete_confirm:{prod_id}")],
        [btn("🔙 محصولات", "admin:products")]
    ])

def admin_choose_cat_for_product(prefix="admin:prod_add_to"):
    conn=db(); cats=conn.execute("SELECT * FROM categories ORDER BY sort_order ASC,id ASC").fetchall(); conn.close()
    rows=[[btn(c["title"], f"{prefix}:{c['id']}")] for c in cats]
    rows.append([btn("🔙 محصولات", "admin:products")])
    return kb(rows)

def admin_stockmode_menu(prod_id):
    return kb([
        [btn("manual - بررسی دستی ادمین", f"admin:prod_stockmode_set:{prod_id}:manual")],
        [btn("unlimited - تحویل خودکار متن", f"admin:prod_stockmode_set:{prod_id}:unlimited")],
        [btn("text - متن موجودی/راهنما", f"admin:prod_stockmode_set:{prod_id}:text")],
        [btn("code - تحویل خودکار از کدها", f"admin:prod_stockmode_set:{prod_id}:code")],
        [btn("🔙 محصول", f"admin:prod:{prod_id}")]
    ])

def admin_settings_menu():
    return kb([
        [btn(f"🤖 وضعیت ربات: {get_setting('bot_status','on')}", "admin:toggle_bot")],
        [btn(f"🛒 وضعیت فروشگاه: {get_setting('shop_status','on')}", "admin:toggle_shop")],
        [btn("📝 متن شروع", "admin:set_welcome"), btn("💳 اطلاعات پرداخت", "admin:set_bank")],
        [btn("حداقل شارژ", "admin:set_min_topup"), btn("حداکثر شارژ", "admin:set_max_topup")],
        [btn("📞 پشتیبانی", "admin:set_support"), btn("📢 کانال", "admin:set_channel")],
        [btn("🌐 وب‌سایت", "admin:set_website"), btn("📸 اینستاگرام", "admin:set_instagram")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def admin_user_detail_menu(tg_id):
    return kb([
        [btn("🚫 مسدود/آزاد", f"admin:user_toggle_block:{tg_id}"), btn("👑 ادمین/عادی", f"admin:user_toggle_admin:{tg_id}")],
        [btn("💰 تغییر موجودی", f"admin:user_balance:{tg_id}"), btn("➕ افزایش موجودی", f"admin:user_add_balance:{tg_id}")],
        [btn("➖ کاهش موجودی", f"admin:user_sub_balance:{tg_id}"), btn("📜 تراکنش‌ها", f"admin:user_txs:{tg_id}")],
        [btn("🧾 سفارش‌های کاربر", f"admin:user_orders:{tg_id}")],
        [btn("🔙 کاربران", "admin:users")]
    ])

def admin_order_detail_menu(order_id):
    return kb([
        [btn("✅ انجام شد", f"admin:order_status:{order_id}:done"), btn("⏳ pending", f"admin:order_status:{order_id}:pending")],
        [btn("❌ رد شد", f"admin:order_status:{order_id}:rejected"), btn("🔄 بازگشت وجه", f"admin:order_refund:{order_id}")],
        [btn("🚚 متن تحویل", f"admin:order_delivery:{order_id}"), btn("📝 یادداشت", f"admin:order_note:{order_id}")],
        [btn("🔙 سفارش‌ها", "admin:orders")]
    ])

def admin_payment_detail_menu(pay_id):
    return kb([
        [btn("✅ تأیید و شارژ", f"admin:pay_approve:{pay_id}")],
        [btn("❌ رد درخواست", f"admin:pay_reject:{pay_id}")],
        [btn("📝 یادداشت ادمین", f"admin:pay_note:{pay_id}")],
        [btn("🔙 پرداخت‌ها", "admin:payments")]
    ])

# -------------------- Render --------------------

def render_profile(u):
    username=f"@{u['username']}" if u["username"] else "ندارد"
    return f"""👤 <b>حساب کاربری</b>

آیدی عددی: <code>{u['tg_id']}</code>
نام: {html_escape(u['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(u['balance'])}</b> تومان
تاریخ عضویت: {u['created_at']}
"""

def render_wallet(u):
    return f"""💰 <b>کیف پول</b>

موجودی فعلی شما:
<b>{money(u['balance'])}</b> تومان

برای خرید محصولات، ابتدا کیف پول را شارژ کنید.
"""

def render_category(cat):
    return f"""🛒 <b>{html_escape(cat['title'])}</b>

{html_escape(cat['description'] or '-')}

از لیست زیر محصول موردنظر را انتخاب کنید.
"""

def render_product(p):
    price=f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
    stock=p["stock_text"] or "موجودی/تحویل توسط ادمین تنظیم نشده است."
    mode=p["stock_mode"] if "stock_mode" in p.keys() else "manual"
    available, used = product_stock_counts(p["id"])
    extra_stock = f"\n🔑 کد آماده: <b>{available}</b>" if mode == "code" else ""
    return f"""📦 <b>{html_escape(p['title'])}</b>

💰 قیمت: <b>{price}</b>
🏷 حالت تحویل: <code>{mode}</code>{extra_stock}

📝 توضیحات:
{html_escape(p['description'] or '-')}

📌 وضعیت/موجودی:
{html_escape(stock)}
"""

def render_admin_home():
    s=stats()
    return f"""👑 <b>پنل مدیریت MVLite</b>

📊 کاربران: <b>{s['users']}</b>
👑 ادمین‌ها: <b>{s['admins']}</b>
🚫 مسدودها: <b>{s['blocked']}</b>
💰 مجموع موجودی کاربران: <b>{money(s['balance'])}</b> تومان

🧩 دسته‌بندی‌ها: <b>{s['categories']}</b> | فعال: <b>{s['active_categories']}</b>
📦 محصولات: <b>{s['products']}</b> | فعال: <b>{s['active_products']}</b>

🧾 سفارش‌ها: <b>{s['orders']}</b>
⏳ pending: <b>{s['pending_orders']}</b>
✅ done: <b>{s['done_orders']}</b>
❌ rejected: <b>{s['rejected_orders']}</b>

💳 درخواست شارژ: <b>{s['payments']}</b>
⏳ شارژ pending: <b>{s['pending_payments']}</b>

🎫 تیکت‌ها: <b>{s['tickets']}</b>
🟢 تیکت‌های باز: <b>{s['open_tickets']}</b>

🎟 کدهای تخفیف: <b>{s['coupons']}</b>
✅ فعال: <b>{s['active_coupons']}</b>

🔑 کدهای آماده تحویل: <b>{s['available_codes']}</b>
🔐 کدهای مصرف‌شده: <b>{s['used_codes']}</b>
📈 فروش ثبت‌شده: <b>{money(s['sales_total'])}</b> تومان
📅 فروش امروز: <b>{money(s['today_sales'])}</b> تومان
🗓 فروش ماه: <b>{money(s['month_sales'])}</b> تومان
🛡 رخداد امنیتی: <b>{s['security_events']}</b>
"""

def render_user_admin(u):
    username=f"@{u['username']}" if u["username"] else "-"
    return f"""👤 <b>مدیریت کاربر</b>

ID داخلی: <code>{u['id']}</code>
Telegram ID: <code>{u['tg_id']}</code>
نام: {html_escape(u['first_name'] or '-')}
یوزرنیم: {html_escape(username)}
موجودی: <b>{money(u['balance'])}</b> تومان
ادمین: {"بله 👑" if u["is_admin"] else "خیر"}
مسدود: {"بله 🚫" if u["is_blocked"] else "خیر"}
عضویت: {u['created_at']}
"""

def render_order_admin(o):
    return f"""🧾 <b>جزئیات سفارش</b>

ID: <code>{o['id']}</code>
کد: <code>{o['order_code']}</code>
کاربر: <code>{o['user_id']}</code>
محصول: {html_escape(o['product_title'] or '-')}
تعداد: {o['qty']}
مبلغ: <b>{money(o['amount'])}</b> تومان
تخفیف: <b>{money(o['discount_amount'] if 'discount_amount' in o.keys() else 0)}</b> تومان
کد تخفیف: <code>{html_escape(o['coupon_code'] if 'coupon_code' in o.keys() else '')}</code>
وضعیت: <b>{o['status']}</b>
تاریخ: {o['created_at']}

تحویل:
{html_escape(o['delivery_text'] or '-')}

یادداشت:
{html_escape(o['note'] or '-')}
"""

def render_payment_admin(p):
    return f"""💳 <b>درخواست شارژ</b>

ID: <code>{p['id']}</code>
کد: <code>{p['request_code']}</code>
کاربر: <code>{p['user_id']}</code>
مبلغ: <b>{money(p['amount'])}</b> تومان
وضعیت: <b>{p['status']}</b>
نوع رسید: {p['receipt_type']}
تاریخ: {p['created_at']}

رسید/توضیح:
{html_escape(p['receipt_text'] or '-')}

File ID:
<code>{html_escape(p['receipt_file_id'] or '-')}</code>

یادداشت ادمین:
{html_escape(p['admin_note'] or '-')}
"""


# -------------------- Ticket Helpers --------------------

def render_ticket(t):
    return f"""🎫 <b>تیکت پشتیبانی</b>

ID: <code>{t['id']}</code>
کد: <code>{t['ticket_code']}</code>
کاربر: <code>{t['user_id']}</code>
موضوع: {html_escape(t['subject'] or '-')}
وضعیت: <b>{t['status']}</b>
تاریخ: {t['created_at']}
"""

def ticket_messages_text(ticket_id, limit=12):
    conn = db()
    rows = conn.execute("""SELECT * FROM ticket_messages
                           WHERE ticket_id=?
                           ORDER BY id DESC LIMIT ?""", (ticket_id, limit)).fetchall()
    conn.close()
    if not rows:
        return "پیامی ثبت نشده است."
    lines = []
    for r in reversed(rows):
        sender = "ادمین" if r["sender_type"] == "admin" else "کاربر"
        lines.append(f"• <b>{sender}</b> | {r['created_at']}\n{html_escape(r['message'])}")
    return "\n\n".join(lines)

def show_my_tickets(chat_id, message_id, tg_id):
    conn = db()
    rows = conn.execute("""SELECT * FROM tickets WHERE user_id=?
                           ORDER BY id DESC LIMIT 20""", (tg_id,)).fetchall()
    conn.close()
    if not rows:
        return edit_message(chat_id, message_id, "🎫 هنوز تیکتی ثبت نکرده‌اید.", support_menu())
    lines = ["🎫 <b>تیکت‌های من</b>\n"]
    buttons = []
    for t in rows:
        lines.append(f"• <code>{t['ticket_code']}</code> | {html_escape(t['subject'] or '-')} | {t['status']}")
        buttons.append([btn(f"{t['ticket_code']} | {t['status']}", f"ticket:{t['id']}")])
    buttons.append([btn("🔙 پشتیبانی", "support")])
    return edit_message(chat_id, message_id, "\n".join(lines), kb(buttons))

def show_admin_tickets(chat_id, message_id, status=None):
    conn = db()
    if status:
        rows = conn.execute("""SELECT * FROM tickets WHERE status=?
                               ORDER BY id DESC LIMIT 30""", (status,)).fetchall()
    else:
        rows = conn.execute("""SELECT * FROM tickets
                               ORDER BY id DESC LIMIT 30""").fetchall()
    conn.close()
    if not rows:
        return edit_message(chat_id, message_id, "🎫 تیکتی ثبت نشده است.", admin_back())
    lines = ["🎫 <b>تیکت‌های پشتیبانی</b>\n"]
    buttons = []
    for t in rows:
        lines.append(f"#{t['id']} | <code>{t['ticket_code']}</code> | user:{t['user_id']} | {t['status']} | {html_escape(t['subject'] or '-')}")
        buttons.append([btn(f"#{t['id']} {t['status']} | {t['ticket_code']}", f"admin:ticket:{t['id']}")])
    buttons.append([btn("🟢 فقط باز", "admin:tickets_open")])
    buttons.append([btn("🔙 پنل ادمین", "admin:home")])
    return edit_message(chat_id, message_id, "\n".join(lines), kb(buttons))

def admin_ticket_menu(ticket_id):
    return kb([
        [btn("↩️ پاسخ", f"admin:ticket_reply:{ticket_id}")],
        [btn("✅ بستن تیکت", f"admin:ticket_close:{ticket_id}"), btn("🟢 باز کردن", f"admin:ticket_open:{ticket_id}")],
        [btn("🔙 تیکت‌ها", "admin:tickets")]
    ])







# -------------------- Release / Diagnostics --------------------

def uptime_text():
    seconds = max(0, int(time.time()) - STARTED_AT)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, sec = divmod(rem, 60)
    return f"{days}d {hours}h {minutes}m {sec}s"

def startup_self_check():
    checks = []
    checks.append(("BOT_TOKEN", bool(BOT_TOKEN and ":" in BOT_TOKEN)))
    try:
        conn = db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        checks.append(("SQLite", True))
    except Exception:
        checks.append(("SQLite", False))
    checks.append(("DB_PATH", bool(DB_PATH)))
    return checks

def diagnostics_text():
    checks = startup_self_check()
    db_size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
    ok_count = sum(1 for _, ok in checks if ok)
    lines = [
        f"🧪 <b>{APP_NAME} Diagnostics</b>",
        "",
        f"Version: <code>{APP_VERSION}</code>",
        f"Release: <code>{APP_RELEASE}</code>",
        f"Uptime: <code>{uptime_text()}</code>",
        f"Database: <code>{html_escape(DB_PATH)}</code>",
        f"DB Size: <code>{db_size}</code> bytes",
        f"Checks: <b>{ok_count}/{len(checks)}</b>",
        ""
    ]
    for name, ok in checks:
        lines.append(f"{'✅' if ok else '❌'} {name}")
    return "\n".join(lines)

def release_menu():
    return kb([
        [btn("🧪 Diagnostics", "admin:diagnostics")],
        [btn("💾 Backup DB", "admin:backup")],
        [btn("📤 Export Summary", "admin:db_summary")],
        [btn("🧹 Clear Runtime State", "admin:clear_state")],
        [btn("🔙 Admin Panel", "admin:home")]
    ])

def release_notes_text():
    return f"""🚀 <b>{APP_NAME} Release {APP_VERSION}</b>

• Telegram bot with no external Python packages
• SQLite database
• Users, wallet, payments, receipts
• Products, categories, orders
• Tickets, coupons, search
• Auto-delivery stock codes
• Reports, exports, analytics
• Rate limiting and security center
• Admin diagnostics and backup

Release ID:
<code>{APP_RELEASE}</code>
"""

# -------------------- Advanced Analytics / Risk Center --------------------

def log_security_event(user_id, event_type, detail=""):
    try:
        conn = db()
        conn.execute("""INSERT INTO security_events(user_id,event_type,detail,created_at)
                        VALUES(?,?,?,?)""", (user_id,event_type,detail,now()))
        conn.commit(); conn.close()
    except Exception:
        pass

def get_mute_until(tg_id):
    try:
        u = get_user(tg_id)
        return int(u["muted_until"] or 0) if u and "muted_until" in u.keys() else 0
    except Exception:
        return 0

def mute_user_temp(tg_id, seconds=None, reason="flood"):
    seconds = seconds or safe_int(get_setting("mute_seconds","60"),60)
    until = int(time.time()) + seconds
    conn = db()
    try:
        conn.execute("UPDATE users SET muted_until=? WHERE tg_id=?", (until,tg_id))
        conn.commit()
    finally:
        conn.close()
    log_security_event(tg_id, "temp_mute", f"{reason}; seconds={seconds}")
    return until

def analytics_menu():
    return kb([
        [btn("📅 روزانه", "admin:analytics_daily"), btn("🗓 ماهانه", "admin:analytics_monthly")],
        [btn("📆 سالانه", "admin:analytics_yearly"), btn("🔥 محصولات برتر", "admin:analytics_products")],
        [btn("👥 کاربران فعال", "admin:analytics_users"), btn("🎟 کدهای تخفیف", "admin:analytics_coupons")],
        [btn("💳 پرداخت‌ها", "admin:analytics_payments"), btn("📤 خروجی گزارش TXT", "admin:analytics_export")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def security_menu():
    return kb([
        [btn("🛡 وضعیت امنیت", "admin:security_status")],
        [btn("🚨 رخدادهای اخیر", "admin:security_events")],
        [btn("🔇 کاربران mute شده", "admin:security_muted")],
        [btn("⚙️ تنظیم AntiSpam", "admin:security_settings")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def security_settings_menu():
    return kb([
        [btn("تعداد مجاز پیام", "admin:set_rate_count"), btn("بازه زمانی", "admin:set_rate_window")],
        [btn("مدت mute", "admin:set_mute_seconds"), btn("Risk Mode روشن/خاموش", "admin:toggle_risk_mode")],
        [btn("🔙 امنیت", "admin:security")]
    ])

def analytics_summary(period="all"):
    conn = db()
    where = "1=1"
    params = []
    if period == "daily":
        where = "substr(created_at,1,10)=substr(datetime('now','localtime'),1,10)"
    elif period == "monthly":
        where = "substr(created_at,1,7)=substr(datetime('now','localtime'),1,7)"
    elif period == "yearly":
        where = "substr(created_at,1,4)=substr(datetime('now','localtime'),1,4)"

    orders = conn.execute(f"SELECT COUNT(*) n FROM orders WHERE {where}", params).fetchone()["n"]
    paid = conn.execute(f"SELECT COUNT(*) n FROM orders WHERE status IN ('done','pending') AND {where}", params).fetchone()["n"]
    income = conn.execute(f"SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('done','pending') AND {where}", params).fetchone()["n"]
    discounts = conn.execute(f"SELECT COALESCE(SUM(discount_amount),0) n FROM orders WHERE {where}", params).fetchone()["n"]
    payments = conn.execute(f"SELECT COALESCE(SUM(amount),0) n FROM payment_requests WHERE status='approved' AND {where}", params).fetchone()["n"]
    new_users = conn.execute(f"SELECT COUNT(*) n FROM users WHERE {where.replace('created_at','created_at')}", params).fetchone()["n"]
    conn.close()
    title = {"daily":"روزانه","monthly":"ماهانه","yearly":"سالانه","all":"کلی"}.get(period, period)
    return f"""📊 <b>گزارش {title}</b>

🧾 کل سفارش‌ها: <b>{orders}</b>
✅ سفارش‌های مالی: <b>{paid}</b>
💰 فروش: <b>{money(income)}</b> تومان
🎟 تخفیف داده‌شده: <b>{money(discounts)}</b> تومان
💳 شارژ تأییدشده: <b>{money(payments)}</b> تومان
👥 کاربران جدید: <b>{new_users}</b>
"""

def analytics_products_text():
    conn = db()
    rows = conn.execute("""SELECT p.id, p.title, COUNT(o.id) cnt, COALESCE(SUM(o.amount),0) total,
                           COALESCE(SUM(o.discount_amount),0) discounts
                           FROM orders o
                           LEFT JOIN products p ON p.id=o.product_id
                           WHERE o.status IN ('done','pending')
                           GROUP BY o.product_id
                           ORDER BY total DESC, cnt DESC
                           LIMIT 20""").fetchall()
    conn.close()
    lines = ["🔥 <b>محصولات برتر</b>\n"]
    if not rows:
        lines.append("هنوز فروشی ثبت نشده است.")
    for r in rows:
        lines.append(f"#{r['id']} {html_escape(r['title'] or '-')} | تعداد: {r['cnt']} | فروش: {money(r['total'])} | تخفیف: {money(r['discounts'])}")
    return "\n".join(lines)

def analytics_users_text():
    conn = db()
    rows = conn.execute("""SELECT u.tg_id, u.username, u.first_name, COUNT(o.id) orders_count,
                           COALESCE(SUM(o.amount),0) total_spent
                           FROM users u
                           LEFT JOIN orders o ON o.user_id=u.tg_id AND o.status IN ('done','pending')
                           GROUP BY u.tg_id
                           ORDER BY total_spent DESC, orders_count DESC
                           LIMIT 20""").fetchall()
    conn.close()
    lines = ["👥 <b>کاربران برتر</b>\n"]
    for r in rows:
        lines.append(f"<code>{r['tg_id']}</code> | @{html_escape(r['username'] or '-')} | سفارش: {r['orders_count']} | خرید: {money(r['total_spent'])}")
    return "\n".join(lines)

def analytics_coupons_text():
    conn = db()
    rows = conn.execute("""SELECT c.code, c.title, c.used_count, COALESCE(SUM(cu.discount_amount),0) total_discount
                           FROM coupons c
                           LEFT JOIN coupon_usages cu ON cu.coupon_id=c.id
                           GROUP BY c.id
                           ORDER BY c.used_count DESC, total_discount DESC
                           LIMIT 30""").fetchall()
    conn.close()
    lines = ["🎟 <b>گزارش کدهای تخفیف</b>\n"]
    if not rows:
        lines.append("کد تخفیفی ثبت نشده است.")
    for r in rows:
        lines.append(f"<code>{html_escape(r['code'])}</code> | استفاده: {r['used_count']} | تخفیف: {money(r['total_discount'])}")
    return "\n".join(lines)

def analytics_payments_text():
    conn = db()
    rows = conn.execute("""SELECT status, COUNT(*) cnt, COALESCE(SUM(amount),0) total
                           FROM payment_requests
                           GROUP BY status
                           ORDER BY total DESC""").fetchall()
    conn.close()
    lines = ["💳 <b>تحلیل پرداخت‌ها</b>\n"]
    for r in rows:
        lines.append(f"{r['status']} | تعداد: {r['cnt']} | مبلغ: {money(r['total'])}")
    return "\n".join(lines)

def full_analytics_export_text():
    return "\n\n".join([
        analytics_summary("daily"),
        analytics_summary("monthly"),
        analytics_summary("yearly"),
        analytics_products_text(),
        analytics_users_text(),
        analytics_coupons_text(),
        analytics_payments_text(),
        low_stock_report(),
    ])

def security_status_text():
    return f"""🛡 <b>وضعیت امنیت</b>

Risk Mode: <code>{get_setting('risk_mode','on')}</code>
Rate Count: <code>{get_setting('rate_limit_count','8')}</code>
Rate Window: <code>{get_setting('rate_limit_window','10')}</code> ثانیه
Mute Seconds: <code>{get_setting('mute_seconds','60')}</code>

اگر کاربر در بازه مشخص بیش از حد پیام بدهد، موقتاً mute می‌شود.
"""

def security_events_text():
    conn = db()
    rows = conn.execute("SELECT * FROM security_events ORDER BY id DESC LIMIT 40").fetchall()
    conn.close()
    if not rows:
        return "🚨 رخداد امنیتی ثبت نشده است."
    lines = ["🚨 <b>رخدادهای امنیتی اخیر</b>\n"]
    for r in rows:
        lines.append(f"#{r['id']} | user:<code>{r['user_id']}</code> | {html_escape(r['event_type'])} | {html_escape(r['detail'] or '-')} | {r['created_at']}")
    return "\n".join(lines)

def muted_users_text():
    ts = int(time.time())
    conn = db()
    rows = conn.execute("SELECT * FROM users WHERE muted_until>? ORDER BY muted_until DESC LIMIT 40", (ts,)).fetchall()
    conn.close()
    if not rows:
        return "🔇 کاربر mute شده‌ای وجود ندارد."
    lines = ["🔇 <b>کاربران mute شده</b>\n"]
    for u in rows:
        remain = int(u["muted_until"]) - ts
        lines.append(f"<code>{u['tg_id']}</code> | @{html_escape(u['username'] or '-')} | باقی‌مانده: {remain}s")
    return "\n".join(lines)

# -------------------- Security / Export / Tools --------------------

def rate_limited(tg_id, limit=None, window=None):
    if is_admin(tg_id):
        return False
    if get_setting("risk_mode","on") != "on":
        return False
    mute_until = get_mute_until(tg_id)
    if mute_until and int(time.time()) < mute_until:
        return True
    limit = limit or safe_int(get_setting("rate_limit_count","8"),8)
    window = window or safe_int(get_setting("rate_limit_window","10"),10)
    t = time.time()
    bucket = RATE_LIMIT.get(tg_id, [])
    bucket = [x for x in bucket if t - x < window]
    bucket.append(t)
    RATE_LIMIT[tg_id] = bucket
    if len(bucket) > limit:
        mute_user_temp(tg_id, reason="rate_limit")
        return True
    return False

def admin_tools_menu():
    return kb([
        [btn("📤 خروجی کاربران CSV", "admin:export_users")],
        [btn("📤 خروجی سفارش‌ها CSV", "admin:export_orders")],
        [btn("📤 خروجی پرداخت‌ها CSV", "admin:export_payments")],
        [btn("📤 خروجی محصولات CSV", "admin:export_products")],
        [btn("🧾 خلاصه دیتابیس", "admin:db_summary")],
        [btn("🗑 پاکسازی لاگ‌های قدیمی", "admin:logs_clear_confirm")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def send_text_file(chat_id, filename, content, caption=""):
    path = filename
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    try:
        send_document(chat_id, path, caption)
    finally:
        try: os.remove(path)
        except Exception: pass

def rows_to_csv(headers, rows):
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(headers)
    for r in rows:
        writer.writerow([r.get(h, "") if isinstance(r, dict) else r[h] for h in headers])
    return out.getvalue()

def export_table_csv(table, headers, query):
    conn = db()
    rows = conn.execute(query).fetchall()
    conn.close()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(headers)
    for r in rows:
        writer.writerow([r[h] if h in r.keys() else "" for h in headers])
    return out.getvalue()

def db_summary_text():
    s = stats()
    conn = db()
    db_size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
    last_users = conn.execute("SELECT tg_id, username, first_name, created_at FROM users ORDER BY id DESC LIMIT 5").fetchall()
    last_orders = conn.execute("SELECT order_code, user_id, amount, status, created_at FROM orders ORDER BY id DESC LIMIT 5").fetchall()
    conn.close()
    lines = [
        "🧾 Database Summary",
        f"DB path: {DB_PATH}",
        f"DB size: {db_size} bytes",
        "",
        f"Users: {s.get('users',0)}",
        f"Products: {s.get('products',0)}",
        f"Orders: {s.get('orders',0)}",
        f"Payments: {s.get('payments',0)}",
        f"Tickets: {s.get('tickets',0)}",
        f"Available Codes: {s.get('available_codes',0)}",
        "",
        "Last Users:"
    ]
    for u in last_users:
        lines.append(f"- {u['tg_id']} | @{u['username'] or '-'} | {u['first_name'] or '-'} | {u['created_at']}")
    lines.append("")
    lines.append("Last Orders:")
    for o in last_orders:
        lines.append(f"- {o['order_code']} | user:{o['user_id']} | {o['amount']} | {o['status']} | {o['created_at']}")
    return "\n".join(lines)

def quick_search_menu():
    return kb([
        [btn("👤 جستجوی کاربر", "admin:user_search")],
        [btn("🧾 جستجوی سفارش", "admin:order_search")],
        [btn("💳 جستجوی پرداخت", "admin:payment_search")],
        [btn("📦 جستجوی محصول", "admin:product_search")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def show_product_admin_search(chat_id, query):
    q = f"%{query.strip()}%"
    conn = db()
    rows = conn.execute("""SELECT p.*, c.title cat_title FROM products p
                           LEFT JOIN categories c ON c.id=p.category_id
                           WHERE p.title LIKE ? OR p.description LIKE ? OR c.title LIKE ?
                           ORDER BY p.id DESC LIMIT 30""", (q,q,q)).fetchall()
    conn.close()
    if not rows:
        return send_message(chat_id, "محصولی پیدا نشد.", admin_back())
    lines = [f"📦 نتایج جستجوی محصول: {html_escape(query)}\n"]
    buttons = []
    for p in rows:
        lines.append(f"#{p['id']} | {html_escape(p['title'])} | {money(p['price'])} | {html_escape(p['cat_title'] or '-')}")
        buttons.append([btn(f"#{p['id']} {p['title']}", f"admin:prod:{p['id']}")])
    buttons.append([btn("🔙 جستجوی سریع", "admin:quick_search")])
    return send_message(chat_id, "\n".join(lines), kb(buttons))

def show_order_admin_search(chat_id, query):
    q = query.strip()
    conn = db()
    if q.isdigit():
        rows = conn.execute("""SELECT o.*, p.title product_title FROM orders o
                               LEFT JOIN products p ON p.id=o.product_id
                               WHERE o.id=? OR o.user_id=? OR o.order_code LIKE ?
                               ORDER BY o.id DESC LIMIT 20""", (int(q), int(q), f"%{q}%")).fetchall()
    else:
        rows = conn.execute("""SELECT o.*, p.title product_title FROM orders o
                               LEFT JOIN products p ON p.id=o.product_id
                               WHERE o.order_code LIKE ?
                               ORDER BY o.id DESC LIMIT 20""", (f"%{q}%",)).fetchall()
    conn.close()
    if not rows:
        return send_message(chat_id, "سفارشی پیدا نشد.", admin_back())
    lines = [f"🧾 نتایج جستجوی سفارش: {html_escape(q)}\n"]
    buttons = []
    for o in rows:
        lines.append(f"#{o['id']} | {o['order_code']} | user:{o['user_id']} | {money(o['amount'])} | {o['status']}")
        buttons.append([btn(f"#{o['id']} {o['order_code']}", f"admin:order:{o['id']}")])
    buttons.append([btn("🔙 جستجوی سریع", "admin:quick_search")])
    return send_message(chat_id, "\n".join(lines), kb(buttons))

def show_payment_admin_search(chat_id, query):
    q = query.strip()
    conn = db()
    if q.isdigit():
        rows = conn.execute("""SELECT * FROM payment_requests
                               WHERE id=? OR user_id=? OR request_code LIKE ?
                               ORDER BY id DESC LIMIT 20""", (int(q), int(q), f"%{q}%")).fetchall()
    else:
        rows = conn.execute("""SELECT * FROM payment_requests
                               WHERE request_code LIKE ?
                               ORDER BY id DESC LIMIT 20""", (f"%{q}%",)).fetchall()
    conn.close()
    if not rows:
        return send_message(chat_id, "پرداختی پیدا نشد.", admin_back())
    lines = [f"💳 نتایج جستجوی پرداخت: {html_escape(q)}\n"]
    buttons = []
    for p in rows:
        lines.append(f"#{p['id']} | {p['request_code']} | user:{p['user_id']} | {money(p['amount'])} | {p['status']}")
        buttons.append([btn(f"#{p['id']} {p['request_code']}", f"admin:pay:{p['id']}")])
    buttons.append([btn("🔙 جستجوی سریع", "admin:quick_search")])
    return send_message(chat_id, "\n".join(lines), kb(buttons))

# -------------------- Texts / FAQ Helpers --------------------

def texts_admin_menu():
    return kb([
        [btn("🏠 متن شروع", "admin:text_welcome"), btn("🧰 متن تعمیرات", "admin:text_maintenance")],
        [btn("📢 اطلاعیه", "admin:text_announcement"), btn("📜 قوانین", "admin:text_rules")],
        [btn("ℹ️ درباره ما", "admin:text_about"), btn("🖼 بنر متنی", "admin:text_banner")],
        [btn("🔙 پنل ادمین", "admin:home")]
    ])

def render_public_links():
    parts = []
    support = get_setting("support_username", "")
    channel = get_setting("channel_username", "")
    website = get_setting("website_url", "")
    instagram = get_setting("instagram_url", "")
    if support: parts.append(f"Support: {html_escape(support)}")
    if channel: parts.append(f"Channel: {html_escape(channel)}")
    if website: parts.append(f"Website: {html_escape(website)}")
    if instagram: parts.append(f"Instagram: {html_escape(instagram)}")
    return "\n".join(parts) if parts else "لینکی ثبت نشده است."

def faq_user_menu():
    conn = db()
    rows = conn.execute("""SELECT * FROM faqs WHERE is_active=1
                           ORDER BY sort_order ASC, id ASC LIMIT 40""").fetchall()
    conn.close()
    buttons = []
    for f in rows:
        buttons.append([btn(f["question"][:55], f"faq:{f['id']}")])
    if not rows:
        buttons.append([btn("فعلاً سوالی ثبت نشده", "noop")])
    buttons.append([btn("🔙 منوی اصلی", "main")])
    return kb(buttons)

def admin_faqs_menu():
    conn = db()
    rows = conn.execute("SELECT * FROM faqs ORDER BY sort_order ASC, id ASC LIMIT 60").fetchall()
    conn.close()
    buttons = [[btn("➕ افزودن سوال", "admin:faq_add_q")]]
    for f in rows:
        st = "✅" if f["is_active"] else "❌"
        buttons.append([btn(f"{st} {f['sort_order']} | {f['question'][:40]}", f"admin:faq:{f['id']}")])
    buttons.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(buttons)

def render_faq(f):
    return f"""❓ <b>سوال متداول</b>

ID: <code>{f['id']}</code>
سوال:
{html_escape(f['question'])}

پاسخ:
{html_escape(f['answer'])}

ترتیب: {f['sort_order']}
وضعیت: {"فعال ✅" if f["is_active"] else "غیرفعال ❌"}
"""

def admin_faq_detail_menu(faq_id):
    return kb([
        [btn("✏️ تغییر سوال", f"admin:faq_q:{faq_id}"), btn("📝 تغییر پاسخ", f"admin:faq_a:{faq_id}")],
        [btn("🔢 ترتیب", f"admin:faq_sort:{faq_id}"), btn("🔁 فعال/غیرفعال", f"admin:faq_toggle:{faq_id}")],
        [btn("🗑 حذف", f"admin:faq_delete_confirm:{faq_id}")],
        [btn("🔙 سوالات", "admin:faqs")]
    ])

# -------------------- Stock / Reports Helpers --------------------

def product_stock_counts(product_id):
    conn = db()
    available = conn.execute("SELECT COUNT(*) n FROM product_codes WHERE product_id=? AND status='available'", (product_id,)).fetchone()["n"]
    used = conn.execute("SELECT COUNT(*) n FROM product_codes WHERE product_id=? AND status='used'", (product_id,)).fetchone()["n"]
    conn.close()
    return available, used

def take_product_code(conn, product_id, order_id, user_id):
    row = conn.execute("""SELECT * FROM product_codes
                          WHERE product_id=? AND status='available'
                          ORDER BY id ASC LIMIT 1""", (product_id,)).fetchone()
    if not row:
        return ""
    conn.execute("""UPDATE product_codes
                    SET status='used', order_id=?, used_by=?, used_at=?
                    WHERE id=?""", (order_id, user_id, now(), row["id"]))
    return row["code_text"]

def admin_stock_menu():
    conn = db()
    rows = conn.execute("""SELECT p.*, c.title cat_title,
                           (SELECT COUNT(*) FROM product_codes pc WHERE pc.product_id=p.id AND pc.status='available') AS available_codes,
                           (SELECT COUNT(*) FROM product_codes pc WHERE pc.product_id=p.id AND pc.status='used') AS used_codes
                           FROM products p
                           LEFT JOIN categories c ON c.id=p.category_id
                           ORDER BY p.id DESC LIMIT 80""").fetchall()
    conn.close()
    buttons = []
    for p in rows:
        buttons.append([btn(f"#{p['id']} {p['title']} | آماده:{p['available_codes']} | مصرف:{p['used_codes']}", f"admin:stock_product:{p['id']}")])
    if not rows:
        buttons.append([btn("محصولی وجود ندارد", "noop")])
    buttons.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(buttons)

def render_stock_product(p):
    available, used = product_stock_counts(p["id"])
    return f"""🔑 <b>مدیریت موجودی کد</b>

محصول: <b>{html_escape(p['title'])}</b>
ID: <code>{p['id']}</code>
حالت موجودی: <code>{p['stock_mode']}</code>

کدهای آماده تحویل: <b>{available}</b>
کدهای مصرف‌شده: <b>{used}</b>

برای تحویل خودکار، حالت موجودی محصول را روی <code>unlimited</code> نگذار؛ در این پارت حالت <code>code</code> اضافه شده و از کدهای واردشده تحویل می‌دهد.
"""

def admin_stock_product_menu(product_id):
    return kb([
        [btn("➕ ایمپورت کدها", f"admin:stock_import:{product_id}")],
        [btn("📋 نمایش چند کد آماده", f"admin:stock_preview:{product_id}")],
        [btn("🧹 حذف کدهای آماده", f"admin:stock_clear_available:{product_id}")],
        [btn("🏷 تنظیم حالت code", f"admin:prod_stockmode_set:{product_id}:code")],
        [btn("🔙 موجودی کدها", "admin:stock")]
    ])

def render_sales_report():
    conn = db()
    total_orders = conn.execute("SELECT COUNT(*) n FROM orders").fetchone()["n"]
    paid_orders = conn.execute("SELECT COUNT(*) n FROM orders WHERE status IN ('done','pending')").fetchone()["n"]
    total_amount = conn.execute("SELECT COALESCE(SUM(amount),0) n FROM orders WHERE status IN ('done','pending')").fetchone()["n"]
    today_amount = conn.execute("""SELECT COALESCE(SUM(amount),0) n FROM orders
                                   WHERE status IN ('done','pending') AND substr(created_at,1,10)=substr(?,1,10)""", (now(),)).fetchone()["n"]
    top_products = conn.execute("""SELECT p.title, COUNT(o.id) cnt, COALESCE(SUM(o.amount),0) total
                                   FROM orders o
                                   LEFT JOIN products p ON p.id=o.product_id
                                   WHERE o.status IN ('done','pending')
                                   GROUP BY o.product_id
                                   ORDER BY total DESC, cnt DESC
                                   LIMIT 10""").fetchall()
    conn.close()
    lines = [
        "📈 <b>گزارش فروش</b>\n",
        f"کل سفارش‌ها: <b>{total_orders}</b>",
        f"سفارش‌های مالی: <b>{paid_orders}</b>",
        f"فروش کل: <b>{money(total_amount)}</b> تومان",
        f"فروش امروز: <b>{money(today_amount)}</b> تومان",
        "\n🔥 <b>محصولات پرفروش</b>"
    ]
    if not top_products:
        lines.append("هنوز فروشی ثبت نشده است.")
    else:
        for r in top_products:
            lines.append(f"• {html_escape(r['title'] or '-')} | تعداد: {r['cnt']} | مبلغ: {money(r['total'])}")
    return "\n".join(lines)

def low_stock_report():
    conn = db()
    rows = conn.execute("""SELECT p.id, p.title,
                           (SELECT COUNT(*) FROM product_codes pc WHERE pc.product_id=p.id AND pc.status='available') AS available_codes
                           FROM products p
                           WHERE p.stock_mode='code'
                           ORDER BY available_codes ASC, p.id DESC
                           LIMIT 30""").fetchall()
    conn.close()
    if not rows:
        return "⚠️ محصولی با حالت code وجود ندارد."
    lines = ["⚠️ <b>گزارش موجودی کدها</b>\n"]
    for r in rows:
        mark = "🔴" if r["available_codes"] == 0 else ("🟡" if r["available_codes"] <= 3 else "🟢")
        lines.append(f"{mark} #{r['id']} {html_escape(r['title'])} | آماده: <b>{r['available_codes']}</b>")
    return "\n".join(lines)

# -------------------- Coupon Helpers --------------------

def calc_coupon_discount(coupon, order_amount):
    if not coupon:
        return 0, "کد تخفیف پیدا نشد."
    if not coupon["is_active"]:
        return 0, "کد تخفیف غیرفعال است."
    if coupon["max_uses"] and coupon["used_count"] >= coupon["max_uses"]:
        return 0, "ظرفیت استفاده از این کد تمام شده است."
    if coupon["min_order"] and order_amount < coupon["min_order"]:
        return 0, f"حداقل مبلغ سفارش برای این کد {money(coupon['min_order'])} تومان است."
    if coupon["discount_type"] == "percent":
        discount = int(order_amount * coupon["amount"] / 100)
    else:
        discount = int(coupon["amount"])
    if discount < 0:
        discount = 0
    if discount > order_amount:
        discount = order_amount
    return discount, ""

def get_coupon_by_code(code):
    conn = db()
    row = conn.execute("SELECT * FROM coupons WHERE lower(code)=lower(?)", (code.strip(),)).fetchone()
    conn.close()
    return row

def admin_coupons_menu():
    conn = db()
    rows = conn.execute("SELECT * FROM coupons ORDER BY id DESC LIMIT 50").fetchall()
    conn.close()
    buttons = [[btn("➕ افزودن کد تخفیف", "admin:coupon_add")]]
    for c in rows:
        st = "✅" if c["is_active"] else "❌"
        kind = "%" if c["discount_type"] == "percent" else "تومان"
        buttons.append([btn(f"{st} {c['code']} | {money(c['amount'])}{kind}", f"admin:coupon:{c['id']}")])
    buttons.append([btn("🔙 پنل ادمین", "admin:home")])
    return kb(buttons)

def render_coupon(c):
    kind = "درصدی" if c["discount_type"] == "percent" else "مبلغ ثابت"
    amount = f"{c['amount']}%" if c["discount_type"] == "percent" else f"{money(c['amount'])} تومان"
    return f"""🎟 <b>کد تخفیف</b>

ID: <code>{c['id']}</code>
کد: <code>{html_escape(c['code'])}</code>
عنوان: {html_escape(c['title'] or '-')}
نوع: {kind}
مقدار: <b>{amount}</b>
حداقل سفارش: <b>{money(c['min_order'])}</b> تومان
ظرفیت: {c['max_uses'] if c['max_uses'] else 'نامحدود'}
استفاده‌شده: {c['used_count']}
وضعیت: {"فعال ✅" if c["is_active"] else "غیرفعال ❌"}
ساخته‌شده: {c['created_at']}
"""

def admin_coupon_detail_menu(coupon_id):
    return kb([
        [btn("✏️ عنوان", f"admin:coupon_title:{coupon_id}"), btn("💰 مقدار", f"admin:coupon_amount:{coupon_id}")],
        [btn("🏷 نوع ثابت", f"admin:coupon_type:{coupon_id}:fixed"), btn("٪ نوع درصدی", f"admin:coupon_type:{coupon_id}:percent")],
        [btn("حداقل سفارش", f"admin:coupon_min:{coupon_id}"), btn("ظرفیت مصرف", f"admin:coupon_max:{coupon_id}")],
        [btn("🔁 فعال/غیرفعال", f"admin:coupon_toggle:{coupon_id}")],
        [btn("🗑 حذف", f"admin:coupon_delete_confirm:{coupon_id}")],
        [btn("🔙 کدهای تخفیف", "admin:coupons")]
    ])

def show_product_search_results(chat_id, message_id, query):
    q = f"%{query.strip()}%"
    conn = db()
    rows = conn.execute("""SELECT p.*, c.title cat_title FROM products p
                           LEFT JOIN categories c ON c.id=p.category_id
                           WHERE p.is_active=1 AND (p.title LIKE ? OR p.description LIKE ? OR c.title LIKE ?)
                           ORDER BY p.sort_order ASC, p.id DESC LIMIT 20""", (q,q,q)).fetchall()
    conn.close()
    if not rows:
        return send_message(chat_id, "🔍 محصولی با این جستجو پیدا نشد.", main_menu()) if not message_id else edit_message(chat_id, message_id, "🔍 محصولی با این جستجو پیدا نشد.", back_main())
    lines = [f"🔍 <b>نتایج جستجو برای:</b> {html_escape(query)}\n"]
    buttons = []
    for p in rows:
        price = f"{money(p['price'])} تومان" if p["price"] else "قیمت توافقی"
        lines.append(f"• {html_escape(p['title'])} | {price} | {html_escape(p['cat_title'] or '-')}")
        buttons.append([btn(f"{p['title']} | {price}", f"product:{p['id']}")])
    buttons.append([btn("🏠 خانه", "main")])
    if message_id:
        return edit_message(chat_id, message_id, "\n".join(lines), kb(buttons))
    return send_message(chat_id, "\n".join(lines), kb(buttons))

# -------------------- User Flows --------------------

def open_main(chat_id, message_id=None):
    banner=get_setting("banner_text","")
    links=render_public_links()
    text=(f"{html_escape(banner)}\n\n" if banner else "") + get_setting("welcome_text", WELCOME_TEXT) + f"\n\n{links}"
    if message_id: edit_message(chat_id, message_id, text, main_menu())
    else: send_message(chat_id, text, main_menu())

def handle_user_callback(chat_id, message_id, tg_id, data):
    u=get_user(tg_id)
    if data=="noop": return

    if data=="announcement":
        return edit_message(chat_id,message_id,f"📢 <b>اطلاعیه</b>\n\n{html_escape(get_setting('announcement_text',''))}",back_main())

    if data=="rules":
        return edit_message(chat_id,message_id,f"📜 <b>قوانین</b>\n\n{html_escape(get_setting('rules_text',''))}",back_main())

    if data=="faq_menu":
        return edit_message(chat_id,message_id,"❓ <b>سوالات متداول</b>\n\nیکی از سوالات را انتخاب کنید:",faq_user_menu())

    if data.startswith("faq:"):
        faq_id=int(data.split(":")[1])
        conn=db(); f=conn.execute("SELECT * FROM faqs WHERE id=? AND is_active=1",(faq_id,)).fetchone(); conn.close()
        if not f:
            return edit_message(chat_id,message_id,"سوال پیدا نشد.",back_main())
        return edit_message(chat_id,message_id,f"❓ <b>{html_escape(f['question'])}</b>\n\n{html_escape(f['answer'])}",kb([[btn("🔙 سوالات","faq_menu")],[btn("🏠 خانه","main")]]))

    if data=="main": clear_state(tg_id); return open_main(chat_id, message_id)
    if data=="help": return edit_message(chat_id,message_id,HELP_TEXT,back_main())
    if data=="support":
        return edit_message(chat_id,message_id,
            f"📞 <b>پشتیبانی</b>\n\nSupport: {html_escape(get_setting('support_username','@Support'))}\nChannel: {html_escape(get_setting('channel_username','@Channel'))}\n\nبرای پیگیری بهتر، می‌توانید تیکت ثبت کنید.",
            support_menu())

    if data=="ticket_new":
        set_state(tg_id, "ticket_subject")
        return edit_message(chat_id,message_id,"🎫 موضوع تیکت را کوتاه ارسال کنید:",kb([[btn("🔙 پشتیبانی","support")]]))

    if data=="my_tickets":
        return show_my_tickets(chat_id,message_id,tg_id)

    if data.startswith("ticket:"):
        ticket_id=int(data.split(":")[1])
        conn=db()
        t=conn.execute("SELECT * FROM tickets WHERE id=? AND user_id=?", (ticket_id,tg_id)).fetchone()
        conn.close()
        if not t:
            return edit_message(chat_id,message_id,"تیکت پیدا نشد.",support_menu())
        text=render_ticket(t)+"\n\n<b>پیام‌ها:</b>\n"+ticket_messages_text(ticket_id)
        return edit_message(chat_id,message_id,text,kb([
            [btn("➕ افزودن پیام", f"ticket_addmsg:{ticket_id}")],
            [btn("🔙 تیکت‌های من", "my_tickets")]
        ]))

    if data.startswith("ticket_addmsg:"):
        ticket_id=int(data.split(":")[1])
        set_state(tg_id,"ticket_addmsg",{"ticket_id":ticket_id})
        return edit_message(chat_id,message_id,"پیام جدیدت را ارسال کن:",kb([[btn("🔙 تیکت‌های من","my_tickets")]]))

    if data=="product_search":
        set_state(tg_id, "product_search")
        return edit_message(chat_id,message_id,"🔍 نام محصول یا دسته‌بندی موردنظر را ارسال کن:",back_main())

    if data=="coupon_help":
        return edit_message(chat_id,message_id,
            "🎟 <b>کد تخفیف</b>\n\nاگر کد تخفیف داری، هنگام خرید محصول می‌توانی آن را وارد کنی.\nدر مرحله تأیید خرید، گزینه «بدون کد تخفیف» هم وجود دارد.",
            back_main())

    if data=="profile": return edit_message(chat_id,message_id,render_profile(u),back_main())

    if data=="wallet": return edit_message(chat_id,message_id,render_wallet(u),wallet_menu())

    if data=="wallet_topup":
        bank=get_setting("bank_info", BANK_INFO_DEFAULT)
        set_state(tg_id, "topup_amount")
        return edit_message(chat_id,message_id,
            f"➕ <b>شارژ کیف پول</b>\n\nابتدا مبلغ شارژ را فقط عددی ارسال کنید.\n\n💳 اطلاعات پرداخت:\n{html_escape(bank)}",
            kb([[btn("🔙 کیف پول","wallet")]]))

    if data=="wallet_txs":
        conn=db()
        rows=conn.execute("""SELECT * FROM wallet_transactions WHERE user_id=?
                             ORDER BY id DESC LIMIT 15""", (tg_id,)).fetchall()
        conn.close()
        if not rows: text="📜 تراکنشی ثبت نشده است."
        else:
            lines=["📜 <b>آخرین تراکنش‌های کیف پول</b>\n"]
            for r in rows:
                sign="+" if r["amount"]>=0 else ""
                lines.append(f"#{r['id']} | {sign}{money(r['amount'])} | {r['type']} | {r['created_at']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,wallet_menu())

    if data=="my_payments":
        conn=db()
        rows=conn.execute("""SELECT * FROM payment_requests WHERE user_id=?
                             ORDER BY id DESC LIMIT 10""", (tg_id,)).fetchall()
        conn.close()
        if not rows: text="🧾 درخواست شارژی ثبت نکرده‌اید."
        else:
            lines=["🧾 <b>درخواست‌های شارژ شما</b>\n"]
            for p in rows:
                lines.append(f"• <code>{p['request_code']}</code> | {money(p['amount'])} | {p['status']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,wallet_menu())

    if data=="buy_menu":
        if get_setting("shop_status","on")!="on":
            return edit_message(chat_id,message_id,"🛒 فروشگاه فعلاً غیرفعال است.",back_main())
        return edit_message(chat_id,message_id,"🛒 <b>بخش خرید</b>\n\nیک دسته‌بندی را انتخاب کنید:",categories_menu())

    if data.startswith("cat:"):
        cat_id=int(data.split(":")[1])
        cat, keyboard=products_menu(cat_id)
        if not cat: return edit_message(chat_id,message_id,"دسته‌بندی پیدا نشد.",back_main())
        return edit_message(chat_id,message_id,render_category(cat),keyboard)

    if data.startswith("product:"):
        prod_id=int(data.split(":")[1])
        conn=db(); p=conn.execute("SELECT * FROM products WHERE id=? AND is_active=1",(prod_id,)).fetchone(); conn.close()
        if not p: return edit_message(chat_id,message_id,"محصول پیدا نشد یا غیرفعال است.",back_main())
        return edit_message(chat_id,message_id,render_product(p),product_buy_menu(prod_id))

    if data.startswith("buy_confirm:"):
        prod_id=int(data.split(":")[1])
        conn=db()
        p=conn.execute("SELECT * FROM products WHERE id=? AND is_active=1",(prod_id,)).fetchone()
        user=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        conn.close()
        if not p:
            return edit_message(chat_id,message_id,"محصول پیدا نشد.",back_main())
        if p["price"] <= 0:
            return edit_message(chat_id,message_id,"برای این محصول قیمت تنظیم نشده است.",back_main())
        set_state(tg_id, "purchase_coupon", {"prod_id": prod_id})
        return edit_message(chat_id,message_id,
            f"🎟 اگر کد تخفیف داری ارسال کن.\n\nمحصول: {html_escape(p['title'])}\nقیمت: <b>{money(p['price'])}</b> تومان\nموجودی شما: <b>{money(user['balance'])}</b> تومان",
            kb([[btn("خرید بدون کد تخفیف", f"purchase_now:{prod_id}:NONE")],[btn("🔙 برگشت",f"product:{prod_id}")]]))

    if data.startswith("purchase_now:"):
        parts=data.split(":")
        prod_id=int(parts[1])
        coupon_code="" if parts[2]=="NONE" else parts[2]
        return finalize_purchase(chat_id,message_id,tg_id,prod_id,coupon_code)

    if data=="my_orders":
        return show_my_orders(chat_id,message_id,tg_id)

    if data.startswith("my_order:"):
        order_id=int(data.split(":")[1])
        conn=db()
        o=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                          LEFT JOIN products p ON p.id=o.product_id
                          WHERE o.id=? AND o.user_id=?""", (order_id,tg_id)).fetchone()
        conn.close()
        if not o: return edit_message(chat_id,message_id,"سفارش پیدا نشد.",back_main())
        text=f"""📦 <b>جزئیات سفارش</b>

کد: <code>{o['order_code']}</code>
محصول: {html_escape(o['product_title'] or '-')}
مبلغ: <b>{money(o['amount'])}</b> تومان
تخفیف: <b>{money(o['discount_amount'] if 'discount_amount' in o.keys() else 0)}</b> تومان
کد تخفیف: <code>{html_escape(o['coupon_code'] if 'coupon_code' in o.keys() else '')}</code>
وضعیت: <b>{o['status']}</b>
تاریخ: {o['created_at']}

تحویل:
{html_escape(o['delivery_text'] or 'در انتظار بررسی/تحویل')}
"""
        return edit_message(chat_id,message_id,text,kb([[btn("🔙 سفارش‌ها","my_orders")],[btn("🏠 خانه","main")]]))

def show_my_orders(chat_id,message_id,tg_id):
    conn=db()
    rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                         LEFT JOIN products p ON p.id=o.product_id
                         WHERE o.user_id=? ORDER BY o.id DESC LIMIT 10""", (tg_id,)).fetchall()
    conn.close()
    if not rows:
        return edit_message(chat_id,message_id,"📦 شما هنوز سفارشی ندارید.",back_main())
    lines=["📦 <b>سفارش‌های من</b>\n"]
    buttons=[]
    for o in rows:
        lines.append(f"• <code>{o['order_code']}</code> | {html_escape(o['product_title'] or '-')} | {o['status']}")
        buttons.append([btn(f"{o['order_code']} | {o['status']}", f"my_order:{o['id']}")])
    buttons.append([btn("🏠 خانه","main")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))


def finalize_purchase(chat_id, message_id, tg_id, prod_id, coupon_code=""):
    conn=db()
    p=conn.execute("SELECT * FROM products WHERE id=? AND is_active=1",(prod_id,)).fetchone()
    user=conn.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    if not p:
        conn.close(); return edit_message(chat_id,message_id,"محصول پیدا نشد.",back_main())
    coupon=None; discount=0; coupon_err=""
    if coupon_code:
        coupon=conn.execute("SELECT * FROM coupons WHERE lower(code)=lower(?)",(coupon_code.strip(),)).fetchone()
        discount, coupon_err = calc_coupon_discount(coupon, p["price"])
        if coupon_err:
            conn.close()
            return send_message(chat_id,f"❌ {html_escape(coupon_err)}",kb([[btn("🔙 برگشت",f"product:{prod_id}")]])) if not message_id else edit_message(chat_id,message_id,f"❌ {html_escape(coupon_err)}",kb([[btn("🔙 برگشت",f"product:{prod_id}")]]))
    final_amount = p["price"] - discount
    if user["balance"] < final_amount:
        conn.close()
        msgtxt=f"❌ موجودی کافی نیست.\n\nقیمت: {money(p['price'])} تومان\nتخفیف: {money(discount)} تومان\nقابل پرداخت: {money(final_amount)} تومان\nموجودی شما: {money(user['balance'])} تومان"
        markup=kb([[btn("➕ شارژ کیف پول","wallet_topup")],[btn("🔙 برگشت",f"product:{prod_id}")]])
        return send_message(chat_id,msgtxt,markup) if not message_id else edit_message(chat_id,message_id,msgtxt,markup)
    code=short_code("MV")
    mode=p["stock_mode"] or "manual"
    if mode == "unlimited":
        status = "done"
        delivery = p["delivery_text"] or ""
    elif mode == "code":
        available_count = conn.execute("SELECT COUNT(*) n FROM product_codes WHERE product_id=? AND status='available'", (prod_id,)).fetchone()["n"]
        if available_count <= 0:
            conn.close()
            msgtxt = "❌ موجودی کد این محصول تمام شده است. لطفاً بعداً تلاش کنید یا با پشتیبانی تماس بگیرید."
            markup = kb([[btn("📞 پشتیبانی","support")],[btn("🔙 برگشت",f"product:{prod_id}")]])
            return send_message(chat_id,msgtxt,markup) if not message_id else edit_message(chat_id,message_id,msgtxt,markup)
        status = "done"
        delivery = ""
    else:
        status = "pending"
        delivery = ""
    conn.execute("UPDATE users SET balance=balance-? WHERE tg_id=?", (final_amount, tg_id))
    conn.execute("""INSERT INTO orders(order_code,user_id,product_id,amount,status,note,qty,delivery_text,created_at,updated_at,coupon_code,discount_amount)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                 (code,tg_id,prod_id,final_amount,status,"خرید با کیف پول",1,delivery,now(),now(),coupon_code or "",discount))
    order_id=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
    if mode == "code":
        code_text = take_product_code(conn, prod_id, order_id, tg_id)
        delivery = code_text
        conn.execute("UPDATE orders SET delivery_text=? WHERE id=?", (delivery, order_id))
    add_wallet_tx(conn,tg_id,-final_amount,"purchase","order",order_id,f"خرید {p['title']}")
    if coupon and discount:
        conn.execute("UPDATE coupons SET used_count=used_count+1 WHERE id=?", (coupon["id"],))
        conn.execute("""INSERT INTO coupon_usages(coupon_id,user_id,order_id,discount_amount,created_at)
                        VALUES(?,?,?,?,?)""", (coupon["id"],tg_id,order_id,discount,now()))
    conn.commit(); conn.close()
    text=f"✅ سفارش ثبت شد.\n\nکد سفارش: <code>{code}</code>\nقیمت اصلی: {money(p['price'])} تومان\nتخفیف: {money(discount)} تومان\nپرداخت‌شده: <b>{money(final_amount)}</b> تومان\nوضعیت: <b>{status}</b>"
    if delivery:
        text += f"\n\n🚚 تحویل:\n{html_escape(delivery)}"
    markup=kb([[btn("📦 سفارش‌های من","my_orders")],[btn("🏠 خانه","main")]])
    return send_message(chat_id,text,markup) if not message_id else edit_message(chat_id,message_id,text,markup)

# -------------------- Admin Helpers --------------------

def show_orders(chat_id,message_id,user_filter=None):
    conn=db()
    if user_filter:
        rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                             LEFT JOIN products p ON p.id=o.product_id
                             WHERE o.user_id=? ORDER BY o.id DESC LIMIT 30""", (user_filter,)).fetchall()
    else:
        rows=conn.execute("""SELECT o.*,p.title product_title FROM orders o
                             LEFT JOIN products p ON p.id=o.product_id
                             ORDER BY o.id DESC LIMIT 30""").fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"🧾 سفارشی ثبت نشده است.",admin_back())
    lines=["🧾 <b>آخرین سفارش‌ها</b>\n"]; buttons=[]
    for o in rows:
        lines.append(f"#{o['id']} | <code>{o['order_code']}</code> | user:{o['user_id']} | {html_escape(o['product_title'] or '-')} | {o['status']}")
        buttons.append([btn(f"#{o['id']} {o['status']}", f"admin:order:{o['id']}")])
    buttons.append([btn("🔙 پنل ادمین","admin:home")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))

def show_payments(chat_id,message_id,status=None):
    conn=db()
    if status:
        rows=conn.execute("SELECT * FROM payment_requests WHERE status=? ORDER BY id DESC LIMIT 30", (status,)).fetchall()
    else:
        rows=conn.execute("SELECT * FROM payment_requests ORDER BY id DESC LIMIT 30").fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"💳 درخواست شارژی ثبت نشده است.",admin_back())
    lines=["💳 <b>درخواست‌های شارژ</b>\n"]; buttons=[]
    for p in rows:
        lines.append(f"#{p['id']} | <code>{p['request_code']}</code> | user:{p['user_id']} | {money(p['amount'])} | {p['status']}")
        buttons.append([btn(f"#{p['id']} {p['status']} | {money(p['amount'])}", f"admin:pay:{p['id']}")])
    buttons.append([btn("⏳ فقط pending","admin:payments_pending")])
    buttons.append([btn("🔙 پنل ادمین","admin:home")])
    return edit_message(chat_id,message_id,"\n".join(lines),kb(buttons))

# -------------------- Admin Callback --------------------

def handle_admin_callback(chat_id,message_id,tg_id,data):
    require_admin(tg_id)

    if data=="admin:home": clear_state(tg_id); return edit_message(chat_id,message_id,render_admin_home(),admin_menu())
    if data=="admin:stats": return edit_message(chat_id,message_id,render_admin_home(),admin_menu())

    if data=="admin:release":
        return edit_message(chat_id,message_id,release_notes_text(),release_menu())

    if data=="admin:diagnostics":
        return edit_message(chat_id,message_id,diagnostics_text(),release_menu())

    if data=="admin:analytics":
        return edit_message(chat_id,message_id,analytics_summary("all"),analytics_menu())

    if data=="admin:analytics_daily":
        return edit_message(chat_id,message_id,analytics_summary("daily"),analytics_menu())

    if data=="admin:analytics_monthly":
        return edit_message(chat_id,message_id,analytics_summary("monthly"),analytics_menu())

    if data=="admin:analytics_yearly":
        return edit_message(chat_id,message_id,analytics_summary("yearly"),analytics_menu())

    if data=="admin:analytics_products":
        return edit_message(chat_id,message_id,analytics_products_text(),analytics_menu())

    if data=="admin:analytics_users":
        return edit_message(chat_id,message_id,analytics_users_text(),analytics_menu())

    if data=="admin:analytics_coupons":
        return edit_message(chat_id,message_id,analytics_coupons_text(),analytics_menu())

    if data=="admin:analytics_payments":
        return edit_message(chat_id,message_id,analytics_payments_text(),analytics_menu())

    if data=="admin:analytics_export":
        send_text_file(chat_id, f"mvlite_analytics_{int(time.time())}.txt", full_analytics_export_text(), "📊 خروجی آنالیتیکس")
        return edit_message(chat_id,message_id,"✅ خروجی آنالیتیکس ارسال شد.",analytics_menu())

    if data=="admin:security":
        return edit_message(chat_id,message_id,security_status_text(),security_menu())

    if data=="admin:security_status":
        return edit_message(chat_id,message_id,security_status_text(),security_menu())

    if data=="admin:security_events":
        return edit_message(chat_id,message_id,security_events_text(),security_menu())

    if data=="admin:security_muted":
        return edit_message(chat_id,message_id,muted_users_text(),security_menu())

    if data=="admin:security_settings":
        return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات امنیت</b>",security_settings_menu())

    if data=="admin:toggle_risk_mode":
        cur=get_setting("risk_mode","on")
        set_setting("risk_mode","off" if cur=="on" else "on")
        return edit_message(chat_id,message_id,security_status_text(),security_menu())

    for cb,state,prompt in [
        ("admin:set_rate_count","set_rate_count","تعداد پیام مجاز در بازه را عددی ارسال کن:"),
        ("admin:set_rate_window","set_rate_window","بازه زمانی را به ثانیه ارسال کن:"),
        ("admin:set_mute_seconds","set_mute_seconds","مدت mute را به ثانیه ارسال کن:")
    ]:
        if data==cb:
            set_state(tg_id,state)
            return edit_message(chat_id,message_id,prompt,admin_back())

    if data=="admin:tools":
        return edit_message(chat_id,message_id,"🛠 <b>ابزارهای مدیریتی</b>",admin_tools_menu())

    if data=="admin:quick_search":
        return edit_message(chat_id,message_id,"🔎 <b>جستجوی سریع</b>\n\nیکی از گزینه‌ها را انتخاب کنید:",quick_search_menu())

    if data=="admin:order_search":
        set_state(tg_id,"admin_order_search")
        return edit_message(chat_id,message_id,"کد سفارش، ID سفارش یا آیدی کاربر را ارسال کن:",admin_back())

    if data=="admin:payment_search":
        set_state(tg_id,"admin_payment_search")
        return edit_message(chat_id,message_id,"کد پرداخت، ID پرداخت یا آیدی کاربر را ارسال کن:",admin_back())

    if data=="admin:product_search":
        set_state(tg_id,"admin_product_search")
        return edit_message(chat_id,message_id,"نام محصول یا دسته‌بندی را ارسال کن:",admin_back())

    if data=="admin:export_users":
        content=export_table_csv("users", ["id","tg_id","username","first_name","balance","is_blocked","is_admin","created_at"],
                                 "SELECT id,tg_id,username,first_name,balance,is_blocked,is_admin,created_at FROM users ORDER BY id DESC")
        send_text_file(chat_id, f"mvlite_users_{int(time.time())}.csv", content, "📤 خروجی کاربران")
        return edit_message(chat_id,message_id,"✅ خروجی کاربران ارسال شد.",admin_tools_menu())

    if data=="admin:export_orders":
        content=export_table_csv("orders", ["id","order_code","user_id","product_id","amount","status","coupon_code","discount_amount","created_at","updated_at"],
                                 "SELECT id,order_code,user_id,product_id,amount,status,coupon_code,discount_amount,created_at,updated_at FROM orders ORDER BY id DESC")
        send_text_file(chat_id, f"mvlite_orders_{int(time.time())}.csv", content, "📤 خروجی سفارش‌ها")
        return edit_message(chat_id,message_id,"✅ خروجی سفارش‌ها ارسال شد.",admin_tools_menu())

    if data=="admin:export_payments":
        content=export_table_csv("payment_requests", ["id","request_code","user_id","amount","status","receipt_type","created_at","reviewed_at"],
                                 "SELECT id,request_code,user_id,amount,status,receipt_type,created_at,reviewed_at FROM payment_requests ORDER BY id DESC")
        send_text_file(chat_id, f"mvlite_payments_{int(time.time())}.csv", content, "📤 خروجی پرداخت‌ها")
        return edit_message(chat_id,message_id,"✅ خروجی پرداخت‌ها ارسال شد.",admin_tools_menu())

    if data=="admin:export_products":
        content=export_table_csv("products", ["id","category_id","title","price","stock_mode","is_active","sort_order","created_at"],
                                 "SELECT id,category_id,title,price,stock_mode,is_active,sort_order,created_at FROM products ORDER BY id DESC")
        send_text_file(chat_id, f"mvlite_products_{int(time.time())}.csv", content, "📤 خروجی محصولات")
        return edit_message(chat_id,message_id,"✅ خروجی محصولات ارسال شد.",admin_tools_menu())

    if data=="admin:db_summary":
        send_text_file(chat_id, f"mvlite_db_summary_{int(time.time())}.txt", db_summary_text(), "🧾 خلاصه دیتابیس")
        return edit_message(chat_id,message_id,"✅ خلاصه دیتابیس ارسال شد.",admin_tools_menu())

    if data=="admin:logs_clear_confirm":
        return edit_message(chat_id,message_id,"آیا لاگ‌های ادمین پاک شوند؟",kb([
            [btn("✅ بله پاک کن","admin:logs_clear_yes")],
            [btn("❌ انصراف","admin:tools")]
        ]))

    if data=="admin:logs_clear_yes":
        conn=db(); conn.execute("DELETE FROM admin_logs"); conn.commit(); conn.close()
        log_admin(tg_id,"logs_clear","")
        return edit_message(chat_id,message_id,"✅ لاگ‌ها پاک شدند.",admin_tools_menu())

    if data=="admin:texts":
        return edit_message(chat_id,message_id,"📝 <b>مدیریت متن‌ها</b>",texts_admin_menu())

    for cb, state, title in [
        ("admin:text_welcome", "set_welcome", "متن شروع"),
        ("admin:text_maintenance", "set_maintenance", "متن تعمیرات"),
        ("admin:text_announcement", "set_announcement", "متن اطلاعیه"),
        ("admin:text_rules", "set_rules", "متن قوانین"),
        ("admin:text_about", "set_about", "متن درباره ما"),
        ("admin:text_banner", "set_banner", "متن بنر")
    ]:
        if data==cb:
            set_state(tg_id,state)
            return edit_message(chat_id,message_id,f"{title} جدید را ارسال کن:",admin_back())

    if data=="admin:faqs":
        return edit_message(chat_id,message_id,"❓ <b>مدیریت سوالات متداول</b>",admin_faqs_menu())

    if data=="admin:faq_add_q":
        set_state(tg_id,"faq_add_q")
        return edit_message(chat_id,message_id,"سوال جدید را ارسال کن:",admin_back())

    if data.startswith("admin:faq:"):
        faq_id=int(data.split(":")[2])
        conn=db(); f=conn.execute("SELECT * FROM faqs WHERE id=?",(faq_id,)).fetchone(); conn.close()
        if not f:
            return edit_message(chat_id,message_id,"سوال پیدا نشد.",admin_faqs_menu())
        return edit_message(chat_id,message_id,render_faq(f),admin_faq_detail_menu(faq_id))

    for prefix,state,prompt in [
        ("admin:faq_q:","faq_q","سوال جدید را ارسال کن:"),
        ("admin:faq_a:","faq_a","پاسخ جدید را ارسال کن:"),
        ("admin:faq_sort:","faq_sort","عدد ترتیب را ارسال کن:")
    ]:
        if data.startswith(prefix):
            faq_id=int(data.split(":")[2])
            set_state(tg_id,state,{"faq_id":faq_id})
            return edit_message(chat_id,message_id,prompt,admin_back())

    if data.startswith("admin:faq_toggle:"):
        faq_id=int(data.split(":")[2])
        conn=db(); conn.execute("UPDATE faqs SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?",(faq_id,))
        conn.commit(); conn.close()
        log_admin(tg_id,"faq_toggle",str(faq_id))
        return edit_message(chat_id,message_id,"✅ وضعیت سوال تغییر کرد.",admin_faqs_menu())

    if data.startswith("admin:faq_delete_confirm:"):
        faq_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف سوال مطمئنی؟",kb([
            [btn("✅ بله حذف کن",f"admin:faq_delete:{faq_id}")],
            [btn("❌ انصراف",f"admin:faq:{faq_id}")]
        ]))

    if data.startswith("admin:faq_delete:"):
        faq_id=int(data.split(":")[2])
        conn=db(); conn.execute("DELETE FROM faqs WHERE id=?",(faq_id,)); conn.commit(); conn.close()
        log_admin(tg_id,"faq_delete",str(faq_id))
        return edit_message(chat_id,message_id,"✅ سوال حذف شد.",admin_faqs_menu())
    if data=="admin:payments": return show_payments(chat_id,message_id)
    if data=="admin:payments_pending": return show_payments(chat_id,message_id,"pending")

    if data=="admin:stock":
        return edit_message(chat_id,message_id,"🔑 <b>مدیریت موجودی کدها</b>",admin_stock_menu())

    if data.startswith("admin:stock_product:"):
        product_id=int(data.split(":")[2])
        conn=db(); p=conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone(); conn.close()
        if not p:
            return edit_message(chat_id,message_id,"محصول پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_stock_product(p),admin_stock_product_menu(product_id))

    if data.startswith("admin:stock_import:"):
        product_id=int(data.split(":")[2])
        set_state(tg_id,"stock_import",{"product_id":product_id})
        return edit_message(chat_id,message_id,"کدها را خط‌به‌خط ارسال کن. هر خط یک کد/اکانت/متن تحویل جدا حساب می‌شود:",admin_back())

    if data.startswith("admin:stock_preview:"):
        product_id=int(data.split(":")[2])
        conn=db()
        rows=conn.execute("""SELECT * FROM product_codes
                             WHERE product_id=? AND status='available'
                             ORDER BY id ASC LIMIT 10""", (product_id,)).fetchall()
        conn.close()
        if not rows:
            return edit_message(chat_id,message_id,"کد آماده‌ای برای این محصول وجود ندارد.",admin_stock_product_menu(product_id))
        lines=["📋 <b>۱۰ کد اول آماده</b>\n"]
        for r in rows:
            lines.append(f"#{r['id']} | <code>{html_escape(r['code_text'])}</code>")
        return edit_message(chat_id,message_id,"\n".join(lines),admin_stock_product_menu(product_id))

    if data.startswith("admin:stock_clear_available:"):
        product_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا کدهای آماده این محصول حذف شوند؟ کدهای مصرف‌شده حذف نمی‌شوند.",kb([
            [btn("✅ حذف کدهای آماده",f"admin:stock_clear_available_yes:{product_id}")],
            [btn("❌ انصراف",f"admin:stock_product:{product_id}")]
        ]))

    if data.startswith("admin:stock_clear_available_yes:"):
        product_id=int(data.split(":")[2])
        conn=db(); conn.execute("DELETE FROM product_codes WHERE product_id=? AND status='available'", (product_id,))
        conn.commit(); conn.close()
        log_admin(tg_id,"stock_clear_available",str(product_id))
        return edit_message(chat_id,message_id,"✅ کدهای آماده حذف شدند.",admin_stock_menu())

    if data=="admin:reports":
        return edit_message(chat_id,message_id,render_sales_report(),kb([
            [btn("⚠️ گزارش موجودی کم", "admin:low_stock")],
            [btn("🔙 پنل ادمین", "admin:home")]
        ]))

    if data=="admin:low_stock":
        return edit_message(chat_id,message_id,low_stock_report(),kb([
            [btn("📈 گزارش فروش", "admin:reports")],
            [btn("🔙 پنل ادمین", "admin:home")]
        ]))

    if data=="admin:coupons":
        return edit_message(chat_id,message_id,"🎟 <b>مدیریت کدهای تخفیف</b>",admin_coupons_menu())

    if data=="admin:coupon_add":
        set_state(tg_id,"coupon_add_code")
        return edit_message(chat_id,message_id,"کد تخفیف جدید را انگلیسی/عددی ارسال کن. مثال: OFF10",admin_back())

    if data.startswith("admin:coupon:"):
        coupon_id=int(data.split(":")[2])
        conn=db(); c=conn.execute("SELECT * FROM coupons WHERE id=?", (coupon_id,)).fetchone(); conn.close()
        if not c:
            return edit_message(chat_id,message_id,"کد تخفیف پیدا نشد.",admin_coupons_menu())
        return edit_message(chat_id,message_id,render_coupon(c),admin_coupon_detail_menu(coupon_id))

    if data.startswith("admin:coupon_type:"):
        parts=data.split(":")
        coupon_id=int(parts[2]); typ=parts[3]
        conn=db(); conn.execute("UPDATE coupons SET discount_type=? WHERE id=?", (typ,coupon_id)); conn.commit(); conn.close()
        log_admin(tg_id,"coupon_type",f"{coupon_id}={typ}")
        return edit_message(chat_id,message_id,"✅ نوع تخفیف تغییر کرد.",admin_coupons_menu())

    if data.startswith("admin:coupon_toggle:"):
        coupon_id=int(data.split(":")[2])
        conn=db(); conn.execute("UPDATE coupons SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (coupon_id,))
        conn.commit(); conn.close()
        log_admin(tg_id,"coupon_toggle",str(coupon_id))
        return edit_message(chat_id,message_id,"✅ وضعیت کد تغییر کرد.",admin_coupons_menu())

    if data.startswith("admin:coupon_delete_confirm:"):
        coupon_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف کد تخفیف مطمئنی؟",kb([
            [btn("✅ بله حذف کن",f"admin:coupon_delete:{coupon_id}")],
            [btn("❌ انصراف",f"admin:coupon:{coupon_id}")]
        ]))

    if data.startswith("admin:coupon_delete:"):
        coupon_id=int(data.split(":")[2])
        conn=db(); conn.execute("DELETE FROM coupons WHERE id=?", (coupon_id,)); conn.commit(); conn.close()
        log_admin(tg_id,"coupon_delete",str(coupon_id))
        return edit_message(chat_id,message_id,"✅ کد تخفیف حذف شد.",admin_coupons_menu())

    for prefix,state_name,prompt in [
        ("admin:coupon_title:","coupon_title","عنوان جدید کد تخفیف را ارسال کن:"),
        ("admin:coupon_amount:","coupon_amount","مقدار تخفیف را عددی ارسال کن. برای درصد مثلاً 10 یعنی 10٪:"),
        ("admin:coupon_min:","coupon_min","حداقل مبلغ سفارش را عددی ارسال کن. برای بدون محدودیت 0:"),
        ("admin:coupon_max:","coupon_max","حداکثر تعداد استفاده را عددی ارسال کن. برای نامحدود 0:")
    ]:
        if data.startswith(prefix):
            coupon_id=int(data.split(":")[2])
            set_state(tg_id,state_name,{"coupon_id":coupon_id})
            return edit_message(chat_id,message_id,prompt,admin_back())

    if data=="admin:tickets":
        return show_admin_tickets(chat_id,message_id)

    if data=="admin:tickets_open":
        return show_admin_tickets(chat_id,message_id,"open")

    if data.startswith("admin:ticket:"):
        ticket_id=int(data.split(":")[2])
        conn=db()
        t=conn.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        conn.close()
        if not t:
            return edit_message(chat_id,message_id,"تیکت پیدا نشد.",admin_back())
        text=render_ticket(t)+"\n\n<b>پیام‌ها:</b>\n"+ticket_messages_text(ticket_id,20)
        return edit_message(chat_id,message_id,text,admin_ticket_menu(ticket_id))

    if data.startswith("admin:ticket_reply:"):
        ticket_id=int(data.split(":")[2])
        set_state(tg_id,"admin_ticket_reply",{"ticket_id":ticket_id})
        return edit_message(chat_id,message_id,"پاسخ ادمین را ارسال کن:",admin_back())

    if data.startswith("admin:ticket_close:"):
        ticket_id=int(data.split(":")[2])
        conn=db()
        t=conn.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        if t:
            conn.execute("UPDATE tickets SET status='closed', updated_at=? WHERE id=?", (now(),ticket_id))
            conn.commit()
        conn.close()
        log_admin(tg_id,"ticket_close",str(ticket_id))
        if t:
            try: send_message(t["user_id"], f"✅ تیکت <code>{t['ticket_code']}</code> بسته شد.")
            except Exception: pass
        return show_admin_tickets(chat_id,message_id,"open")

    if data.startswith("admin:ticket_open:"):
        ticket_id=int(data.split(":")[2])
        conn=db()
        t=conn.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        if t:
            conn.execute("UPDATE tickets SET status='open', updated_at=? WHERE id=?", (now(),ticket_id))
            conn.commit()
        conn.close()
        log_admin(tg_id,"ticket_open",str(ticket_id))
        return show_admin_tickets(chat_id,message_id)

    if data.startswith("admin:pay:"):
        pay_id=int(data.split(":")[2])
        conn=db(); p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone(); conn.close()
        if not p: return edit_message(chat_id,message_id,"درخواست پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_payment_admin(p),admin_payment_detail_menu(pay_id))

    if data.startswith("admin:pay_approve:"):
        pay_id=int(data.split(":")[2])
        conn=db()
        p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone()
        if not p:
            conn.close(); return edit_message(chat_id,message_id,"درخواست پیدا نشد.",admin_back())
        if p["status"]!="pending":
            conn.close(); return edit_message(chat_id,message_id,"این درخواست قبلاً بررسی شده است.",admin_back())
        conn.execute("UPDATE payment_requests SET status='approved', reviewed_at=? WHERE id=?", (now(),pay_id))
        conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (p["amount"],p["user_id"]))
        add_wallet_tx(conn,p["user_id"],p["amount"],"topup","payment",pay_id,"تأیید شارژ توسط ادمین")
        conn.commit(); conn.close()
        log_admin(tg_id,"pay_approve",str(pay_id))
        try: send_message(p["user_id"], f"✅ درخواست شارژ شما تأیید شد.\nمبلغ: {money(p['amount'])} تومان")
        except Exception: pass
        return show_payments(chat_id,message_id,"pending")

    if data.startswith("admin:pay_reject:"):
        pay_id=int(data.split(":")[2])
        conn=db(); p=conn.execute("SELECT * FROM payment_requests WHERE id=?", (pay_id,)).fetchone()
        if p and p["status"]=="pending":
            conn.execute("UPDATE payment_requests SET status='rejected', reviewed_at=? WHERE id=?", (now(),pay_id))
            conn.commit()
            try: send_message(p["user_id"], f"❌ درخواست شارژ شما رد شد.\nکد: {p['request_code']}")
            except Exception: pass
        conn.close(); log_admin(tg_id,"pay_reject",str(pay_id))
        return show_payments(chat_id,message_id,"pending")

    if data.startswith("admin:pay_note:"):
        pay_id=int(data.split(":")[2]); set_state(tg_id,"pay_note",{"pay_id":pay_id})
        return edit_message(chat_id,message_id,"یادداشت ادمین برای این پرداخت را ارسال کن:",admin_back())

    # categories
    if data=="admin:cats": return edit_message(chat_id,message_id,"🧩 <b>مدیریت دسته‌بندی‌ها</b>",admin_cats_menu())
    if data=="admin:cat_add": set_state(tg_id,"cat_add_title"); return edit_message(chat_id,message_id,"نام دسته‌بندی جدید را ارسال کن:",admin_back())
    if data.startswith("admin:cat:"):
        cat_id=int(data.split(":")[2])
        conn=db(); cat=conn.execute("SELECT * FROM categories WHERE id=?", (cat_id,)).fetchone(); conn.close()
        if not cat: return edit_message(chat_id,message_id,"دسته‌بندی پیدا نشد.",admin_cats_menu())
        text=f"""🧩 <b>{html_escape(cat['title'])}</b>

ID: <code>{cat['id']}</code>
Slug: <code>{cat['slug']}</code>
وضعیت: {"فعال ✅" if cat["is_active"] else "غیرفعال ❌"}
ترتیب: {cat['sort_order']}

توضیح:
{html_escape(cat['description'] or '-')}
"""
        return edit_message(chat_id,message_id,text,admin_cat_detail_menu(cat_id))
    for prefix,state_name,prompt in [
        ("admin:cat_rename:","cat_rename","نام جدید دسته‌بندی را ارسال کن:"),
        ("admin:cat_desc:","cat_desc","توضیح جدید دسته‌بندی را ارسال کن:"),
        ("admin:cat_sort:","cat_sort","عدد ترتیب دسته را ارسال کن:")
    ]:
        if data.startswith(prefix):
            cat_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"cat_id":cat_id})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:cat_toggle:"):
        cat_id=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE categories SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (cat_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"cat_toggle",str(cat_id))
        return edit_message(chat_id,message_id,"وضعیت دسته‌بندی تغییر کرد.",admin_cats_menu())
    if data.startswith("admin:cat_delete_confirm:"):
        cat_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف این دسته مطمئنی؟ محصولاتش هم حذف می‌شوند.",kb([
            [btn("✅ بله حذف کن",f"admin:cat_delete:{cat_id}")],[btn("❌ انصراف",f"admin:cat:{cat_id}")]]))
    if data.startswith("admin:cat_delete:"):
        cat_id=int(data.split(":")[2]); conn=db()
        conn.execute("DELETE FROM products WHERE category_id=?", (cat_id,))
        conn.execute("DELETE FROM categories WHERE id=?", (cat_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"cat_delete",str(cat_id))
        return edit_message(chat_id,message_id,"دسته‌بندی حذف شد.",admin_cats_menu())

    # products
    if data=="admin:products": return edit_message(chat_id,message_id,"📦 <b>مدیریت محصولات</b>",admin_products_menu())
    if data=="admin:prod_choose_cat": return edit_message(chat_id,message_id,"اول دسته‌بندی محصول را انتخاب کن:",admin_choose_cat_for_product())
    if data.startswith("admin:prod_add_to:"):
        cat_id=int(data.split(":")[2]); set_state(tg_id,"prod_add_title",{"cat_id":cat_id})
        return edit_message(chat_id,message_id,"نام محصول جدید را ارسال کن:",admin_back())
    if data.startswith("admin:prod:"):
        prod_id=int(data.split(":")[2])
        conn=db()
        p=conn.execute("""SELECT p.*,c.title cat_title FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?""",(prod_id,)).fetchone()
        conn.close()
        if not p: return edit_message(chat_id,message_id,"محصول پیدا نشد.",admin_products_menu())
        text=f"""📦 <b>{html_escape(p['title'])}</b>

ID: <code>{p['id']}</code>
دسته: {html_escape(p['cat_title'] or '-')}
قیمت: <b>{money(p['price'])}</b> تومان
ترتیب: {p['sort_order']}
وضعیت: {"فعال ✅" if p["is_active"] else "غیرفعال ❌"}
حالت موجودی: <code>{p['stock_mode']}</code>

توضیح:
{html_escape(p['description'] or '-')}

متن موجودی:
{html_escape(p['stock_text'] or '-')}

متن تحویل:
{html_escape(p['delivery_text'] or '-')}
"""
        return edit_message(chat_id,message_id,text,admin_product_detail_menu(prod_id))
    for prefix,state_name,prompt in [
        ("admin:prod_rename:","prod_rename","نام جدید محصول را ارسال کن:"),
        ("admin:prod_price:","prod_price","قیمت جدید را فقط عددی ارسال کن:"),
        ("admin:prod_desc:","prod_desc","توضیح جدید محصول را ارسال کن:"),
        ("admin:prod_stock:","prod_stock","متن موجودی/راهنما را ارسال کن:"),
        ("admin:prod_delivery:","prod_delivery","متن تحویل خودکار را ارسال کن:"),
        ("admin:prod_sort:","prod_sort","عدد ترتیب محصول را ارسال کن:")
    ]:
        if data.startswith(prefix):
            prod_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"prod_id":prod_id})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:prod_stockmode:"):
        prod_id=int(data.split(":")[2]); return edit_message(chat_id,message_id,"حالت موجودی را انتخاب کن:",admin_stockmode_menu(prod_id))
    if data.startswith("admin:prod_stockmode_set:"):
        parts=data.split(":"); prod_id=int(parts[2]); mode=parts[3]
        conn=db(); conn.execute("UPDATE products SET stock_mode=? WHERE id=?", (mode,prod_id)); conn.commit(); conn.close()
        log_admin(tg_id,"prod_stockmode",f"{prod_id}={mode}")
        return edit_message(chat_id,message_id,"✅ حالت موجودی تغییر کرد.",admin_product_detail_menu(prod_id))
    if data.startswith("admin:prod_move:"):
        prod_id=int(data.split(":")[2]); set_state(tg_id,"prod_move_wait_cat",{"prod_id":prod_id})
        return edit_message(chat_id,message_id,"دسته‌بندی جدید محصول را انتخاب کن:",admin_choose_cat_for_product("admin:prod_move_to"))
    if data.startswith("admin:prod_move_to:"):
        cat_id=int(data.split(":")[2]); st=get_state(tg_id)
        if not st or st["name"]!="prod_move_wait_cat": return edit_message(chat_id,message_id,"وضعیت انتقال پیدا نشد.",admin_products_menu())
        prod_id=st["data"]["prod_id"]; conn=db()
        conn.execute("UPDATE products SET category_id=? WHERE id=?", (cat_id,prod_id)); conn.commit(); conn.close()
        clear_state(tg_id); log_admin(tg_id,"prod_move",f"{prod_id}->{cat_id}")
        return edit_message(chat_id,message_id,"✅ دسته محصول تغییر کرد.",admin_products_menu())
    if data.startswith("admin:prod_toggle:"):
        prod_id=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE products SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?", (prod_id,))
        conn.commit(); conn.close(); log_admin(tg_id,"prod_toggle",str(prod_id))
        return edit_message(chat_id,message_id,"وضعیت محصول تغییر کرد.",admin_products_menu())
    if data.startswith("admin:prod_delete_confirm:"):
        prod_id=int(data.split(":")[2])
        return edit_message(chat_id,message_id,"آیا از حذف محصول مطمئنی؟",kb([[btn("✅ بله حذف کن",f"admin:prod_delete:{prod_id}")],[btn("❌ انصراف",f"admin:prod:{prod_id}")]]))
    if data.startswith("admin:prod_delete:"):
        prod_id=int(data.split(":")[2]); conn=db(); conn.execute("DELETE FROM products WHERE id=?", (prod_id,)); conn.commit(); conn.close()
        log_admin(tg_id,"prod_delete",str(prod_id))
        return edit_message(chat_id,message_id,"محصول حذف شد.",admin_products_menu())

    # users
    if data=="admin:users":
        conn=db(); rows=conn.execute("SELECT * FROM users ORDER BY id DESC LIMIT 25").fetchall(); conn.close()
        lines=["👥 <b>آخرین کاربران</b>\n"]
        for u in rows:
            lines.append(f"{'👑' if u['is_admin'] else ''}{'🚫' if u['is_blocked'] else ''} <code>{u['tg_id']}</code> | {html_escape(u['first_name'] or '-')} | @{html_escape(u['username'] or '-')}")
        return edit_message(chat_id,message_id,"\n".join(lines),kb([[btn("🔍 جستجوی کاربر","admin:user_search")],[btn("🔙 پنل ادمین","admin:home")]]))
    if data=="admin:user_search": set_state(tg_id,"user_search"); return edit_message(chat_id,message_id,"آیدی عددی یا یوزرنیم کاربر را ارسال کن:",admin_back())
    if data.startswith("admin:user:"):
        target=int(data.split(":")[2]); u=get_user(target)
        if not u: return edit_message(chat_id,message_id,"کاربر پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_user_admin(u),admin_user_detail_menu(target))
    if data.startswith("admin:user_toggle_block:"):
        target=int(data.split(":")[2]); conn=db()
        conn.execute("UPDATE users SET is_blocked=CASE WHEN is_blocked=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit(); conn.close(); log_admin(tg_id,"user_toggle_block",str(target))
        return edit_message(chat_id,message_id,render_user_admin(get_user(target)),admin_user_detail_menu(target))
    if data.startswith("admin:user_toggle_admin:"):
        target=int(data.split(":")[2])
        if OWNER_ID and target==OWNER_ID: return edit_message(chat_id,message_id,"مالک اصلی را نمی‌شود عادی کرد.",admin_back())
        conn=db(); conn.execute("UPDATE users SET is_admin=CASE WHEN is_admin=1 THEN 0 ELSE 1 END WHERE tg_id=?", (target,))
        conn.commit(); conn.close(); log_admin(tg_id,"user_toggle_admin",str(target))
        return edit_message(chat_id,message_id,render_user_admin(get_user(target)),admin_user_detail_menu(target))
    for prefix,state_name,prompt in [
        ("admin:user_balance:","user_balance","موجودی جدید کاربر را فقط عددی ارسال کن:"),
        ("admin:user_add_balance:","user_add_balance","مبلغ افزایش موجودی را فقط عددی ارسال کن:"),
        ("admin:user_sub_balance:","user_sub_balance","مبلغ کاهش موجودی را فقط عددی ارسال کن:")
    ]:
        if data.startswith(prefix):
            target=int(data.split(":")[2]); set_state(tg_id,state_name,{"target":target})
            return edit_message(chat_id,message_id,prompt,admin_back())
    if data.startswith("admin:user_txs:"):
        target=int(data.split(":")[2]); return show_user_txs(chat_id,message_id,target)
    if data.startswith("admin:user_orders:"):
        target=int(data.split(":")[2]); return show_orders(chat_id,message_id,target)

    # orders
    if data=="admin:orders": return show_orders(chat_id,message_id)
    if data.startswith("admin:order:"):
        order_id=int(data.split(":")[2])
        conn=db()
        o=conn.execute("""SELECT o.*,p.title product_title FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.id=?""",(order_id,)).fetchone()
        conn.close()
        if not o: return edit_message(chat_id,message_id,"سفارش پیدا نشد.",admin_back())
        return edit_message(chat_id,message_id,render_order_admin(o),admin_order_detail_menu(order_id))
    if data.startswith("admin:order_status:"):
        parts=data.split(":"); order_id=int(parts[2]); status=parts[3]
        conn=db(); conn.execute("UPDATE orders SET status=?, updated_at=? WHERE id=?", (status,now(),order_id)); conn.commit(); conn.close()
        log_admin(tg_id,"order_status",f"{order_id}={status}")
        return show_orders(chat_id,message_id)
    if data.startswith("admin:order_refund:"):
        order_id=int(data.split(":")[2])
        conn=db()
        o=conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not o:
            conn.close(); return edit_message(chat_id,message_id,"سفارش پیدا نشد.",admin_back())
        if "REFUNDED" in (o["note"] or ""):
            conn.close(); return edit_message(chat_id,message_id,"این سفارش قبلاً بازگشت وجه شده است.",admin_back())
        conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?", (o["amount"],o["user_id"]))
        conn.execute("UPDATE orders SET status='refunded', note=note||? , updated_at=? WHERE id=?", ("\nREFUNDED",now(),order_id))
        add_wallet_tx(conn,o["user_id"],o["amount"],"refund","order",order_id,"بازگشت وجه سفارش")
        conn.commit(); conn.close(); log_admin(tg_id,"order_refund",str(order_id))
        try: send_message(o["user_id"], f"🔄 مبلغ سفارش <code>{o['order_code']}</code> به کیف پول شما برگشت داده شد.")
        except Exception: pass
        return show_orders(chat_id,message_id)
    for prefix,state_name,prompt in [
        ("admin:order_note:","order_note","یادداشت جدید سفارش را ارسال کن:"),
        ("admin:order_delivery:","order_delivery","متن تحویل سفارش را ارسال کن:")
    ]:
        if data.startswith(prefix):
            order_id=int(data.split(":")[2]); set_state(tg_id,state_name,{"order_id":order_id})
            return edit_message(chat_id,message_id,prompt,admin_back())

    # settings/logs/backup
    if data=="admin:settings": return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    if data=="admin:toggle_bot":
        set_setting("bot_status","off" if get_setting("bot_status","on")=="on" else "on")
        return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    if data=="admin:toggle_shop":
        set_setting("shop_status","off" if get_setting("shop_status","on")=="on" else "on")
        return edit_message(chat_id,message_id,"⚙️ <b>تنظیمات</b>",admin_settings_menu())
    for cb,state,prompt in [
        ("admin:set_welcome","set_welcome","متن جدید /start را ارسال کن:"),
        ("admin:set_bank","set_bank","اطلاعات پرداخت/شماره کارت را ارسال کن:"),
        ("admin:set_min_topup","set_min_topup","حداقل مبلغ شارژ را عددی ارسال کن:"),
        ("admin:set_max_topup","set_max_topup","حداکثر مبلغ شارژ را عددی ارسال کن:"),
        ("admin:set_support","set_support","یوزرنیم پشتیبانی را ارسال کن:"),
        ("admin:set_channel","set_channel","یوزرنیم کانال را ارسال کن:"),
        ("admin:set_website","set_website","آدرس وب‌سایت را ارسال کن:"),
        ("admin:set_instagram","set_instagram","آدرس یا یوزرنیم اینستاگرام را ارسال کن:"),
        ("admin:broadcast","broadcast","متن پیام همگانی را ارسال کن:")
    ]:
        if data==cb:
            set_state(tg_id,state); return edit_message(chat_id,message_id,prompt,admin_back())
    if data=="admin:logs":
        conn=db(); rows=conn.execute("SELECT * FROM admin_logs ORDER BY id DESC LIMIT 30").fetchall(); conn.close()
        if not rows: text="📜 لاگی ثبت نشده است."
        else:
            lines=["📜 <b>آخرین لاگ‌ها</b>\n"]
            for r in rows:
                lines.append(f"#{r['id']} | <code>{r['admin_tg_id']}</code> | {html_escape(r['action'])} | {html_escape(r['detail'] or '-')} | {r['created_at']}")
            text="\n".join(lines)
        return edit_message(chat_id,message_id,text,admin_back())
    if data=="admin:backup":
        backup=f"mvlite_backup_{int(time.time())}.db"
        with open(DB_PATH,"rb") as src, open(backup,"wb") as dst: dst.write(src.read())
        send_document(chat_id, backup, "💾 بکاپ دیتابیس MVLite")
        try: os.remove(backup)
        except Exception: pass
        return edit_message(chat_id,message_id,"✅ بکاپ ارسال شد.",admin_menu())
    if data=="admin:clear_state": clear_state(tg_id); return edit_message(chat_id,message_id,"وضعیت موقت پاک شد.",admin_menu())

def show_user_txs(chat_id,message_id,target):
    conn=db()
    rows=conn.execute("SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 25",(target,)).fetchall()
    conn.close()
    if not rows: return edit_message(chat_id,message_id,"تراکنشی برای این کاربر نیست.",admin_back())
    lines=[f"📜 <b>تراکنش‌های کاربر</b>\n<code>{target}</code>\n"]
    for r in rows:
        sign="+" if r["amount"]>=0 else ""
        lines.append(f"#{r['id']} | {sign}{money(r['amount'])} | {r['type']} | {html_escape(r['note'] or '-')} | {r['created_at']}")
    return edit_message(chat_id,message_id,"\n".join(lines),admin_back())

# -------------------- State Text / Photo --------------------

def handle_state_message(chat_id,tg_id,text,message=None):
    st=get_state(tg_id)
    if not st: return False
    name=st["name"]; data=st.get("data") or {}

    if name=="topup_amount":
        amount=safe_int(only_digits(text),0)
        minv=safe_int(get_setting("min_topup","10000"),10000)
        maxv=safe_int(get_setting("max_topup","50000000"),50000000)
        if amount < minv or amount > maxv:
            send_message(chat_id,f"❌ مبلغ باید بین {money(minv)} تا {money(maxv)} تومان باشد.",wallet_menu())
            clear_state(tg_id); return True
        set_state(tg_id,"topup_receipt",{"amount":amount})
        send_message(chat_id,
            f"✅ مبلغ ثبت شد: {money(amount)} تومان\n\nحالا رسید پرداخت را به صورت متن یا عکس ارسال کن.",
            kb([[btn("🔙 کیف پول","wallet")]]))
        return True

    if name=="topup_receipt":
        amount=data["amount"]
        receipt_type="text"; receipt_text=text or ""; file_id=""
        if message and message.get("photo"):
            receipt_type="photo"
            file_id=message["photo"][-1]["file_id"]
            receipt_text=message.get("caption","")
        code=short_code("PAY")
        conn=db()
        conn.execute("""INSERT INTO payment_requests(request_code,user_id,amount,status,receipt_type,receipt_text,receipt_file_id,created_at)
                        VALUES(?,?,?,?,?,?,?,?)""", (code,tg_id,amount,"pending",receipt_type,receipt_text,file_id,now()))
        conn.commit(); conn.close()
        clear_state(tg_id)
        send_message(chat_id,f"✅ درخواست شارژ ثبت شد.\n\nکد: <code>{code}</code>\nمبلغ: {money(amount)} تومان\nوضعیت: pending",wallet_menu())
        notify_admins(f"💳 درخواست شارژ جدید\n\nکاربر: <code>{tg_id}</code>\nمبلغ: <b>{money(amount)}</b>\nکد: <code>{code}</code>")
        return True

    if name=="ticket_subject":
        subject=text.strip()[:80]
        if not subject:
            send_message(chat_id,"موضوع تیکت خالی است.",support_menu())
            clear_state(tg_id); return True
        set_state(tg_id,"ticket_message",{"subject":subject})
        send_message(chat_id,"حالا متن کامل پیام تیکت را ارسال کن:",kb([[btn("🔙 پشتیبانی","support")]]))
        return True

    if name=="ticket_message":
        subject=data["subject"]
        code=short_code("TCK")
        conn=db()
        conn.execute("""INSERT INTO tickets(ticket_code,user_id,subject,status,created_at,updated_at)
                        VALUES(?,?,?,?,?,?)""", (code,tg_id,subject,"open",now(),now()))
        ticket_id=conn.execute("SELECT last_insert_rowid() x").fetchone()["x"]
        conn.execute("""INSERT INTO ticket_messages(ticket_id,sender_type,sender_id,message,created_at)
                        VALUES(?,?,?,?,?)""", (ticket_id,"user",tg_id,text.strip(),now()))
        conn.commit(); conn.close()
        clear_state(tg_id)
        send_message(chat_id,f"✅ تیکت شما ثبت شد.\n\nکد: <code>{code}</code>\nوضعیت: open",support_menu())
        notify_admins(f"🎫 تیکت جدید\n\nکاربر: <code>{tg_id}</code>\nکد: <code>{code}</code>\nموضوع: {html_escape(subject)}")
        return True

    if name=="ticket_addmsg":
        ticket_id=data["ticket_id"]
        conn=db()
        t=conn.execute("SELECT * FROM tickets WHERE id=? AND user_id=?", (ticket_id,tg_id)).fetchone()
        if not t:
            conn.close(); clear_state(tg_id)
            send_message(chat_id,"تیکت پیدا نشد.",support_menu()); return True
        conn.execute("""INSERT INTO ticket_messages(ticket_id,sender_type,sender_id,message,created_at)
                        VALUES(?,?,?,?,?)""", (ticket_id,"user",tg_id,text.strip(),now()))
        conn.execute("UPDATE tickets SET status='open', updated_at=? WHERE id=?", (now(),ticket_id))
        conn.commit(); conn.close()
        clear_state(tg_id)
        send_message(chat_id,"✅ پیام شما به تیکت اضافه شد.",support_menu())
        notify_admins(f"🎫 پیام جدید روی تیکت\n\nکد: <code>{t['ticket_code']}</code>\nکاربر: <code>{tg_id}</code>")
        return True

    if name=="product_search":
        clear_state(tg_id)
        return show_product_search_results(chat_id, None, text.strip())

    if name=="purchase_coupon":
        prod_id=data["prod_id"]
        coupon_code=text.strip()
        clear_state(tg_id)
        return finalize_purchase(chat_id, message.get("message_id") if message else None, tg_id, prod_id, coupon_code)

    # admin-only states
    if not is_admin(tg_id):
        clear_state(tg_id); return False

    conn=db()
    try:
        if name=="coupon_add_code":
            code=text.strip().upper().replace(" ","")
            if not code:
                send_message(chat_id,"کد معتبر نیست.",admin_coupons_menu()); return True
            try:
                conn.execute("""INSERT INTO coupons(code,title,discount_type,amount,min_order,max_uses,used_count,is_active,created_at)
                                VALUES(?,?,?,?,?,?,?,?,?)""", (code,"","fixed",0,0,0,0,1,now()))
                conn.commit()
                send_message(chat_id,"✅ کد تخفیف ساخته شد. حالا مقدار و نوع آن را تنظیم کن.",admin_coupons_menu())
            except sqlite3.IntegrityError:
                send_message(chat_id,"❌ این کد قبلاً وجود دارد.",admin_coupons_menu())
            return True

        if name=="coupon_title":
            conn.execute("UPDATE coupons SET title=? WHERE id=?", (text.strip(),data["coupon_id"]))
            conn.commit(); send_message(chat_id,"✅ عنوان تغییر کرد.",admin_coupons_menu()); return True

        if name=="coupon_amount":
            amount=safe_int(only_digits(text),0)
            conn.execute("UPDATE coupons SET amount=? WHERE id=?", (amount,data["coupon_id"]))
            conn.commit(); send_message(chat_id,"✅ مقدار تخفیف تغییر کرد.",admin_coupons_menu()); return True

        if name=="coupon_min":
            value=safe_int(only_digits(text),0)
            conn.execute("UPDATE coupons SET min_order=? WHERE id=?", (value,data["coupon_id"]))
            conn.commit(); send_message(chat_id,"✅ حداقل سفارش تغییر کرد.",admin_coupons_menu()); return True

        if name=="coupon_max":
            value=safe_int(only_digits(text),0)
            conn.execute("UPDATE coupons SET max_uses=? WHERE id=?", (value,data["coupon_id"]))
            conn.commit(); send_message(chat_id,"✅ ظرفیت استفاده تغییر کرد.",admin_coupons_menu()); return True

        if name=="set_maintenance":
            set_setting("maintenance_text",text.strip()); send_message(chat_id,"✅ متن تعمیرات تغییر کرد.",texts_admin_menu()); return True
        if name=="set_announcement":
            set_setting("announcement_text",text.strip()); send_message(chat_id,"✅ اطلاعیه تغییر کرد.",texts_admin_menu()); return True
        if name=="set_rules":
            set_setting("rules_text",text.strip()); send_message(chat_id,"✅ قوانین تغییر کرد.",texts_admin_menu()); return True
        if name=="set_about":
            set_setting("about_text",text.strip()); send_message(chat_id,"✅ درباره ما تغییر کرد.",texts_admin_menu()); return True
        if name=="set_banner":
            set_setting("banner_text",text.strip()); send_message(chat_id,"✅ بنر متنی تغییر کرد.",texts_admin_menu()); return True
        if name=="set_website":
            set_setting("website_url",text.strip()); send_message(chat_id,"✅ وب‌سایت تغییر کرد.",admin_settings_menu()); return True
        if name=="set_instagram":
            set_setting("instagram_url",text.strip()); send_message(chat_id,"✅ اینستاگرام تغییر کرد.",admin_settings_menu()); return True

        if name=="faq_add_q":
            set_state(tg_id,"faq_add_a",{"question":text.strip()})
            send_message(chat_id,"حالا پاسخ این سوال را ارسال کن:",admin_back()); return True
        if name=="faq_add_a":
            q=data["question"]
            conn.execute("""INSERT INTO faqs(question,answer,is_active,sort_order,created_at)
                            VALUES(?,?,?,?,?)""",(q,text.strip(),1,100,now()))
            conn.commit(); log_admin(tg_id,"faq_add",q)
            send_message(chat_id,"✅ سوال متداول اضافه شد.",admin_faqs_menu()); return True
        if name=="faq_q":
            conn.execute("UPDATE faqs SET question=? WHERE id=?",(text.strip(),data["faq_id"]))
            conn.commit(); send_message(chat_id,"✅ سوال تغییر کرد.",admin_faqs_menu()); return True
        if name=="faq_a":
            conn.execute("UPDATE faqs SET answer=? WHERE id=?",(text.strip(),data["faq_id"]))
            conn.commit(); send_message(chat_id,"✅ پاسخ تغییر کرد.",admin_faqs_menu()); return True
        if name=="faq_sort":
            conn.execute("UPDATE faqs SET sort_order=? WHERE id=?",(safe_int(text,100),data["faq_id"]))
            conn.commit(); send_message(chat_id,"✅ ترتیب تغییر کرد.",admin_faqs_menu()); return True

        if name=="admin_order_search":
            show_order_admin_search(chat_id,text)
            return True

        if name=="admin_payment_search":
            show_payment_admin_search(chat_id,text)
            return True

        if name=="admin_product_search":
            show_product_admin_search(chat_id,text)
            return True

        if name=="set_rate_count":
            set_setting("rate_limit_count",str(max(1,safe_int(only_digits(text),8))))
            send_message(chat_id,"✅ تعداد مجاز پیام تغییر کرد.",security_settings_menu()); return True
        if name=="set_rate_window":
            set_setting("rate_limit_window",str(max(1,safe_int(only_digits(text),10))))
            send_message(chat_id,"✅ بازه زمانی تغییر کرد.",security_settings_menu()); return True
        if name=="set_mute_seconds":
            set_setting("mute_seconds",str(max(5,safe_int(only_digits(text),60))))
            send_message(chat_id,"✅ مدت mute تغییر کرد.",security_settings_menu()); return True

        if name=="stock_import":
            product_id=data["product_id"]
            lines=[ln.strip() for ln in text.splitlines() if ln.strip()]
            if not lines:
                send_message(chat_id,"هیچ کدی دریافت نشد.",admin_back()); return True
            inserted=0
            for line in lines:
                conn.execute("""INSERT INTO product_codes(product_id,code_text,status,created_at)
                                VALUES(?,?,?,?)""", (product_id,line,"available",now()))
                inserted += 1
            conn.commit()
            log_admin(tg_id,"stock_import",f"product={product_id}, count={inserted}")
            send_message(chat_id,f"✅ {inserted} کد برای محصول #{product_id} اضافه شد.",admin_stock_product_menu(product_id))
            return True

        if name=="admin_ticket_reply":
            ticket_id=data["ticket_id"]
            t=conn.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
            if not t:
                send_message(chat_id,"تیکت پیدا نشد.",admin_back()); return True
            conn.execute("""INSERT INTO ticket_messages(ticket_id,sender_type,sender_id,message,created_at)
                            VALUES(?,?,?,?,?)""", (ticket_id,"admin",tg_id,text.strip(),now()))
            conn.execute("UPDATE tickets SET updated_at=? WHERE id=?", (now(),ticket_id))
            conn.commit()
            log_admin(tg_id,"ticket_reply",str(ticket_id))
            send_message(chat_id,"✅ پاسخ ثبت شد.",admin_ticket_menu(ticket_id))
            try: send_message(t["user_id"], f"↩️ پاسخ جدید برای تیکت <code>{t['ticket_code']}</code> ثبت شد.")
            except Exception: pass
            return True

        if name=="cat_add_title":
            slug="cat_"+str(int(time.time()))
            conn.execute("INSERT INTO categories(title,slug,description,is_active,sort_order,created_at) VALUES(?,?,?,?,?,?)",(text.strip(),slug,"",1,100,now()))
            conn.commit(); log_admin(tg_id,"cat_add",text); send_message(chat_id,"✅ دسته‌بندی اضافه شد.",admin_cats_menu()); return True
        if name=="cat_rename":
            conn.execute("UPDATE categories SET title=? WHERE id=?",(text.strip(),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ نام تغییر کرد.",admin_cats_menu()); return True
        if name=="cat_desc":
            conn.execute("UPDATE categories SET description=? WHERE id=?",(text.strip(),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ توضیح تغییر کرد.",admin_cats_menu()); return True
        if name=="cat_sort":
            conn.execute("UPDATE categories SET sort_order=? WHERE id=?",(safe_int(text,100),data["cat_id"])); conn.commit(); send_message(chat_id,"✅ ترتیب تغییر کرد.",admin_cats_menu()); return True
        if name=="prod_add_title":
            conn.execute("""INSERT INTO products(category_id,title,description,price,stock_text,is_active,sort_order,created_at,stock_mode,delivery_text,min_qty,max_qty)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (data["cat_id"],text.strip(),"",0,"",1,100,now(),"manual","",1,1))
            conn.commit(); log_admin(tg_id,"prod_add",text); send_message(chat_id,"✅ محصول اضافه شد.",admin_products_menu()); return True
        if name=="prod_rename":
            conn.execute("UPDATE products SET title=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ نام محصول تغییر کرد.",admin_products_menu()); return True
        if name=="prod_price":
            conn.execute("UPDATE products SET price=? WHERE id=?",(safe_int(only_digits(text),0),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ قیمت تغییر کرد.",admin_products_menu()); return True
        if name=="prod_desc":
            conn.execute("UPDATE products SET description=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ توضیح تغییر کرد.",admin_products_menu()); return True
        if name=="prod_stock":
            conn.execute("UPDATE products SET stock_text=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ متن موجودی تغییر کرد.",admin_products_menu()); return True
        if name=="prod_delivery":
            conn.execute("UPDATE products SET delivery_text=? WHERE id=?",(text.strip(),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ متن تحویل تغییر کرد.",admin_products_menu()); return True
        if name=="prod_sort":
            conn.execute("UPDATE products SET sort_order=? WHERE id=?",(safe_int(text,100),data["prod_id"])); conn.commit(); send_message(chat_id,"✅ ترتیب محصول تغییر کرد.",admin_products_menu()); return True
        if name=="user_search":
            u=get_user_by_any(text)
            if not u: send_message(chat_id,"❌ کاربر پیدا نشد.",admin_back())
            else: send_message(chat_id,render_user_admin(u),admin_user_detail_menu(u["tg_id"]))
            return True
        if name=="user_balance":
            target=data["target"]; newbal=safe_int(only_digits(text),0)
            old=conn.execute("SELECT balance FROM users WHERE tg_id=?",(target,)).fetchone()["balance"]
            delta=newbal-old
            conn.execute("UPDATE users SET balance=? WHERE tg_id=?",(newbal,target))
            add_wallet_tx(conn,target,delta,"admin_set","user",target,"تنظیم موجودی توسط ادمین")
            conn.commit(); send_message(chat_id,"✅ موجودی تنظیم شد.",admin_user_detail_menu(target)); return True
        if name in ("user_add_balance","user_sub_balance"):
            target=data["target"]; amount=safe_int(only_digits(text),0)
            delta=amount if name=="user_add_balance" else -amount
            conn.execute("UPDATE users SET balance=balance+? WHERE tg_id=?",(delta,target))
            add_wallet_tx(conn,target,delta,"admin_adjust","user",target,"افزایش/کاهش دستی ادمین")
            conn.commit(); send_message(chat_id,"✅ موجودی تغییر کرد.",admin_user_detail_menu(target)); return True
        if name=="order_note":
            conn.execute("UPDATE orders SET note=?, updated_at=? WHERE id=?",(text.strip(),now(),data["order_id"])); conn.commit(); send_message(chat_id,"✅ یادداشت ثبت شد.",admin_menu()); return True
        if name=="order_delivery":
            conn.execute("UPDATE orders SET delivery_text=?, status='done', updated_at=? WHERE id=?",(text.strip(),now(),data["order_id"])); conn.commit()
            o=conn.execute("SELECT * FROM orders WHERE id=?",(data["order_id"],)).fetchone()
            send_message(chat_id,"✅ متن تحویل ثبت و سفارش done شد.",admin_menu())
            try: send_message(o["user_id"], f"✅ سفارش شما تکمیل شد.\nکد: <code>{o['order_code']}</code>\n\nتحویل:\n{html_escape(text)}")
            except Exception: pass
            return True
        if name=="pay_note":
            conn.execute("UPDATE payment_requests SET admin_note=? WHERE id=?",(text.strip(),data["pay_id"])); conn.commit(); send_message(chat_id,"✅ یادداشت پرداخت ثبت شد.",admin_menu()); return True
        if name=="set_welcome": set_setting("welcome_text",text.strip()); send_message(chat_id,"✅ متن شروع تغییر کرد.",admin_settings_menu()); return True
        if name=="set_bank": set_setting("bank_info",text.strip()); send_message(chat_id,"✅ اطلاعات پرداخت تغییر کرد.",admin_settings_menu()); return True
        if name=="set_min_topup": set_setting("min_topup",str(safe_int(only_digits(text),10000))); send_message(chat_id,"✅ حداقل شارژ تغییر کرد.",admin_settings_menu()); return True
        if name=="set_max_topup": set_setting("max_topup",str(safe_int(only_digits(text),50000000))); send_message(chat_id,"✅ حداکثر شارژ تغییر کرد.",admin_settings_menu()); return True
        if name=="set_support": set_setting("support_username",text.strip()); send_message(chat_id,"✅ پشتیبانی تغییر کرد.",admin_settings_menu()); return True
        if name=="set_channel": set_setting("channel_username",text.strip()); send_message(chat_id,"✅ کانال تغییر کرد.",admin_settings_menu()); return True
        if name=="set_website": set_setting("website_url",text.strip()); send_message(chat_id,"✅ وب‌سایت تغییر کرد.",admin_settings_menu()); return True
        if name=="set_instagram": set_setting("instagram_url",text.strip()); send_message(chat_id,"✅ اینستاگرام تغییر کرد.",admin_settings_menu()); return True
        if name=="broadcast":
            users=conn.execute("SELECT tg_id FROM users WHERE is_blocked=0").fetchall()
            clear_state(tg_id); conn.close()
            ok=fail=0; send_message(chat_id,f"📣 شروع ارسال به {len(users)} کاربر...")
            for u in users:
                try: send_message(u["tg_id"],text); ok+=1; time.sleep(0.05)
                except Exception: fail+=1
            log_admin(tg_id,"broadcast",f"ok={ok},fail={fail}")
            send_message(chat_id,f"✅ ارسال تمام شد.\nموفق: {ok}\nناموفق: {fail}",admin_menu())
            return True
    finally:
        try: conn.close()
        except Exception: pass
        clear_state(tg_id)
    return False

def notify_admins(text):
    conn=db(); admins=conn.execute("SELECT tg_id FROM users WHERE is_admin=1").fetchall(); conn.close()
    for a in admins:
        try: send_message(a["tg_id"], text)
        except Exception: pass

# -------------------- Dispatcher --------------------

def handle_message(message):
    u=upsert_user(message)
    chat_id=message["chat"]["id"]; tg_id=message["from"]["id"]
    if rate_limited(tg_id):
        remain=max(1,get_mute_until(tg_id)-int(time.time()))
        return send_message(chat_id,f"⏳ لطفاً کمی آهسته‌تر پیام ارسال کنید.\nمحدودیت موقت: {remain} ثانیه")
    text=message.get("text","")

    if u["is_blocked"]: return send_message(chat_id,"🚫 دسترسی شما به ربات مسدود شده است.")
    if get_setting("bot_status","on")!="on" and not is_admin(tg_id):
        return send_message(chat_id,html_escape(get_setting("maintenance_text","ربات فعلاً غیرفعال است.")))

    if text=="/start": clear_state(tg_id); return open_main(chat_id)
    if text=="/help": return send_message(chat_id,HELP_TEXT,back_main())
    if text=="/id": return send_message(chat_id,f"آیدی عددی شما:\n<code>{tg_id}</code>")
    if text=="/version": return send_message(chat_id,release_notes_text())
    if text=="/claim_admin":
        conn=db(); count=conn.execute("SELECT COUNT(*) n FROM users WHERE is_admin=1").fetchone()["n"]
        if count==0 or (OWNER_ID and tg_id==OWNER_ID):
            conn.execute("UPDATE users SET is_admin=1 WHERE tg_id=?",(tg_id,)); conn.commit(); conn.close()
            return send_message(chat_id,"✅ شما ادمین شدید.\nحالا /admin را بزنید.")
        conn.close(); return send_message(chat_id,"❌ ادمین قبلاً ثبت شده است.")
    if text=="/admin":
        if not is_admin(tg_id): return send_message(chat_id,"❌ شما ادمین نیستید.\nاگر اولین اجراست، /claim_admin را بزنید.")
        clear_state(tg_id); return send_message(chat_id,render_admin_home(),admin_menu())
    if text=="/tools":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        return send_message(chat_id,"🛠 ابزارهای مدیریتی",admin_tools_menu())
    if text=="/analytics":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        return send_message(chat_id,analytics_summary("all"),analytics_menu())
    if text=="/security":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        return send_message(chat_id,security_status_text(),security_menu())
    if text=="/diag":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        return send_message(chat_id,diagnostics_text(),release_menu())

    if text=="/backup":
        if not is_admin(tg_id): return send_message(chat_id,"❌ دسترسی ندارید.")
        backup=f"mvlite_backup_{int(time.time())}.db"
        with open(DB_PATH,"rb") as src, open(backup,"wb") as dst: dst.write(src.read())
        send_document(chat_id,backup,"💾 بکاپ دیتابیس")
        try: os.remove(backup)
        except Exception: pass
        return

    if handle_state_message(chat_id,tg_id,text,message): return
    return send_message(chat_id,"از منوی زیر استفاده کنید:",main_menu())

def handle_callback(callback):
    cid=callback["id"]; answer_callback(cid)
    msg=callback.get("message",{})
    chat_id=msg.get("chat",{}).get("id"); message_id=msg.get("message_id")
    tg_id=callback["from"]["id"]; data=callback.get("data","")
    upsert_user({"from":callback["from"],"chat":msg.get("chat",{})})
    try:
        if data.startswith("admin:"): return handle_admin_callback(chat_id,message_id,tg_id,data)
        return handle_user_callback(chat_id,message_id,tg_id,data)
    except PermissionError:
        return edit_message(chat_id,message_id,"❌ دسترسی ادمین ندارید.",back_main())
    except Exception as e:
        traceback.print_exc()
        return edit_message(chat_id,message_id,f"خطا:\n<code>{html_escape(repr(e))}</code>",back_main())

def polling_loop():
    print("MVLite Part 03 is running...")
    print("Use /claim_admin for first admin, then /admin")
    offset=0
    while True:
        try:
            updates=tg("getUpdates",{"timeout":30,"offset":offset,"allowed_updates":["message","callback_query"]},45)
            for upd in updates:
                offset=upd["update_id"]+1
                try:
                    if "message" in upd: handle_message(upd["message"])
                    elif "callback_query" in upd: handle_callback(upd["callback_query"])
                except Exception as inner:
                    print("UPDATE ERROR:",repr(inner)); traceback.print_exc()
        except KeyboardInterrupt:
            print("Stopped by user.")
            break
        except Exception as e:
            print("POLLING ERROR:",repr(e)); time.sleep(5)

def main():
    init_db()
    polling_loop()

if __name__=="__main__":
    main()

